
import io
import re
from pathlib import Path
from datetime import datetime
import pandas as pd
import streamlit as st
import subprocess
import platform
import os

VERSION = "3.4.5 RFND wrapper real"
APP_NAME = "Conciliador IATA - Maveric"
APP_DIR = Path(__file__).resolve().parent
LOGO_PATH = APP_DIR / "sevens_logo.png"
CREATED_LABEL = "03jun2026"

def show_logo():
    try:
        if LOGO_PATH.exists():
            st.image(str(LOGO_PATH), width=130)
        else:
            st.markdown("**SEVENS TRAVEL**")
    except Exception:
        st.markdown("**SEVENS TRAVEL**")


ACMA_OVERRIDES = {
    "8996000581": -68512.00,
}


AUTHORIZED_DEVICES = {
    "00000000-0000-0000-0000-309C230BAEF1": {"name": "Tuki PC", "role": "admin"},
    "D4157452-1745-11EC-B699-67F9496C3500": {"name": "Laura Techera PC", "role": "user"},
    "86FE5326-6706-53D3-97C4-442452FDC186": {"name": "Tuki Mac Admin", "role": "admin"},
    "0C8703A9-3F15-54CD-A977-B4D2B4CFE266": {"name": "Federico Mac", "role": "user"},
    "C1C28570-D1CF-0000-0000-000000000000": {"name": "Federico PC", "role": "user"},
    "60658200-1690-11EC-8AD9-C282CD8C3500": {"name": "Karen PC", "role": "user"},
}

def get_device_uuid():
    system = platform.system().lower()
    try:
        if system == "darwin":
            out = subprocess.check_output(
                ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                stderr=subprocess.DEVNULL,
                text=True,
                timeout=5
            )
            m = re.search(r'"IOPlatformUUID"\s*=\s*"([^"]+)"', out)
            return m.group(1).strip().upper() if m else None

        if system == "windows":
            out = subprocess.check_output(
                ["wmic", "csproduct", "get", "uuid"],
                stderr=subprocess.DEVNULL,
                text=True,
                timeout=5
            )
            lines = [x.strip() for x in out.splitlines() if x.strip() and "UUID" not in x.upper()]
            return lines[0].upper() if lines else None
    except Exception:
        return None
    return None


def get_conciliador_home():
    return REPORTS_DIR

def periodo_label(start_date, end_date):
    start = pd.Timestamp(start_date)
    end = pd.Timestamp(end_date)
    meses = {
        1: "ene", 2: "feb", 3: "mar", 4: "abr", 5: "may", 6: "jun",
        7: "jul", 8: "ago", 9: "sep", 10: "oct", 11: "nov", 12: "dic"
    }
    if start.month == end.month and start.year == end.year:
        return f"{start.day}-{end.day} {meses[end.month]} {str(end.year)[-2:]}"
    return f"{start.day} {meses[start.month]}-{end.day} {meses[end.month]} {str(end.year)[-2:]}"


def check_device_authorized():
    uuid = get_device_uuid()
    info = AUTHORIZED_DEVICES.get((uuid or "").upper())
    return uuid, info


def read_txt_file(uploaded_file):
    raw = uploaded_file.read()
    return raw.decode("latin-1", errors="ignore").splitlines()

def parse_iata_date(line, date_re):
    m = date_re.search(line)
    if not m:
        return pd.NaT
    y = m.group(3)
    try:
        return pd.Timestamp(2000 + int(y[:2]), int(y[2:4]), int(y[4:6]))
    except Exception:
        return pd.NaT

def parse_txt_blocks(lines):
    doc_re = re.compile(r"(TKTT|ADMA|SPDR|EMDS|EMDA|CANX|CANN|ACMA|SPCR|RFND)(\d{10})")
    date_re = re.compile(r"(TKTT|ADMA|SPDR|EMDS|EMDA|CANX|CANN|ACMA|SPCR|RFND)(\d{10})(?:\d)?(\d{6})")
    blocks = {}
    cur = None
    for i, line in enumerate(lines, start=1):
        m = doc_re.search(line)
        if line.startswith("DET") and m:
            cur = m.group(2)
            if cur not in blocks:
                blocks[cur] = {
                    "Documento IATA": cur,
                    "Tipo TXT": m.group(1),
                    "Aerolínea TXT": line[3:6] if len(line) >= 6 else "",
                    "Fecha IATA": parse_iata_date(line, date_re),
                    "Linea TXT": i,
                    "DET TXT": line,
                    "Bloque TXT": line,
                    "Cantidad DET": 1,
                }
            else:
                blocks[cur]["DET TXT"] += "\n" + line
                blocks[cur]["Bloque TXT"] += "\n" + line
                blocks[cur]["Cantidad DET"] += 1
        elif cur:
            blocks[cur]["Bloque TXT"] += "\n" + line
    return blocks

def section_after_usd2(det):
    if not det:
        return ""
    s = str(det)
    if "USD2" in s:
        s = s.split("USD2", 1)[1]
    elif "USD" in s:
        s = s.split("USD", 1)[1]
    else:
        return ""
    m = re.search(r"\s{4,}[A-Z]\s", s)
    return s[:m.start()] if m else s[:230]

def signed_amount_from_chunk(raw, max_chars=12):
    raw = str(raw)
    if not raw.startswith("-"):
        return None, ""
    part = raw[:max_chars] if len(raw) >= max_chars else raw
    digits = re.sub(r"^-0+", "", part)
    if digits == "":
        return 0.0, part
    return -int(digits) / 100, part

def parse_acma_importe(det, doc=None):
    if doc in ACMA_OVERRIDES:
        return ACMA_OVERRIDES[doc], "override_usuario"
    sec = section_after_usd2(det)
    vals = []
    for m in re.finditer(r"-0+\d+", sec[:220]):
        val, part = signed_amount_from_chunk(m.group(0), 12)
        if val is not None and abs(val) > 0:
            vals.append((round(val, 2), part))
    if vals:
        idx = 1 if len(vals) > 1 else 0
        return vals[idx]
    return None, "sin_candidato_acma"


def parse_adma_importe(det):
    """
    ADMA/SPDR siempre positivos.
    ADMA: -000000043800... => 4.38
    SPDR: 000001201460000... => 1201.46
    """
    s = str(det)
    sec = section_after_usd2(s)

    if "SPDR" in s:
        tail = s.split(" I ", 1)[-1] if " I " in s else s
        m_tail = re.search(r"(?<!\d)(0{1,}\d{6,})(?=0{6,})", tail)
        if m_tail:
            field = m_tail.group(1)[:11]
            try:
                return round(int(field) / 100, 2), field
            except Exception:
                pass
        m = re.search(r"USD2(0+\d{6,})", s)
        if m:
            field = m.group(1)[:11]
            try:
                return round(int(field) / 100, 2), field
            except Exception:
                pass

    for m in re.finditer(r"-0+\d+", sec[:220]):
        val, part = signed_amount_from_chunk(m.group(0), 11)
        if val is not None and abs(val) > 0:
            return round(abs(val), 2), part

    aud, afield, ameth = audit_net(s)
    return (round(abs(aud), 2) if aud is not None else None), afield


def _rfnd_parse_fixed_usd2(det):
    """
    RFND v3.4.8 - lectura posicional estable.
    Regla base detectada en TXT BSP:
    - Cash real = campo posicional USD2[60:72] (12 caracteres, centavos, puede ser + / - / cero).
    - CC real = último importe de la cola antes de RFxxx cuando hay al menos dos importes en esa cola.
      Ej: 00000000000-00000013377RF -> cash blanco, CC -133.77.
      Ej: -0000008802-00000012700RF -> cash -88.02, CC -127.00.
    - No tomar el primer importe de USD2 ni el último negativo largo de USD2 como cash.
    - Si el cash posicional es cero, se devuelve blanco/None para no inventar cash.
    """
    det = str(det or "")

    def _amt(field):
        f = str(field or "").strip()
        if not f or not re.fullmatch(r"-?\d+", f):
            return None
        sign = -1 if f.startswith("-") else 1
        digits = f[1:] if f.startswith("-") else f
        if not digits or set(digits) == {"0"}:
            return None
        return round(sign * int(digits) / 100.0, 2)

    pre = ""
    tail = ""
    if "USD2" in det:
        after_usd2 = det.split("USD2", 1)[1]
        if "     I" in after_usd2:
            pre, rest = after_usd2.split("     I", 1)
            tail = rest.split("RF", 1)[0] if "RF" in rest else rest
        else:
            pre = after_usd2

    cash_field = pre[60:72] if len(pre) >= 72 else ""
    cash = _amt(cash_field)

    # CC: cola antes de RF. Ignora códigos tipo W05 / OPERINT5 tomando solo bloques largos.
    tail_tokens = re.findall(r"-?\d{10,22}", tail)
    cc_field = ""
    cc = None
    if len(tail_tokens) >= 2:
        cc_field = tail_tokens[-1]
        cc = _amt(cc_field)

    # Comisión informativa: marcador habitual 0100/0500 en USD2.
    campo_comision = ""
    comision = 0
    m_com = re.search(r"0000(100|500)", pre)
    if m_com:
        campo_comision = "0" + m_com.group(1)
        try:
            comision = round(int(m_com.group(1)) / 100.0, 2)
        except Exception:
            comision = 0

    metodo = "rfnd_v348_posicional_usd2_60_72_cash_tail_cc"
    return cash, cc, cash_field, cc_field, metodo, comision, campo_comision


def parse_rfnd_cash_cc(det):
    """Wrapper compatible con build_beta2."""
    return _rfnd_parse_fixed_usd2(det)


def parse_acma_rfnd_importe(det, doc=None):
    s = str(det)
    if "RFND" in s:
        cash, cc, cash_field, cc_field, metodo, com, campo_com = parse_rfnd_cash_cc(det)
        return cash, cash_field
    if "ACMA" in s:
        return parse_acma_importe(det, doc)
    return None, "tipo_no_acma_rfnd"

def negative_digits_after_dash(raw):
    m = re.search(r"-(0+)(\d+)", str(raw))
    if not m:
        return None, None
    return m.group(2), m.group(0)

def parse_negative_suggest(raw):
    """
    Toma el campo monetario negativo como signo + 11 dígitos.
    Corrige -000000001180... para leer -00000000118 = -1.18.
    """
    val, part = signed_amount_from_chunk(raw, 12)
    return val


def clean_positive_or_regular_amount(field):
    raw = str(field).strip()
    if not raw:
        return None
    if raw.startswith("-"):
        return parse_negative_suggest(raw)
    if not re.fullmatch(r"\d+", raw):
        return None
    if int(raw) == 0:
        return 0.0
    if len(raw) == 11 and raw.endswith("00000") and int(raw[:6]) != 0:
        return int(raw[:6]) / 100
    return int(raw) / 100

def to_cents(x):
    if pd.isna(x):
        return None
    return int(round(float(x) * 100))

def audit_net(det):
    sec = section_after_usd2(det)
    if not sec:
        return None, "", "sin_usd2"
    control = sec[65:86]
    if not re.search(r"[1-9-]", control):
        return 0.0, control, "cero_control_65_85"
    area = sec[40:120]
    neg = re.search(r"-0+\d+", area)
    if neg:
        v = parse_negative_suggest(neg.group(0))
        return (round(v, 2) if v is not None else None), neg.group(0), "posicional_negativo_regla_guion_ceros_4dig"
    for st in [66,65,67,64,68,63,69,62,70]:
        fld = sec[st:st+11]
        if re.fullmatch(r"\d{11}", fld):
            v = clean_positive_or_regular_amount(fld)
            if v is not None and abs(v) > 0:
                return round(v, 2), fld, f"posicional_campo_{st}_{st+10}"
    return None, control, "posicional_no_interpretable"

def find_exact(det, amount):
    c = to_cents(amount)
    if c is None:
        return None, "", "sin_neto_maverick"
    sec = section_after_usd2(det)
    if not sec:
        return None, "", "sin_usd2"
    if c == 0:
        control = sec[65:86]
        if not re.search(r"[1-9-]", control):
            return 0.0, control, "cero_validado_control_65_85"
        return None, control, "maverick_cero_con_control_no_cero"
    area = sec[40:120]
    if c < 0:
        target = str(abs(c))
        for m in re.finditer(r"-0+\d+", area):
            digits, full = negative_digits_after_dash(m.group(0))
            if digits and digits.startswith(target):
                return float(amount), m.group(0), "negativo_exacto_regla_guion_ceros"
        return None, area, "no_encontre_negativo_exacto"
    target = str(abs(c))
    for p in [re.compile(r"0+" + re.escape(target) + r"(?!\d)"), re.compile(r"0+" + re.escape(target) + r"0{2,}"), re.compile(re.escape(target) + r"0{2,}")]:
        m = p.search(area)
        if m:
            return abs(c)/100, m.group(0), "positivo_en_seccion_financiera_40_120"
    v, fld, meth = audit_net(det)
    if v is not None and abs(round(float(v)-float(amount),2)) < 0.01:
        return float(v), fld, "positivo_por_neto_posicional"
    return None, area, "no_encontre_positivo_exacto"

def candidates(det):
    sec = section_after_usd2(det)
    vals = []
    starts = list(range(0, min(len(sec),154), 11)) + [40,45,50,55,60,62,63,64,65,66,67,68,69,70]
    for st in starts:
        fld = sec[st:st+11]
        if re.fullmatch(r"\d{11}", fld):
            v = clean_positive_or_regular_amount(fld)
            if v is not None and 0 < abs(v) < 100000:
                vals.append(round(v,2))
    for m in re.finditer(r"-0+\d+", sec):
        v = parse_negative_suggest(m.group(0))
        if v is not None and abs(v) < 100000:
            vals.append(round(v,2))
    out, seen = [], set()
    for v in vals:
        if v not in seen:
            seen.add(v); out.append(v)
    return out

def period_status(fecha, doc, p0, p1, g0, blocks):
    """
    Antes solo conciliaba día anterior si estaba en TXT.
    Ahora: cualquier fecha Maverick fuera del período IATA se concilia si el documento existe en TXT.
    Si no existe en TXT, queda como fuera de período para no ensuciar No encontrada en IATA.
    """
    if pd.isna(fecha):
        return ""
    if p0 <= fecha <= p1:
        return "DENTRO_PERIODO_IATA"
    return "FUERA_PERIODO_CON_TXT" if doc in blocks else "FUERA_PERIODO_IATA"

def acma_sheet_from_txt(txt_leido):
    rows = []
    for _, r in txt_leido[txt_leido["Tipo TXT"].isin(["ACMA","SPCR"])].iterrows():
        tipo = str(r.get("Tipo TXT",""))
        val, field = parse_acma_importe(r.get("DET TXT",""), str(r.get("Documento IATA","")))
        rows.append({"Documento IATA": r.get("Documento IATA"), "Tipo": tipo, "Aerolínea": r.get("Aerolínea TXT"), "Fecha IATA": r.get("Fecha IATA"), "Importe ACM": val, "": "", "Linea TXT": r.get("Linea TXT"), "Campo usado": field, "DET TXT": r.get("DET TXT")})
    return pd.DataFrame(rows)

def rfnd_sheet_from_txt(txt_leido):
    rows = []
    for _, r in txt_leido[txt_leido["Tipo TXT"] == "RFND"].iterrows():
        cash, cc, com, campo_cash, campo_cc, campo_com, metodo = parse_rfnd_importes(r.get("DET TXT",""), str(r.get("Documento IATA","")))
        doc_iata = str(r.get("Documento IATA",""))
        rows.append({
            "Fecha IATA": r.get("Fecha IATA"),
            "Documento IATA": doc_iata,
            "Tipo": "RFND",
            "Aerolínea": r.get("Aerolínea TXT"),
            "Número de billete": doc_iata,
            "Estado Maverick": "NO EN MAVERICK",
            "Importe Cash": cash,
            "Importe CC": cc,
            "Comisión descontada": com,
            "Campo Cash": campo_cash,
            "Campo CC": campo_cc,
            "Campo Comisión": campo_com,
            "Metodo RFND": metodo,
            "Linea TXT": r.get("Linea TXT"),
            "DET TXT": r.get("DET TXT"),
        })
    return pd.DataFrame(rows)



def read_maverick_excel_file(mav_file):
    """
    Lee el Excel Maveric subido por Streamlit forzando motor.
    Evita: ValueError: Excel file format cannot be determined.
    """
    name = str(getattr(mav_file, "name", "") or "").lower()

    if hasattr(mav_file, "getvalue"):
        raw = mav_file.getvalue()
    else:
        try:
            pos = mav_file.tell()
        except Exception:
            pos = None
        raw = mav_file.read()
        try:
            if pos is not None:
                mav_file.seek(pos)
        except Exception:
            pass

    if name.endswith(".xls") and not name.endswith(".xlsx"):
        engines = ["xlrd", "openpyxl"]
    elif name.endswith(".xlsx") or name.endswith(".xlsm"):
        engines = ["openpyxl", "xlrd"]
    else:
        engines = ["openpyxl", "xlrd"]

    last_error = None
    for engine in engines:
        try:
            return pd.read_excel(io.BytesIO(raw), header=None, engine=engine)
        except Exception as e:
            last_error = e

    raise ValueError(
        "No pude leer el Excel Maveric. Probé openpyxl/xlrd. "
        "Verificá que sea .xls o .xlsx original de Maveric. "
        f"Último error: {last_error}"
    )



# --- Parche v3.3.0: códigos aerolínea especiales ---
try:
    _tuki_airline_from_code_original_v330 = tuki_airline_from_code
    def tuki_airline_from_code(code):
        c = str(code or "").strip().zfill(3)
        if c == "952":
            return "IATA"
        if c == "083":
            return "SOUTH AFRICAN AIRWAYS"
        return _tuki_airline_from_code_original_v330(code)
except Exception:
    pass


# --- Parche v3.3.0: lógica RFND validada ---
def _rfnd_v330_signed_amount(raw):
    s = str(raw or "").strip()
    if not s:
        return None
    sign = -1 if s.startswith("-") else 1
    digits = re.sub(r"\D", "", s)
    if not digits:
        return None
    return sign * (int(digits) / 100.0)

def _rfnd_v330_tokens(det):
    # campos firmados de 11 dígitos usados al final de la línea IATA
    return re.findall(r"-?\d{11}", str(det or ""))

def parse_rfnd_importes(det_txt, documento=""):
    """
    RFND v3.4.8 - función única: devuelve siempre 7 valores.
    Orden histórico: cash, cc, comision, campo_cash, campo_cc, campo_comision, metodo.
    """
    cash, cc, campo_cash, campo_cc, metodo, comision, campo_comision = _rfnd_parse_fixed_usd2(det_txt)
    return cash, cc, comision, campo_cash, campo_cc, campo_comision, metodo


def parse_rfnd_cash_cc(det):
    """Wrapper único para compatibilidad con build_beta2 y hojas RFND."""
    cash, cc, comision, campo_cash, campo_cc, campo_comision, metodo = parse_rfnd_importes(det, "")
    return cash, cc, campo_cash, campo_cc, metodo + "_via_wrapper_v347", comision, campo_comision

def build_beta2(txt_file, mav_file, p0, p1):
    p0 = pd.Timestamp(p0); p1 = pd.Timestamp(p1); g0 = p0 - pd.Timedelta(days=1)
    blocks = parse_txt_blocks(read_txt_file(txt_file))
    mav0 = ensure_maverick_format(read_maverick_excel_file(mav_file))
    required_mav_cols = ["Fecha", "Boleto", "Total a pagar Maverick"]
    missing_mav_cols = [c for c in required_mav_cols if c not in mav0.columns]
    if missing_mav_cols:
        raise ValueError("No pude interpretar el Maveric original. Faltan columnas normalizadas: " + ", ".join(missing_mav_cols))

    fc = "Fecha"; dc = "Boleto"; nc = "Total a pagar Maverick"
    mav = mav0.copy()
    mav["_Fecha Maverick"] = pd.to_datetime(mav[fc], errors="coerce", dayfirst=True)
    mav["_Documento Maverick"] = mav[dc].astype(str).str.extract(r"(\d{10})")
    mav["_Neto Maverick"] = pd.to_numeric(mav[nc], errors="coerce")

    doc_counts = mav["_Documento Maverick"].dropna().value_counts().to_dict()
    doc_seen = {}

    neto_iata_col=[]; diferencia_col=[]; estado_col=[]; tipo_col=[]; aer_col=[]; linea_col=[]; metodo_col=[]; campo_col=[]
    dup_flag_col=[]; cuenta_iata_col=[]; datos_rows=[]

    for _, r in mav.iterrows():
        doc = r["_Documento Maverick"]; neto = r["_Neto Maverick"]; fecha = r["_Fecha Maverick"]
        is_dup = bool(pd.notna(doc) and doc_counts.get(doc, 0) > 1)
        n_seen = doc_seen.get(doc, 0) + 1 if pd.notna(doc) else 1
        if pd.notna(doc):
            doc_seen[doc] = n_seen
        cuenta_iata = (not is_dup) or n_seen == 1

        ep = period_status(fecha, doc, p0, p1, g0, blocks)
        base = {"Fecha Maverick": fecha, "Documento Maverick": doc, "A pagar Maverick": neto, "Tipo TXT": None, "Aerolínea TXT": None, "Fecha IATA": pd.NaT, "Linea TXT": None, "Neto IATA": None, "Diferencia Maverick-IATA": None, "Estado": None, "Estado técnico": None, "Método": "", "Campo control/neto": "", "Importe Cash RFND": None, "Importe CC RFND": None, "Comisión descontada RFND": None, "DET TXT": "", "Bloque TXT": "", "Duplicado Maverick": "SI" if is_dup else "", "Cuenta Neto IATA": "SI" if cuenta_iata else "NO"}

        if pd.isna(doc):
            estado, technical = "NO ENCONTRADO", "SIN_DOCUMENTO_MAVERICK"
        elif ep == "FUERA_PERIODO_IATA":
            estado, technical = "FUERA DE PERIODO", "FUERA_PERIODO_IATA"
        else:
            b = blocks.get(doc)
            if not b:
                estado, technical = "NO ENCONTRADO", "NO EN TXT"
            else:
                tipo = b["Tipo TXT"]
                found, field, method = find_exact(b["DET TXT"], neto)
                aud, afield, ameth = audit_net(b["DET TXT"])
                base.update({"Tipo TXT": tipo, "Aerolínea TXT": b["Aerolínea TXT"], "Fecha IATA": b["Fecha IATA"], "Linea TXT": b["Linea TXT"], "Método": method, "Campo control/neto": field, "DET TXT": b["DET TXT"], "Bloque TXT": b["Bloque TXT"]})

                if tipo in {"ACMA","SPCR"}:
                    val, fld = parse_acma_importe(b["DET TXT"], doc)
                    estado, technical = "ACMA_DETALLE", "ACMA_DETALLE"
                    base["Neto IATA"] = val
                    base["Campo control/neto"] = fld

                elif tipo == "RFND":
                    cash, cc, cash_field, cc_field, metodo_rfnd, comision, campo_com = parse_rfnd_cash_cc(b["DET TXT"])
                    estado, technical = "RFND", "RFND"
                    base["Neto IATA"] = cash
                    base["Importe Cash RFND"] = cash
                    base["Importe CC RFND"] = cc
                    base["Comisión descontada RFND"] = comision
                    base["Método"] = metodo_rfnd
                    base["Campo control/neto"] = cash_field

                elif tipo in {"ADMA","SPDR"}:
                    adm_val, adm_field = parse_adma_importe(b["DET TXT"])
                    base["Neto IATA"] = adm_val
                    base["Campo control/neto"] = adm_field
                    if pd.notna(neto) and adm_val is not None:
                        base["Diferencia Maverick-IATA"] = round(float(neto) - float(adm_val), 2)
                        if abs(base["Diferencia Maverick-IATA"]) <= 0.50:
                            estado, technical = "ADM OK", "ADMA_OK"
                        else:
                            estado, technical = "ADM CON DIFERENCIA", "ADMA_CON_DIFERENCIA"
                    else:
                        estado, technical = "ADM", "ADMA"

                elif tipo in {"CANX","CANN"}:
                    estado = f"{tipo}_DETALLE"
                    technical = estado
                    base["Neto IATA"] = aud

                else:
                    if found is not None:
                        estado = "OK"
                        technical = "OK_CERO" if abs(found)<0.01 and pd.notna(neto) and abs(float(neto))<0.01 else "OK"
                        if ep in {"DIA_ANTERIOR_EN_TXT","FUERA_PERIODO_CON_TXT"}:
                            technical += "_FUERA_PERIODO_IATA"
                        base["Neto IATA"] = found
                        base["Diferencia Maverick-IATA"] = round(float(neto)-float(found),2) if pd.notna(neto) else None
                    else:
                        base["Neto IATA"] = aud
                        base["Diferencia Maverick-IATA"] = round(float(neto)-float(aud),2) if (pd.notna(neto) and aud is not None) else None
                        if base["Diferencia Maverick-IATA"] is not None and abs(base["Diferencia Maverick-IATA"]) <= 0.50:
                            estado = "OK"
                            technical = "OK_TOLERANCIA_050"
                        else:
                            estado = "CON DIFERENCIA"
                            technical = "NO ENCONTRE_COSTO_FUERA_PERIODO_IATA" if ep in {"DIA_ANTERIOR_EN_TXT","FUERA_PERIODO_CON_TXT"} else "NO ENCONTRE COSTO"

        if is_dup and not cuenta_iata and ep != "FUERA_PERIODO_IATA" and base.get("Tipo TXT") not in {"ADMA","SPDR"}:
            # No duplicar cobro IATA para líneas Maverick con mismo ticket/base de 10 dígitos.
            # ADM/SPDR duplicados se concilian después por suma grupal.
            estado = "DUPLICADO MAVERICK"
            technical = "DUPLICADO_MAVERICK_NO_SUMA_IATA"
            base["Neto IATA"] = None
            base["Diferencia Maverick-IATA"] = None
            base["Método"] = "duplicado_maverick_no_suma_iata"

        base["Estado"] = estado
        base["Estado técnico"] = technical
        datos_rows.append(base)

        neto_iata_col.append(base["Neto IATA"])
        diferencia_col.append(base["Diferencia Maverick-IATA"])
        estado_col.append(base["Estado"])
        tipo_col.append(base["Tipo TXT"])
        aer_col.append(base["Aerolínea TXT"])
        linea_col.append(base["Linea TXT"])
        metodo_col.append(base["Método"])
        campo_col.append(base["Campo control/neto"])
        dup_flag_col.append(base["Duplicado Maverick"])
        cuenta_iata_col.append(base["Cuenta Neto IATA"])

    datos_leidos = pd.DataFrame(datos_rows)

    # Reconciliación especial duplicados ADM/SPDR:
    # Si Maverick tiene varias líneas con el mismo documento base y en TXT hay un único ADM/SPDR,
    # se compara la suma Maverick contra el ADM IATA. Si cierra con tolerancia 0.50, todas quedan ADM OK.
    if not datos_leidos.empty and "Documento Maverick" in datos_leidos.columns:
        for d, grp in datos_leidos.groupby("Documento Maverick", dropna=True):
            if pd.isna(d) or len(grp) <= 1:
                continue
            idxs = list(grp.index)
            tipos = grp["Tipo TXT"].fillna("").astype(str).str.upper() if "Tipo TXT" in grp.columns else pd.Series([""]*len(grp), index=grp.index)
            if not tipos.isin(["ADMA","SPDR"]).any():
                continue
            iata_vals = pd.to_numeric(grp.get("Neto IATA"), errors="coerce").dropna().unique()
            if len(iata_vals) == 0:
                continue
            iata_val = float(iata_vals[0])
            mav_sum = float(pd.to_numeric(grp["A pagar Maverick"], errors="coerce").fillna(0).sum())
            diff_group = round(mav_sum - iata_val, 2)
            new_estado = "ADM OK" if abs(diff_group) <= 0.50 else "ADM CON DIFERENCIA"
            new_technical = "ADMA_DUP_GRUPO_OK" if abs(diff_group) <= 0.50 else "ADMA_DUP_GRUPO_CON_DIFERENCIA"
            for n_ix, ix in enumerate(idxs):
                # Solo la primera línea muestra el único Neto IATA. Las otras quedan visibles como parte del grupo.
                datos_leidos.at[ix, "Neto IATA"] = iata_val if n_ix == 0 else None
                datos_leidos.at[ix, "Diferencia Maverick-IATA"] = diff_group if n_ix == 0 else None
                datos_leidos.at[ix, "Estado"] = new_estado
                datos_leidos.at[ix, "Estado técnico"] = new_technical
                datos_leidos.at[ix, "Método"] = "adm_duplicado_maverick_conciliado_por_suma"
                datos_leidos.at[ix, "Cuenta Neto IATA"] = "SI" if n_ix == 0 else "NO"



    main = mav0.copy()
    main["Total a pagar Maverick"] = pd.to_numeric(main["Total a pagar Maverick"], errors="coerce").fillna(0.0)
    # Las columnas se toman desde datos_leidos para incorporar ajustes grupales ADM duplicados.
    neto_iata_col = datos_leidos["Neto IATA"].tolist()
    diferencia_col = datos_leidos["Diferencia Maverick-IATA"].tolist()
    estado_col = datos_leidos["Estado"].tolist()
    tipo_col = datos_leidos["Tipo TXT"].tolist()
    aer_col = datos_leidos["Aerolínea TXT"].tolist()
    linea_col = datos_leidos["Linea TXT"].tolist()
    metodo_col = datos_leidos["Método"].tolist()
    campo_col = datos_leidos["Campo control/neto"].tolist()
    dup_flag_col = datos_leidos["Duplicado Maverick"].tolist()
    cuenta_iata_col = datos_leidos["Cuenta Neto IATA"].tolist()
    main["Neto IATA"] = neto_iata_col
    main["Diferencia Maverick-IATA"] = diferencia_col
    main["Estado"] = estado_col
    main["Tipo TXT"] = tipo_col
    main["Aerolínea TXT"] = aer_col
    main["Línea TXT"] = linea_col
    main["Método"] = metodo_col
    main["Campo control/neto"] = campo_col
    main["Duplicado Maverick"] = dup_flag_col
    main["Cuenta Neto IATA"] = cuenta_iata_col
    main["Estado RFND Maverick"] = ""
    try:
        mask_rfnd_main = main["Tipo TXT"].fillna("").astype(str).str.upper().eq("RFND")
        main.loc[mask_rfnd_main, "Estado RFND Maverick"] = "RFND en Maveric"
    except Exception:
        pass

    txt_rows=[]
    for doc, b in blocks.items():
        aud, afield, ameth = audit_net(b.get("DET TXT",""))
        adma_val=adma_field=acma_val=acma_field=rfnd_cash=rfnd_cc=rfnd_cash_field=rfnd_cc_field=rfnd_method=comision=campo_com=None
        if b["Tipo TXT"] in {"ADMA","SPDR"}:
            adma_val, adma_field = parse_adma_importe(b.get("DET TXT",""))
            aud, afield = adma_val, adma_field
        if b["Tipo TXT"] in {"ACMA","SPCR"}:
            acma_val, acma_field = parse_acma_importe(b.get("DET TXT",""), doc)
        if b["Tipo TXT"] == "RFND":
            rfnd_cash, rfnd_cc, rfnd_cash_field, rfnd_cc_field, rfnd_method, comision, campo_com = parse_rfnd_cash_cc(b.get("DET TXT",""))
        txt_rows.append({"Documento IATA": doc, "Tipo TXT": b["Tipo TXT"], "Aerolínea TXT": b["Aerolínea TXT"], "Fecha IATA": b["Fecha IATA"], "Linea TXT": b["Linea TXT"], "Neto posicional auditoría": aud, "Importe ADM": adma_val, "Importe ACM": acma_val, "Campo ACM": acma_field, "Importe Cash RFND": rfnd_cash, "Importe CC RFND": rfnd_cc, "Comisión descontada RFND": comision, "Campo Cash RFND": rfnd_cash_field, "Campo CC RFND": rfnd_cc_field, "Campo Comisión RFND": campo_com, "Metodo RFND": rfnd_method, "Metodo neto posicional": ameth, "Campo control/neto": afield, "Candidatos DET": " | ".join(f"{x:.2f}" for x in candidates(b.get("DET TXT",""))[:80]), "DET TXT": b.get("DET TXT"), "Bloque TXT": b.get("Bloque TXT")})
    txt_leido = pd.DataFrame(txt_rows)

    mav_docs = set(mav["_Documento Maverick"].dropna())
    not_in_mav = txt_leido[~txt_leido["Documento IATA"].isin(mav_docs)].copy()
    faltan_en_maverick = not_in_mav[~not_in_mav["Tipo TXT"].isin(["ADMA","SPDR","ACMA","SPCR","CANX","CANN","RFND"])].copy()
    acma_sheet = acma_sheet_from_txt(txt_leido)
    rfnd_sheet = rfnd_sheet_from_txt(txt_leido)
    # Ajuste final de estados Maverick:
    # - dentro del período y sin TXT: NO ENCONTRADO EN IATA
    # - fuera del período y sin TXT: FUERA DE PERIODO
    try:
        fecha_main = pd.to_datetime(main["Fecha"], errors="coerce")
        mask_no = main["Estado"].astype(str).eq("NO ENCONTRADO")
        mask_in_period = fecha_main.between(p0, p1)
        main.loc[mask_no & mask_in_period, "Estado"] = "NO ENCONTRADO EN IATA"
        main.loc[mask_no & ~mask_in_period, "Estado"] = "FUERA DE PERIODO"
    except Exception:
        pass

    # Duplicados Maverick: no considerar duplicados fuera del período que no estén en TXT.
    try:
        fecha_main = pd.to_datetime(main["Fecha"], errors="coerce")
        mask_fuera_sin_txt = main["Estado"].astype(str).eq("FUERA DE PERIODO")
        main.loc[mask_fuera_sin_txt, "Duplicado Maverick"] = ""
        main.loc[mask_fuera_sin_txt, "Cuenta Neto IATA"] = "NO"
    except Exception:
        pass

    duplicados_maverick = main[main["Duplicado Maverick"].astype(str).eq("SI")].copy()

    resumen = pd.DataFrame([
        ["Periodo IATA desde", p0], ["Periodo IATA hasta", p1],
        ["Total filas Maverick originales", len(mav0)], ["OK", int((main["Estado"]=="OK").sum())],
        ["CON DIFERENCIA", int((main["Estado"]=="CON DIFERENCIA").sum())],
        ["ADM OK", int((main["Estado"]=="ADM OK").sum())],
        ["ADM CON DIFERENCIA", int((main["Estado"]=="ADM CON DIFERENCIA").sum())],
        ["DUPLICADO MAVERICK", int((main["Estado"]=="DUPLICADO MAVERICK").sum())],
        ["NO ENCONTRADO EN IATA", int((main["Estado"]=="NO ENCONTRADO EN IATA").sum())],
        ["FUERA DE PERIODO", int((main["Estado"]=="FUERA DE PERIODO").sum())], ["ADMA", int((txt_leido["Tipo TXT"].isin(["ADMA","SPDR"])).sum())],
        ["RFND", int((txt_leido["Tipo TXT"]=="RFND").sum())], ["ACMA/SPCR", int((txt_leido["Tipo TXT"].isin(["ACMA","SPCR"])).sum())],
        ["Faltan en Maverick TKTT/EMD", len(faltan_en_maverick)]
    ], columns=["Concepto","Cantidad"])

    return {
        "Resumen": resumen,
        "Espejo maverick conciliado": main,
        "Con_Diferencia": main[main["Estado"].isin(["CON DIFERENCIA","ADM CON DIFERENCIA"])].copy(),
        "No encontrada en periodo IATA": main[main["Estado"]=="NO ENCONTRADO EN IATA"].copy(),
        "Fuera de Periodo IATA": main[main["Estado"]=="FUERA DE PERIODO"].copy(),
        "Duplicados_Maverick": duplicados_maverick,
        "Faltan_en_Maverick": faltan_en_maverick,
        "TKTT": txt_leido[txt_leido["Tipo TXT"]=="TKTT"].copy(),
        "RFND": rfnd_sheet,
        "ACMA": acma_sheet,
        "ADMA": txt_leido[txt_leido["Tipo TXT"].isin(["ADMA","SPDR"])].copy(),
        "CANX": txt_leido[txt_leido["Tipo TXT"]=="CANX"].copy(),
        "CANN": txt_leido[txt_leido["Tipo TXT"]=="CANN"].copy(),
        "EMDS": txt_leido[txt_leido["Tipo TXT"]=="EMDS"].copy(),
        "EMDA": txt_leido[txt_leido["Tipo TXT"]=="EMDA"].copy(),
        "Control_ACMA_RFND": txt_leido[txt_leido["Tipo TXT"].isin(["ACMA","SPCR","RFND"])].copy(),
        "TXT_Leido": txt_leido,
        "Datos_leidos": datos_leidos,
    }


# ============================
# CAPA CONTABLE TUKI v2.8
# No toca la lógica de conciliación. Solo ordena hojas, columnas y resumen.
# ============================

AIR_NUM_TUKI = {
    "001":"American Airlines","006":"Delta Air Lines","014":"Air Canada","016":"United Airlines",
    "044":"Aerolineas Argentinas","045":"LATAM Airlines Group","047":"TAP Air Portugal","057":"Air France","071":"Ethiopian Airlines",
    "075":"IBERIA","125":"British Airways","127":"GOL Linhas Aereas","134":"Avianca","139":"Aeromexico",
    "157":"Qatar Airways","169":"Hahnair","176":"Emirates","220":"Lufthansa","230":"COPA Airlines",
    "235":"Turkish Airlines","275":"APG Airlines","291":"Euroairlines","365":"FlexFlight","445":"Paranair",
    "577":"Azul Brazilian Airlines","589":"Jet Airways","605":"SKY","633":"Código 633",
    "973":"JetSmart","996":"Air Europa"
}
AIR_ALPHA_TUKI = {
    "AA":"American Airlines","AC":"Air Canada","AD":"Azul Brazilian Airlines","AF":"Air France",
    "AM":"Aeromexico","AR":"Aerolineas Argentinas","AV":"Avianca","BA":"British Airways",
    "CM":"COPA Airlines","DL":"Delta Air Lines","EK":"Emirates","G3":"GOL Linhas Aereas",
    "GP":"APG Airlines","H2":"SKY","IB":"IBERIA","JJ":"LATAM Airlines Brasil",
    "LA":"LATAM Airlines Group","LH":"Lufthansa","LP":"LATAM Airlines Peru","PZ":"LATAM Airlines Paraguay",
    "QR":"Qatar Airways","TK":"Turkish Airlines","UA":"United Airlines","UX":"Air Europa",
    "W2":"FlexFlight","XL":"LATAM Airlines Ecuador","ZP":"Paranair"
}

def tuki_airline_from_code(code):
    if code is None or str(code).strip() == "":
        return "NO COMPAÑIA"
    c = str(code).strip().upper()
    if c.isdigit():
        c = c.zfill(3)
        return AIR_NUM_TUKI.get(c, f"FALTA NOMBRE {c}")
    return AIR_ALPHA_TUKI.get(c, f"FALTA NOMBRE {c}")

def tuki_code_from_boleto(v):
    s = str(v or "").strip().upper()
    if "ADM" in s or "-" not in s:
        return None
    m = re.match(r"^([A-Z0-9]{2,3})-", s)
    return m.group(1) if m else None

def tuki_doc_digits(v):
    s = str(v or "")
    m = re.search(r"(\d{10,13})", s)
    return m.group(1) if m else ""

def tuki_det_code(row):
    for col in ["Código compañía", "Codigo compañía", "Codigo compania", "Código", "Codigo", "Sigla"]:
        if col in row.index and pd.notna(row.get(col)):
            raw = str(row.get(col)).strip().upper()
            if raw:
                if raw in {"JA", "0JA"}:
                    return "JA"
                if raw.isdigit():
                    return raw.zfill(3)
                return raw
    if "Aerolínea" in row.index and pd.notna(row.get("Aerolínea")):
        val = str(row.get("Aerolínea")).strip().upper()
        if val in {"JA", "0JA"}:
            return "JA"
        if val.isdigit():
            return val.zfill(3)
    for k in ["DET TXT", "Linea TXT", "Línea TXT"]:
        if k in row.index and pd.notna(row.get(k)):
            m = re.search(r"DET(\d{3})", str(row.get(k)))
            if m:
                return m.group(1)
    return None

def tuki_emitido_en(row):
    txt = ""
    for k in ["DET TXT", "Linea TXT", "Línea TXT"]:
        if k in row.index and pd.notna(row.get(k)):
            txt += " " + str(row.get(k)).upper()
    if "WEB" in txt or "FLGXBSP" in txt:
        return "WEB"
    if "BSP" in txt:
        return "BSP"
    return "???"

def tuki_drop_cols(df, cols):
    return df.drop(columns=[c for c in cols if c in df.columns], errors="ignore")

def tuki_move_to_end(df, cols):
    present = [c for c in cols if c in df.columns]
    return df[[c for c in df.columns if c not in present] + present]


def tuki_rfnd_boleto_from_line(row):
    txt = ""
    for k in ["DET TXT", "Linea TXT", "Línea TXT"]:
        if k in row.index and pd.notna(row.get(k)):
            txt += " " + str(row.get(k))
    m = re.search(r"RF(\d{3})(\d{10})", txt)
    return m.group(2) if m else ""

def tuki_order_cols(df, desired):
    return df[[c for c in desired if c in df.columns] + [c for c in df.columns if c not in desired]]

def tuki_rename_first(df, names, new_name):
    df = df.copy()
    for n in names:
        if n in df.columns:
            return df.rename(columns={n:new_name})
    return df


def tuki_add_airline_mav(df):
    df = df.copy()
    for c in list(df.columns):
        if str(c).strip().lower() in {
            "aerolínea","aerolinea","aerolínea nombre","aerolinea nombre",
            "código compañía","codigo compañía","codigo compania","aerolínea txt","aerolinea txt"
        }:
            df = df.drop(columns=[c])
    names = []
    if len(df):
        for _, row in df.iterrows():
            tipo = str(row.get("Tipo TXT","")).upper()
            estado = str(row.get("Estado","")).upper()
            boleto = row.get("Boleto")
            if "ADM" in tipo or "ADM" in estado:
                names.append("ADM")
            elif "Boleto" in df.columns:
                code = tuki_code_from_boleto(boleto)
                names.append(tuki_airline_from_code(code) if code else "NO COMPAÑIA")
            else:
                names.append("NO COMPAÑIA")
    if "Estado" in df.columns:
        idx = list(df.columns).index("Estado") + 1
        df.insert(idx, "Aerolínea", names)
    else:
        df["Aerolínea"] = names
    return df


def tuki_add_airline_iata(df):
    df = df.copy()
    for c in list(df.columns):
        if str(c).strip().lower() in {"aerolínea","aerolinea","aerolínea nombre","aerolinea nombre","aerolínea txt","aerolinea txt"}:
            df = df.drop(columns=[c])
    names = [tuki_airline_from_code(tuki_det_code(row)) for _, row in df.iterrows()]
    if "Código compañía" in df.columns:
        idx = list(df.columns).index("Código compañía") + 1
    elif "Documento IATA" in df.columns:
        idx = list(df.columns).index("Documento IATA") + 1
    else:
        idx = min(3, len(df.columns))
    df.insert(idx, "Aerolínea", names)
    return df

def tuki_numeric_sum(df, col):
    if df is None or col not in df.columns:
        return 0.0
    return float(pd.to_numeric(df[col], errors="coerce").fillna(0).sum())



# --- Parche v3.3.3: normalización final de códigos de compañía ---
def _tuki_fix_airline_name_by_code_final(row):
    # Busca código en columnas típicas o en documento/DET.
    code = ""
    for col in ["Código Aerolínea", "Codigo Aerolinea", "Código", "Codigo", "Prefijo", "Aerolínea Código"]:
        try:
            val = row.get(col, "")
            if pd.notna(val) and str(val).strip():
                code = str(val).strip().zfill(3)[-3:]
                break
        except Exception:
            pass

    if not code:
        # Si no hay columna código, intentar extraerlo del DET TXT: RF/AC/SP + 3 dígitos, o DET + 3 dígitos.
        txt_det = str(row.get("DET TXT", "") or row.get("Linea TXT", "") or "")
        m = re.search(r"(?:RF|AC|AD|SP)(\d{3})", txt_det)
        if not m:
            m = re.search(r"^DET(\d{3})", txt_det)
        if m:
            code = m.group(1)

    if code == "083":
        return "SOUTH AFRICAN AIRWAYS"
    if code == "952":
        return "IATA"

    try:
        current = row.get("Aerolínea", row.get("Aerolínea TXT", ""))
        if isinstance(current, str) and current.strip().upper().startswith("FALTA NOMBRE"):
            c2 = re.sub(r"\D", "", current)
            if c2.endswith("083"):
                return "SOUTH AFRICAN AIRWAYS"
            if c2.endswith("952"):
                return "IATA"
    except Exception:
        pass

    return None

def _tuki_apply_airline_code_fixes(df):
    try:
        if df is None or df.empty:
            return df
        out = df.copy()
        target_cols = [c for c in ["Aerolínea", "Aerolínea TXT", "Compañia Aerea", "Compañía aérea"] if c in out.columns]
        if not target_cols:
            return out
        target = target_cols[0]
        for idx, row in out.iterrows():
            fixed = _tuki_fix_airline_name_by_code_final(row)
            if fixed:
                out.at[idx, target] = fixed
        return out
    except Exception:
        return df

# Reforzar función principal si existe.
try:
    _tuki_airline_from_code_base_333 = tuki_airline_from_code
    def tuki_airline_from_code(code):
        c = str(code or "").strip().zfill(3)
        if c == "083":
            return "SOUTH AFRICAN AIRWAYS"
        if c == "952":
            return "IATA"
        return _tuki_airline_from_code_base_333(code)
except Exception:
    pass



# --- Parche v3.3.4: JA = Jetsmart / código 973 ---
try:
    _tuki_airline_from_code_base_334 = tuki_airline_from_code
    def tuki_airline_from_code(code):
        c_raw = str(code or "").strip().upper()
        c = c_raw.zfill(3)
        if c_raw == "JA" or c == "973":
            return "Jetsmart"
        if c == "083":
            return "SOUTH AFRICAN AIRWAYS"
        if c == "952":
            return "IATA"
        return _tuki_airline_from_code_base_334(code)
except Exception:
    pass

try:
    _tuki_apply_airline_code_fixes_base_334 = _tuki_apply_airline_code_fixes
    def _tuki_apply_airline_code_fixes(df):
        out = _tuki_apply_airline_code_fixes_base_334(df)
        try:
            if out is None or out.empty:
                return out
            target_cols = [c for c in ["Aerolínea", "Aerolínea TXT", "Compañia Aerea", "Compañía aérea"] if c in out.columns]
            if not target_cols:
                return out
            target = target_cols[0]
            for idx, row in out.iterrows():
                vals = " ".join([str(row.get(c, "")) for c in out.columns if c in ["Aerolínea", "Aerolínea TXT", "DET TXT", "Linea TXT", "Código", "Codigo", "Código Aerolínea"]])
                vals_u = vals.upper()
                if "FALTA NOMBRE JA" in vals_u or re.search(r"\bJA\b", vals_u):
                    out.at[idx, target] = "Jetsmart"
                if "FALTA NOMBRE 973" in vals_u or re.search(r"DET973|RF973|AC973|AD973|SP973", vals_u):
                    out.at[idx, target] = "Jetsmart"
                if "FALTA NOMBRE 083" in vals_u or re.search(r"DET083|RF083|AC083|AD083|SP083", vals_u):
                    out.at[idx, target] = "SOUTH AFRICAN AIRWAYS"
                if "FALTA NOMBRE 952" in vals_u or re.search(r"DET952|RF952|AC952|AD952|SP952", vals_u):
                    out.at[idx, target] = "IATA"
            return out
        except Exception:
            return out
except Exception:
    pass



# --- Parche v3.3.5: normalización definitiva de compañías ---
def _tuki_company_fixed_name(code_or_text):
    """
    FIX v3.3.6:
    No usar terminaciones de documento/boleto para mapear compañía.
    Solo mapear si viene como código explícito o patrón DET/RF/AC/AD/SP.
    """
    s = str(code_or_text or "").strip().upper()
    s_clean = s.replace("FALTA NOMBRE", "").strip()
    if s in {"JA", "0JA"} or s_clean in {"JA", "0JA"} or "JA-" in s or re.fullmatch(r"JA", s_clean or ""):
        return "Jetsmart"
    if re.search(r"(?:DET|RF|AC|AD|SP)973", s):
        return "Jetsmart"
    if re.search(r"(?:DET|RF|AC|AD|SP)083", s):
        return "SOUTH AFRICAN AIRWAYS"
    if re.search(r"(?:DET|RF|AC|AD|SP)952", s):
        return "IATA"
    if s_clean == "973":
        return "Jetsmart"
    if s_clean == "083":
        return "SOUTH AFRICAN AIRWAYS"
    if s_clean == "952":
        return "IATA"
    return None


def _tuki_apply_company_names_final(df):
    try:
        if df is None or df.empty:
            return df
        out = df.copy()
        target_cols = [c for c in ["Aerolínea", "Aerolínea TXT", "Compañia Aerea", "Compañía aérea", "Compañía"] if c in out.columns]
        if not target_cols:
            return out
        target = target_cols[0]
        scan_cols = [c for c in [
            "Código compañía", "Codigo compañía", "Codigo compania", "Código", "Codigo", "Sigla",
            "Aerolínea", "Aerolínea TXT", "Compañia Aerea", "Compañía aérea", "Compañía",
            "DET TXT", "Linea TXT", "Línea TXT", "Boleto", "Documento IATA", "Número de billete"
        ] if c in out.columns]
        for idx, row in out.iterrows():
            fixed = None
            for col in scan_cols:
                fixed = _tuki_company_fixed_name(row.get(col, ""))
                if fixed:
                    break
            if fixed:
                out.at[idx, target] = fixed
        # reemplazo de texto por si quedó en otra columna visible
        for col in out.columns:
            if out[col].dtype == object:
                out[col] = out[col].replace({
                    "FALTA NOMBRE JA": "Jetsmart",
                    "FALTA NOMBRE 0JA": "Jetsmart",
                    "FALTA NOMBRE 973": "Jetsmart",
                    "FALTA NOMBRE 083": "SOUTH AFRICAN AIRWAYS",
                    "FALTA NOMBRE 952": "IATA",
                })
        return out
    except Exception:
        return df



# --- Parche v3.3.6: totales finales por hoja ---
def _tuki_norm_col_name(c):
    return re.sub(r"[^a-z0-9]", "", str(c or "").lower())

def _tuki_find_col(df, candidates):
    norm_map = {_tuki_norm_col_name(c): c for c in df.columns}
    for cand in candidates:
        n = _tuki_norm_col_name(cand)
        if n in norm_map:
            return norm_map[n]
    for cand in candidates:
        n = _tuki_norm_col_name(cand)
        for k, real in norm_map.items():
            if n and (n in k or k in n):
                return real
    return None

def _tuki_add_total_row(df, columns_to_sum):
    try:
        if df is None or df.empty:
            return df
        out = df.copy()
        cols = []
        for cand_list in columns_to_sum:
            col = _tuki_find_col(out, cand_list if isinstance(cand_list, (list, tuple)) else [cand_list])
            if col and col in out.columns and col not in cols:
                cols.append(col)
        if not cols:
            return out
        total = {c: "" for c in out.columns}
        if len(out.columns) > 0:
            total[out.columns[0]] = "TOTAL"
        for col in cols:
            vals = pd.to_numeric(out[col], errors="coerce")
            total[col] = float(vals.sum(skipna=True))
        return pd.concat([out, pd.DataFrame([total])], ignore_index=True)
    except Exception:
        return df

def _tuki_apply_total_rows_to_sheets(out):
    try:
        if not isinstance(out, dict):
            return out
        rules = {
            "espejo": [
                ["Monto tarjeta", "Monto Tarjeta", "Monto tarjeta Maverick"],
                ["Costo de Res.", "Costo reserva", "Costo reserva Maverick"],
                ["Total a pagar Maverick", "Total a pagar Maveric"],
                ["Neto IATA", "Neto IATA según Maverick", "A pagar IATA"],
                ["Diferencia", "Diferencia Maverick-IATA"],
            ],
            "diferencias": [
                ["Monto tarjeta", "Monto Tarjeta", "Monto tarjeta Maverick"],
                ["Costo de Res.", "Costo reserva", "Costo reserva Maverick"],
                ["Total a pagar Maverick", "Total a pagar Maveric"],
                ["Neto IATA", "Neto IATA según Maverick", "A pagar IATA"],
                ["Diferencia", "Diferencia Maverick-IATA"],
            ],
            "duplicados": [
                ["Monto tarjeta", "Monto Tarjeta", "Monto tarjeta Maverick"],
                ["Costo de Res.", "Costo reserva", "Costo reserva Maverick"],
                ["Total a pagar Maverick", "Total a pagar Maveric"],
                ["Neto IATA", "Neto IATA según Maverick", "A pagar IATA"],
                ["Diferencia", "Diferencia Maverick-IATA"],
            ],
            "faltan": [["Neto a pagar", "Neto IATA", "A pagar IATA"]],
            "rfnd": [["Importe Cash", "RFND Cash"], ["Importe CC", "RFND CC"]],
            "adm": [["Importe ADM", "Total ADM", "ADM"]],
            "adms": [["Importe ADM", "Total ADM", "ADM"]],
            "acm": [["Importe ACM", "Total ACM", "ACM"]],
            "acma": [["Importe ACM", "Total ACM", "ACM"]],
        }
        for name in list(out.keys()):
            if not isinstance(out[name], pd.DataFrame):
                continue
            lname = str(name).lower()
            selected = None
            # avoid resumen/pivot sheets
            if "resumen" in lname:
                continue
            for key, cols in rules.items():
                if key in lname:
                    selected = cols
                    break
            if selected:
                # do not add twice
                df = out[name]
                if not df.empty and str(df.iloc[-1,0]).upper() == "TOTAL":
                    continue
                out[name] = _tuki_add_total_row(df, selected)
        return out
    except Exception:
        return out



# --- Parche v3.4.0: RFND no se deduplica por documento ---

# --- Parche v3.4.1: RFND usando la línea DET exacta ---
def _tuki_split_det_lines_v341(text):
    """
    Divide un bloque que puede traer:
    DET...TKTT...
    DET...RFND...
    en líneas DET individuales. Importante para no tomar TKTT como RFND.
    """
    s = str(text or "")
    parts = re.split(r"(?=DET\d{3})", s)
    return [p.strip() for p in parts if p.strip().startswith("DET")]

def _tuki_doc_rfnd_from_line_v340(line):
    m = re.search(r"RFND(\d{10})", str(line or ""))
    return m.group(1) if m else ""

def _tuki_find_sheet_v340(sheets, names):
    for n in names:
        for k in sheets.keys():
            if str(k).strip().lower() == n.strip().lower():
                return k
    return None

def _tuki_force_all_rfnd_from_txt_v340(sheets):
    """
    Un mismo documento puede aparecer como TKTT y RFND.
    Para RFND SIEMPRE tomar la sublínea DET que contiene RFND,
    nunca el bloque completo ni la línea TKTT.
    """
    try:
        if not isinstance(sheets, dict):
            return sheets
        txt_key = _tuki_find_sheet_v340(sheets, ["TXT_Leido","TXT Leido","TXT leído","IATA LEÍDO","IATA_LEIDO"])
        if txt_key is None:
            return sheets
        txt_df = sheets.get(txt_key)
        if txt_df is None or not isinstance(txt_df, pd.DataFrame) or txt_df.empty:
            return sheets

        rfnd_key = _tuki_find_sheet_v340(sheets, ["RFND"])
        if rfnd_key is None:
            rfnd_key = "RFND"
            sheets[rfnd_key] = pd.DataFrame()
        rfnd_df = sheets.get(rfnd_key)
        if rfnd_df is None or not isinstance(rfnd_df, pd.DataFrame):
            rfnd_df = pd.DataFrame()

        existing = set()
        if not rfnd_df.empty:
            for _, rr in rfnd_df.iterrows():
                doc = ""
                for c in ["Documento IATA", "Número de billete", "Documento"]:
                    if c in rfnd_df.columns and str(rr.get(c, "")).strip():
                        doc = re.sub(r"\D", "", str(rr.get(c, "")))
                        break
                line = ""
                for c in ["DET TXT", "Linea TXT", "Línea TXT"]:
                    if c in rfnd_df.columns and str(rr.get(c, "")).strip():
                        line = str(rr.get(c, ""))
                        break
                for det_line in _tuki_split_det_lines_v341(line):
                    if "RFND" in det_line:
                        existing.add(("RFND", doc, det_line[:160]))

        add = []
        for _, r in txt_df.iterrows():
            raw = ""
            for c in ["DET TXT", "Linea TXT", "Línea TXT", "Raw TXT", "Linea"]:
                if c in txt_df.columns and str(r.get(c, "")).strip():
                    raw = str(r.get(c, ""))
                    break

            # Puede venir bloque multi-DET; tomar solo DET...RFND.
            det_lines = _tuki_split_det_lines_v341(raw)
            if not det_lines and "RFND" in raw:
                det_lines = [raw]

            for det_line in det_lines:
                if "RFND" not in det_line:
                    continue
                doc = _tuki_doc_rfnd_from_line_v340(det_line)
                if not doc:
                    continue
                key = ("RFND", doc, det_line[:160])
                if key in existing:
                    continue

                cash, cc, com, campo_cash, campo_cc, campo_com, metodo = parse_rfnd_importes(det_line, doc)
                add.append({
                    "Fecha IATA": r.get("Fecha IATA", r.get("Fecha", "")),
                    "Documento IATA": doc,
                    "Tipo": "RFND",
                    "Aerolínea": r.get("Aerolínea TXT", r.get("Aerolínea", "")),
                    "Número de billete": doc,
                    "Estado Maverick": "RFND Fuera de Maveric",
                    "Importe Cash": cash,
                    "Importe CC": cc,
                    "Comisión descontada": com,
                    "Campo Cash": campo_cash,
                    "Campo CC": campo_cc,
                    "Campo Comisión": campo_com,
                    "Metodo RFND": metodo,
                    "Linea TXT": r.get("Linea TXT", r.get("Línea TXT", "")),
                    "DET TXT": det_line,
                })
                existing.add(key)

        if add:
            add_df = pd.DataFrame(add)
            if not rfnd_df.empty:
                for c in add_df.columns:
                    if c not in rfnd_df.columns:
                        rfnd_df[c] = ""
                for c in rfnd_df.columns:
                    if c not in add_df.columns:
                        add_df[c] = ""
                add_df = add_df[rfnd_df.columns]
                sheets[rfnd_key] = pd.concat([rfnd_df, add_df], ignore_index=True)
            else:
                sheets[rfnd_key] = add_df
        return sheets
    except Exception:
        return sheets


def tuki_prepare_output_sheets(sheets):
    try:
        sheets = _tuki_force_all_rfnd_from_txt_v340(sheets)
    except Exception:
        pass

    out = {}
    # Pasar hojas opcionales ya armadas antes de la capa contable.
    if "Resumen IATA" in sheets:
        out["Resumen IATA"] = sheets["Resumen IATA"].copy()

    if "Resumen" in sheets:
        out["Resumen"] = sheets["Resumen"].copy()

    mav_desired = ["Fecha","Boleto","Sistema","Ciudad de Emision","Agente Emisor","Pasajero","Reserva","Forma de Pago",
                   "Monto Tarjeta"," Costo de Res.","Total a pagar Maverick","Neto IATA",
                   "Diferencia Maverick-IATA","Estado","Estado RFND Maverick","Aerolínea","Duplicado Maverick","Cuenta Neto IATA"]

    for src, dst in [
        ("Espejo maverick conciliado","Espejo Maverick"),
        ("Con_Diferencia","Diferencias"),
        ("No encontrada en periodo IATA","No encontrada en periodo IATA"),
        ("Fuera de Periodo IATA","Fuera de Periodo IATA"),
        ("Duplicados_Maverick","Duplicados Maverick"),
    ]:
        if src in sheets:
            out[dst] = tuki_order_cols(tuki_add_airline_mav(sheets[src].copy()), mav_desired)

    # Estado Maverick, para ADM/RFND/ACM
    esp_tmp = out.get("Espejo Maverick", pd.DataFrame())
    estado_map = {}
    if not esp_tmp.empty and "Boleto" in esp_tmp.columns and "Estado" in esp_tmp.columns:
        for _, row in esp_tmp.iterrows():
            d = tuki_doc_digits(row.get("Boleto"))
            if d:
                estado_map[d] = row.get("Estado")

    def add_estado_mav(df):
        df = df.copy()
        vals = []
        tipo_series = None
        if "Tipo" in df.columns:
            tipo_series = df["Tipo"].astype(str).str.upper()
        elif "Tipo TXT" in df.columns:
            tipo_series = df["Tipo TXT"].astype(str).str.upper()
        is_rfnd_df = bool(tipo_series.eq("RFND").any()) if tipo_series is not None else False
        is_adm_df = bool(tipo_series.isin(["ADMA","SPDR"]).any()) if tipo_series is not None else False
        for i, row in df.iterrows():
            d = tuki_doc_digits(row.get("Documento IATA") if "Documento IATA" in df.columns else row.iloc[0])
            raw_estado = estado_map.get(d, "NO EN MAVERICK")
            tipo_row = str(tipo_series.loc[i]) if tipo_series is not None and i in tipo_series.index else ""
            if tipo_row == "RFND" or is_rfnd_df:
                vals.append("RFND en Maveric" if raw_estado != "NO EN MAVERICK" else "RFND Fuera de Maveric")
            elif tipo_row in {"ADMA","SPDR"} or is_adm_df:
                vals.append(raw_estado if raw_estado != "NO EN MAVERICK" else "ADM FUERA DE MAVERIC")
            else:
                vals.append(raw_estado)
        insert_at = list(df.columns).index("Aerolínea") + 1 if "Aerolínea" in df.columns else min(5, len(df.columns))
        if "Estado Maverick" in df.columns:
            df["Estado Maverick"] = vals
        else:
            df.insert(insert_at, "Estado Maverick", vals)
        return df

    # Falta en Maverick
    if "Faltan_en_Maverick" in sheets:
        df = tuki_add_airline_iata(sheets["Faltan_en_Maverick"].copy())
        df = tuki_rename_first(df, ["Neto posicional auditoría","Neto a Pagar","Neto a pagar"], "Neto a pagar")
        df.insert(3, "Emitido en:", [tuki_emitido_en(row) for _, row in df.iterrows()])
        df = tuki_drop_cols(df, ["Importe ACM","Campo ACM","Importe Cash RFND","Importe CC RFND",
                                 "Comisión descontada RFND","Campo Cash RFND","Campo CC RFND","Campo Comisión RFND","Metodo RFND"])
        df = tuki_move_to_end(df, ["Linea TXT","DET TXT","Candidatos DET","Metodo neto posicional","Campo control/neto"])
        out["Falta en Maverick"] = tuki_order_cols(df, ["Fecha IATA","Documento IATA","Tipo","Emitido en:","Código compañía","Aerolínea","Neto a pagar"])

    # RFND
    if "RFND" in sheets:
        df = tuki_add_airline_iata(sheets["RFND"].copy())
        if "Número de billete" not in df.columns:
            insert_at = list(df.columns).index("Aerolínea") + 1 if "Aerolínea" in df.columns else min(5, len(df.columns))
            df.insert(insert_at, "Número de billete", [tuki_rfnd_boleto_from_line(row) for _, row in df.iterrows()])
        df = add_estado_mav(df)
        df = tuki_move_to_end(df, ["Linea TXT","DET TXT"])
        out["RFND"] = tuki_order_cols(df, ["Fecha IATA","Documento IATA","Tipo","Código compañía","Aerolínea","Número de billete","Estado Maverick",
                                           "Importe Cash","Importe CC","Comisión descontada","Campo Cash","Campo CC","Campo Comisión","Metodo RFND"])

    # ADM
    if "ADMA" in sheets or "SPDR" in sheets:
        df = tuki_add_airline_iata(pd.concat([sheets[x].copy() for x in ["ADMA","SPDR"] if x in sheets], ignore_index=True))
        df = add_estado_mav(df)
        df = tuki_rename_first(df, ["Importe ADM","Neto posicional auditoría"], "Importe ADM")
        df = tuki_drop_cols(df, ["Importe ACM","Campo ACM","Importe Cash RFND","Importe CC RFND",
                                 "Comisión descontada RFND","Campo Cash RFND","Campo CC RFND","Campo Comisión RFND","Metodo RFND"])
        df = tuki_move_to_end(df, ["Linea TXT","DET TXT","Candidatos DET","Metodo neto posicional","Campo control/neto"])
        out["ADM"] = tuki_order_cols(df, ["Fecha IATA","Documento IATA","Tipo","Código compañía","Aerolínea","Estado Maverick","Importe ADM"])

    # ACM
    if "ACMA" in sheets:
        df = tuki_add_airline_iata(sheets["ACMA"].copy())
        df = add_estado_mav(df)
        df = tuki_rename_first(df, ["Importe ACM","Neto posicional auditoría"], "Importe ACM")
        df = tuki_move_to_end(df, ["Linea TXT","DET TXT","Campo usado"])
        out["ACM"] = tuki_order_cols(df, ["Fecha IATA","Documento IATA","Tipo","Código compañía","Aerolínea","Estado Maverick","Importe ACM"])

    # TKTT
    if "TKTT" in sheets:
        esp_ok_tktt = out.get("Espejo Maverick", pd.DataFrame())
        if not esp_ok_tktt.empty and "Tipo TXT" in esp_ok_tktt.columns and "Estado" in esp_ok_tktt.columns:
            ok_docs = set(esp_ok_tktt[
                esp_ok_tktt["Tipo TXT"].fillna("").astype(str).str.upper().eq("TKTT")
                & esp_ok_tktt["Estado"].fillna("").astype(str).str.upper().eq("OK")
            ]["Boleto"].astype(str).str.extract(r"(\d{10})")[0].dropna())
            df = sheets["TKTT"].copy()
            if "Documento IATA" in df.columns and ok_docs:
                df = df[df["Documento IATA"].astype(str).isin(ok_docs)].copy()
            df = tuki_add_airline_iata(df)
        else:
            df = tuki_add_airline_iata(sheets["TKTT"].copy())
        df = tuki_rename_first(df, ["Neto a Pagar","Neto a pagar","Neto posicional auditoría"], "Neto IATA")
        fp_map, mt_map = {}, {}
        esp = out.get("Espejo Maverick", pd.DataFrame())
        if not esp.empty and "Boleto" in esp.columns:
            for _, row in esp.iterrows():
                d = tuki_doc_digits(row.get("Boleto"))
                if d:
                    fp_map[d] = row.get("Forma de Pago")
                    mt_map[d] = row.get("Monto Tarjeta")
        docs = df["Documento IATA"].astype(str) if "Documento IATA" in df.columns else pd.Series([""]*len(df))
        df["Forma de Pago"] = docs.map(fp_map)
        df["Monto Tarjeta"] = docs.map(mt_map)
        df = tuki_drop_cols(df, ["Importe ACM","Campo ACM","Importe Cash RFND","Importe CC RFND",
                                 "Comisión descontada RFND","Campo Cash RFND","Campo CC RFND","Campo Comisión RFND","Metodo RFND"])
        df = tuki_move_to_end(df, ["Linea TXT","DET TXT","Candidatos DET","Metodo neto posicional","Campo control/neto"])
        out["TKTT"] = tuki_order_cols(df, ["Fecha IATA","Documento IATA","Tipo","Código compañía","Aerolínea","Forma de Pago","Monto Tarjeta","Neto IATA"])

    # EMDS + EMDA
    emds = []
    for nm in ["EMDS","EMDA"]:
        if nm in sheets:
            x = sheets[nm].copy()
            if "Tipo" in x.columns:
                x["Tipo"] = nm
            else:
                x.insert(1, "Tipo", nm)
            emds.append(x)
    if emds:
        df = tuki_add_airline_iata(pd.concat(emds, ignore_index=True))
        df = tuki_rename_first(df, ["Importe EMD","Neto posicional auditoría","Neto a Pagar"], "Importe EMD")
        df = tuki_drop_cols(df, ["Linea TXT","Importe ACM","Campo ACM","Importe Cash RFND","Importe CC RFND",
                                 "Comisión descontada RFND","Campo Cash RFND","Campo CC RFND","Campo Comisión RFND","Metodo RFND"])
        df = tuki_move_to_end(df, ["DET TXT","Candidatos DET","Metodo neto posicional","Campo control/neto"])
        out["EMDS"] = tuki_order_cols(df, ["Fecha IATA","Documento IATA","Tipo","Código compañía","Aerolínea","Importe EMD"])

    # CANX + CANN
    canx = []
    for nm in ["CANX","CANN"]:
        if nm in sheets:
            x = sheets[nm].copy()
            if "Tipo" in x.columns:
                x["Tipo"] = nm
            else:
                x.insert(1, "Tipo", nm)
            canx.append(x)
    if canx:
        df = tuki_add_airline_iata(pd.concat(canx, ignore_index=True))
        df = tuki_drop_cols(df, ["Linea TXT","Importe ACM","Campo ACM","Importe Cash RFND","Importe CC RFND",
                                 "Comisión descontada RFND","Campo Cash RFND","Campo CC RFND","Campo Comisión RFND","Metodo RFND","Neto posicional auditoría"])
        df = tuki_move_to_end(df, ["DET TXT","Candidatos DET","Metodo neto posicional","Campo control/neto"])
        out["CANX"] = tuki_order_cols(df, ["Fecha IATA","Documento IATA","Tipo","Código compañía","Aerolínea"])

    # Resumen contable
    esp = out.get("Espejo Maverick", pd.DataFrame())
    rfnd = out.get("RFND", pd.DataFrame())
    acm = out.get("ACM", pd.DataFrame())
    adm = out.get("ADM", pd.DataFrame())

    if not esp.empty and "Estado" in esp.columns:
        estados = esp["Estado"].fillna("").astype(str).str.upper()
        base_mask = estados.isin(["OK","CON DIFERENCIA","ADM OK","ADM CON DIFERENCIA"])
        ok_mask = estados.str.contains("OK", na=False)
        esp_base = esp[base_mask].copy()
        esp_ok = esp[ok_mask].copy()
    else:
        esp_base = esp.copy()
        esp_ok = esp.copy()

    monto_tarjeta_mav = tuki_numeric_sum(esp_base, "Monto Tarjeta")
    costo_res_mav = tuki_numeric_sum(esp_base, " Costo de Res.")
    neto_iata_mav = tuki_numeric_sum(esp_base, "Neto IATA")
    tkts_adms_pagar_iata = tuki_numeric_sum(esp_ok, "Neto IATA")
    total_rfnd_cash = tuki_numeric_sum(rfnd, "Importe Cash")
    total_rfnd_cc = tuki_numeric_sum(rfnd, "Importe CC")
    total_adm = tuki_numeric_sum(adm, "Importe ADM")
    total_spdr = 0.0
    if not adm.empty and "Importe ADM" in adm.columns:
        if "Tipo" in adm.columns:
            total_spdr = pd.to_numeric(adm.loc[adm["Tipo"].astype(str).str.upper().eq("SPDR"), "Importe ADM"], errors="coerce").fillna(0).sum()
        elif "Tipo TXT" in adm.columns:
            total_spdr = pd.to_numeric(adm.loc[adm["Tipo TXT"].astype(str).str.upper().eq("SPDR"), "Importe ADM"], errors="coerce").fillna(0).sum()
    total_acm = tuki_numeric_sum(acm, "Importe ACM")
    total_a_pagar_iata = tkts_adms_pagar_iata + total_rfnd_cash + total_acm

    total_informado_pdf = sheets.get("_TOTAL_INFORMADO_IATA_PDF", "")
    # Normalización final de nombres de aerolínea por código 083/952 en todas las hojas.
    try:
        for _k in list(out.keys()):
            if isinstance(out[_k], pd.DataFrame):
                out[_k] = _tuki_apply_airline_code_fixes(out[_k])
    except Exception:
        pass

    try:
        for _k in list(out.keys()):
            if isinstance(out[_k], pd.DataFrame):
                out[_k] = _tuki_apply_company_names_final(out[_k])
    except Exception:
        pass

    # Agregar filas de totales al final de hojas de datos.
    try:
        out = _tuki_apply_total_rows_to_sheets(out)
    except Exception:
        pass

    resumen_contable = pd.DataFrame([
        ["Monto tarjeta Maverick (OK/ADM OK/Con diferencia)", monto_tarjeta_mav],
        ["Costo reserva Maverick (OK/ADM OK/Con diferencia)", costo_res_mav],
        ["Neto IATA según Maverick (OK/ADM OK/Con diferencia)", neto_iata_mav],
        ["Tkts y ADMS a Pagar Iata", tkts_adms_pagar_iata],
        ["Total refunds Cash", total_rfnd_cash],
        ["Total refunds CC", total_rfnd_cc],
        ["Total ADM", total_adm],
        ["Total SPDR informativo - ya incluido en Tkts y ADMS", total_spdr],
        ["Total ACM", total_acm],
        ["", ""],
        ["TOTAL A PAGAR EN IATA calculado por el conciliador", total_a_pagar_iata],
        ["TOTAL informado por IATA", total_informado_pdf],
        ["Diferencia de la Semana", ""],
        ["", ""],
        ["* Nota: TOTAL A PAGAR EN IATA calculado = Tkts y ADMS a Pagar Iata + refunds Cash + ACM. SPDR queda informativo porque ya está incluido en Tkts y ADMS.", ""],
    ], columns=["Concepto","Importe"])

    if not esp.empty and "Aerolínea" in esp.columns:
        pivot = esp.groupby("Aerolínea", dropna=False).agg(
            **{
                "Monto tarjeta": ("Monto Tarjeta","sum"),
                "Costo reserva": (" Costo de Res.","sum"),
                "Neto IATA": ("Neto IATA","sum"),
                "Diferencia": ("Diferencia Maverick-IATA","sum"),
                "Cantidad billetes": ("Boleto","count")
            }
        ).reset_index()
        pivot = pivot.sort_values("Monto tarjeta", ascending=False).reset_index(drop=True)
        pivot = pd.concat([pivot, pd.DataFrame([{
            "Aerolínea":"TOTAL",
            "Monto tarjeta": pivot["Monto tarjeta"].sum(),
            "Costo reserva": pivot["Costo reserva"].sum(),
            "Neto IATA": pivot["Neto IATA"].sum(),
            "Diferencia": pivot["Diferencia"].sum(),
            "Cantidad billetes": pivot["Cantidad billetes"].sum()
        }])], ignore_index=True)
    else:
        pivot = pd.DataFrame()

    return out, resumen_contable, pivot



def normalize_maverick_original(df):
    """
    Maveric original sin títulos, por coordenadas fijas EXACTAS:
      A Fecha -> índice 0
      B Documento/Boleto -> índice 1
      D Ciudad emisión -> índice 3
      E Agente emisor -> índice 4
      F Pasajero -> índice 5
      G Forma de pago -> índice 6
      H Monto tarjeta -> índice 7
      J Reserva -> índice 9
      K Costo reserva -> índice 10
      L Sistema -> índice 11
      M Total a pagar Maverick -> índice 12
    C se ignora.
    """
    raw = df.copy()

    def colpos(idx):
        return raw.iloc[:, idx] if raw.shape[1] > idx else pd.Series([None] * len(raw))

    out = pd.DataFrame({
        "Fecha": colpos(0),
        "Boleto": colpos(1),
        "Ciudad de Emision": colpos(3),
        "Agente Emisor": colpos(4),
        "Pasajero": colpos(5),
        "Forma de Pago": colpos(6),
        "Monto Tarjeta": colpos(7),
        "Reserva": colpos(9),
        " Costo de Res.": colpos(10),
        "Sistema": colpos(11),
        "Total a pagar Maverick": colpos(12),
    })

    out = out.dropna(how="all")
    out = out[out["Boleto"].notna()]
    out["Boleto"] = out["Boleto"].astype(str).str.strip()
    out = out[(out["Boleto"] != "") & (~out["Boleto"].str.lower().isin(["nan", "none"]))]
    out = out[~out["Boleto"].str.upper().isin(["DOCUMENTO", "BOLETO", "DOCUMENTO/BOLETO"])]

    out["Fecha"] = pd.to_datetime(out["Fecha"], errors="coerce")
    for c in ["Monto Tarjeta", " Costo de Res.", "Total a pagar Maverick"]:
        out[c] = pd.to_numeric(out[c], errors="coerce").fillna(0.0)

    out["Forma de Pago"] = out["Forma de Pago"].fillna("").astype(str).str.strip()
    out.loc[(out["Forma de Pago"] == "") & (out["Monto Tarjeta"].fillna(0) == 0), "Forma de Pago"] = "CASH"
    return out


def ensure_maverick_format(df):
    # En esta versión NO se autodetectan encabezados: Maveric original siempre por coordenadas.
    return normalize_maverick_original(df)






# =========================
# Resumen IATA PDF opcional
# =========================




def _iata_pdf_num(x):
    if x is None:
        return 0.0
    s = str(x).strip().replace(",", "")
    if s in {"", "-", "None", "nan"}:
        return 0.0
    try:
        return float(s)
    except Exception:
        return 0.0

def _iata_pdf_text(pdf_file):
    if pdf_file is None:
        return "", "SIN_PDF"
    try:
        raw = pdf_file.getvalue() if hasattr(pdf_file, "getvalue") else pdf_file.read()
    except Exception as e:
        return "", f"NO_PUDE_LEER_BYTES: {e}"

    errors = []
    for modname in ("pypdf", "PyPDF2"):
        try:
            if modname == "pypdf":
                from pypdf import PdfReader
                reader = PdfReader(io.BytesIO(raw))
                # layout mantiene mejor columnas y evita mezclar encabezados con compañías
                text = "\n".join([(page.extract_text(extraction_mode="layout") or "") for page in reader.pages])
            else:
                from PyPDF2 import PdfReader
                reader = PdfReader(io.BytesIO(raw))
                text = "\n".join([(page.extract_text() or "") for page in reader.pages])
            if text.strip():
                return text, f"OK_{modname}"
            errors.append(f"{modname}: texto vacío")
        except Exception as e:
            errors.append(f"{modname}: {e}")
    return "", " | ".join(errors)

def _money_tokens(s):
    return re.findall(r"-?\d[\d,]*\.\d{2}", str(s or ""))

def _doc_count_from_block(block_lines):
    joined = " ".join(block_lines)
    # patrones como "39,134.54 8", "3EFECTIVO", "8CREDITO"
    candidates = []
    for ln in block_lines:
        for m in re.finditer(r"\.\d{2}\s+(\d{1,4})(?=\s|$)", ln):
            candidates.append(int(m.group(1).replace(",", "")))
        for m in re.finditer(r"(?<![\d.,])(\d{1,4})\s*(?:EFECTIVO|CREDITO)\b", ln, re.I):
            candidates.append(int(m.group(1).replace(",", "")))
    return candidates[-1] if candidates else 0

def _agent_total_from_text(text):
    # Fuente oficial del total informado: AGENT ... TOTAL / GRAND TOTAL.
    lines = [ln.strip() for ln in str(text or "").splitlines() if ln.strip()]
    for ln in reversed(lines):
        up = ln.upper()
        if ("AGENT" in up and "TOTAL" in up) or ("GRAND TOTAL" in up) or up.startswith("TOTAL"):
            vals = [_iata_pdf_num(x) for x in _money_tokens(ln)]
            if len(vals) >= 8:
                return float(vals[-1])
    # fallback global: buscar todas las líneas TOTAL con muchos importes y usar la última columna neto
    candidates = []
    for ln in lines:
        up = ln.upper()
        if "TOTAL" in up:
            vals = [_iata_pdf_num(x) for x in _money_tokens(ln)]
            if len(vals) >= 8:
                candidates.append(float(vals[-1]))
    return candidates[-1] if candidates else None

PDF_AIR_NAMES = {
    "001": "American Airlines",
    "006": "Delta Air Lines Inc.",
    "016": "United Airlines Inc",
    "044": "Aerolineas Argentinas S.A.",
    "045": "LATAM Airlines Group SA dba La",
    "057": "Air France",
    "071": "Ethiopian Airlines dba Ethiopi",
    "075": "Iberia Lineas Aereas de Espana",
    "127": "GOL Linhas Aereas S/A dba GOL",
    "134": "Aerovias del Continente Americ",
    "139": "Aerovias de Mexico SA de CV db",
    "169": "Hahn Air Lines GmbH",
    "176": "Emirates",
    "220": "Lufthansa",
    "230": "Compania Panamena de Aviacion,",
    "235": "Turkish Airlines Inc",
    "275": "APG Airlines",
    "365": "FlexFlight ApS",
    "445": "Compania De Aviacion Paraguaya",
    "577": "Azul Linhas Aereas Brasileiras",
    "605": "Sky Airline S.A.",
    "799": "International Air Transport As",
    "973": "JETSMART AIRLINES SpA",
    "996": "Air Europa Lineas Aereas, S.A.",
}

def _pdf_air_name(code, sigla, fallback=""):
    code = str(code or "").zfill(3)
    if code in PDF_AIR_NAMES:
        return PDF_AIR_NAMES[code]
    try:
        name = tuki_airline_from_code(code)
        if name and not str(name).startswith("FALTA"):
            return name
    except Exception:
        pass
    return str(fallback or "").strip()

def parse_iata_summary_pdf(pdf_file):
    """
    Parser FCAGBILLSUMNG usando layout text.
    Compañía por código, total informado desde PDF oficial.
    """
    cols = ["Categoria","Codigo","Sigla","Compañia","FOP","Cash","CC","Total",
            "RFND Cash","RFND CC","RFND Total","ADMS","ACM","Tasas y Cargos",
            "Monto Cash","Taxs sin Comi","Neto a pagar","Cantidad de docs"]
    totals_cols = ["Concepto","FOP","Cash","CC","Total","RFND Cash","RFND CC","RFND Total",
                   "ADMS","ACM","Tasas y Cargos","Monto Cash","Taxs sin Comi","Neto a pagar","Cantidad de docs"]

    text, diag = _iata_pdf_text(pdf_file)
    if not text.strip():
        if pdf_file is None:
            return pd.DataFrame(columns=cols), pd.DataFrame(columns=totals_cols), None, "SIN_PDF"
        df_diag = pd.DataFrame([{
            "Categoria":"ERROR","Codigo":"","Sigla":"",
            "Compañia":f"No pude leer texto del PDF. Diagnóstico: {diag}",
            "FOP":"","Cash":0.0,"CC":0.0,"Total":0.0,"RFND Cash":0.0,"RFND CC":0.0,"RFND Total":0.0,
            "ADMS":0.0,"ACM":0.0,"Tasas y Cargos":0.0,"Monto Cash":0.0,"Taxs sin Comi":0.0,"Neto a pagar":0.0,"Cantidad de docs":0
        }])
        return df_diag, pd.DataFrame(columns=totals_cols), None, diag

    lines = [ln.rstrip() for ln in text.splitlines() if ln.strip()]
    code_re = re.compile(r"^\s*(\d{3})\s+([A-Z0-9]{2})\b(.*)$")
    code_indices = []
    for i, ln in enumerate(lines):
        if code_re.match(ln):
            code_indices.append(i)

    rows = []
    total_oficial = _agent_total_from_text(text)

    def current_category(before_idx):
        cat = ""
        for j in range(before_idx, -1, -1):
            s = lines[j].strip()
            if s.startswith("CATEGORY "):
                cat = s.replace("CATEGORY", "").strip()
                break
        return cat

    for pos, i in enumerate(code_indices):
        m = code_re.match(lines[i])
        if not m:
            continue
        code, sigla, rest = m.group(1), m.group(2), m.group(3)
        # ignorar falsos positivos de encabezados
        if str(rest).upper().startswith(("NOMBRE", "FOP", "DEBITO", "CREDITO Y CARGOS")):
            continue

        next_i = code_indices[pos+1] if pos+1 < len(code_indices) else len(lines)
        block = lines[i:next_i]
        # cortar antes de totales / nueva categoría
        clean_block = []
        for ln in block:
            up = ln.strip().upper()
            if up.startswith(("COMBINED TOTALS", "BSP TOTAL", "WEBSALES-EDIS TOTAL", "AGENT ", "GRAND TOTAL", "CATEGORY ")):
                break
            # sacar encabezados/pies de página de la lectura
            if "FCAGBILLSUMNG AGENT BILLING SUMMARY" in up:
                continue
            if "PAGE :" in up and len(_money_tokens(ln)) == 0:
                continue
            clean_block.append(ln)
        block = clean_block
        if not block:
            continue

        cat = current_category(i)
        first_vals = [_iata_pdf_num(x) for x in _money_tokens(block[0])]
        all_lines = " ".join(block).upper()
        cash = cc = rf_cash = rf_cc = 0.0
        total_vals = None
        single_tail = None

        # línea de inicio: generalmente trae cash/rfnd cash
        if first_vals:
            if "CREDITO" in block[0].upper() and "EFECTIVO" not in block[0].upper():
                # caso crédito puro mal alineado; a veces emisión aparece al final
                if len(first_vals) >= 7 and first_vals[-2] > 0:
                    cc = first_vals[-2]
                    rf_cc = first_vals[-1] if len(first_vals) > 1 else 0.0
                    single_tail = first_vals[0:-2]
                else:
                    cc = first_vals[0]
                    rf_cc = first_vals[1] if len(first_vals) > 1 else 0.0
                    single_tail = first_vals[2:] if len(first_vals) > 2 else None
            else:
                cash = first_vals[0]
                rf_cash = first_vals[1] if len(first_vals) > 1 else 0.0
                if "EFECTIVO" in block[0].upper() and len(first_vals) > 2:
                    single_tail = first_vals[2:]

        for ln in block[1:]:
            up = ln.upper().strip()
            vals = [_iata_pdf_num(x) for x in _money_tokens(ln)]
            if up.startswith("CREDITO") or "CREDITO" in up:
                if vals:
                    # normal: CREDITO 154,137.28 -900.00
                    # crédito puro mal alineado: varios campos y emisión al final
                    if len(vals) >= 7 and vals[-2] > 0 and (vals[0] == 0 or vals[0] < vals[-2]):
                        cc = vals[-2]
                        rf_cc = vals[-1] if len(vals) > 1 else 0.0
                        single_tail = vals[0:-2]
                    else:
                        cc = vals[0]
                        rf_cc = vals[1] if len(vals) > 1 else 0.0
                        if len(vals) > 2:
                            single_tail = vals[2:]
                continue
            if up.startswith("EFECTIVO") or "EFECTIVO" in up:
                if vals:
                    # efectivo puro con todo en la misma línea: docs pueden aparecer pegados antes de EFECTIVO
                    if cash == 0 and rf_cash == 0:
                        cash = vals[0]
                        rf_cash = vals[1] if len(vals) > 1 else 0.0
                        if len(vals) > 2:
                            single_tail = vals[2:]
                    elif len(vals) >= 6:
                        single_tail = vals
                continue
            if up.startswith("TOTAL"):
                total_vals = vals
                continue

        if total_vals:
            total = total_vals[0] if len(total_vals) > 0 else cash + cc
            rf_total = total_vals[1] if len(total_vals) > 1 else rf_cash + rf_cc
            adms = total_vals[2] if len(total_vals) > 2 else 0.0
            acm = total_vals[3] if len(total_vals) > 3 else 0.0
            tasas = total_vals[4] if len(total_vals) > 4 else 0.0
            monto_cash = total_vals[5] if len(total_vals) > 5 else 0.0
            tax_sin_comi = total_vals[6] if len(total_vals) > 6 else 0.0
            neto = total_vals[7] if len(total_vals) > 7 else 0.0
            docs = _doc_count_from_block([ln for ln in block if ln.strip().upper().startswith("TOTAL")])
        else:
            tail = single_tail or []
            total = cash + cc
            rf_total = rf_cash + rf_cc
            adms = tail[0] if len(tail) > 0 else 0.0
            acm = tail[1] if len(tail) > 1 else 0.0
            tasas = tail[2] if len(tail) > 2 else 0.0
            monto_cash = tail[3] if len(tail) > 3 else 0.0
            tax_sin_comi = tail[4] if len(tail) > 4 else 0.0
            neto = tail[5] if len(tail) > 5 else cash + rf_cash + adms + acm - monto_cash
            docs = _doc_count_from_block(block)

        rows.append({
            "Categoria": cat,
            "Codigo": str(code).zfill(3),
            "Sigla": sigla,
            "Compañia": _pdf_air_name(code, sigla),
            "FOP": "TOTAL",
            "Cash": round(cash, 2),
            "CC": round(cc, 2),
            "Total": round(total, 2),
            "RFND Cash": round(rf_cash, 2),
            "RFND CC": round(rf_cc, 2),
            "RFND Total": round(rf_total, 2),
            "ADMS": round(adms, 2),
            "ACM": round(acm, 2),
            "Tasas y Cargos": round(tasas, 2),
            "Monto Cash": round(monto_cash, 2),
            "Taxs sin Comi": round(tax_sin_comi, 2),
            "Neto a pagar": round(neto, 2),
            "Cantidad de docs": int(docs or 0)
        })

    df = pd.DataFrame(rows, columns=cols)
    if not df.empty:
        # excluir filas claramente vacías
        df = df[~((pd.to_numeric(df["Total"], errors="coerce").fillna(0).eq(0)) & (pd.to_numeric(df["Neto a pagar"], errors="coerce").fillna(0).eq(0)) & (pd.to_numeric(df["ADMS"], errors="coerce").fillna(0).eq(0)))]
        df = df.sort_values("Total", ascending=False).reset_index(drop=True)
        total_row = {"Categoria": "TOTAL", "Codigo": "", "Sigla": "", "Compañia": "TOTAL", "FOP": ""}
        for c in cols:
            if c in ["Cash","CC","Total","RFND Cash","RFND CC","RFND Total","ADMS","ACM","Tasas y Cargos","Monto Cash","Taxs sin Comi","Neto a pagar","Cantidad de docs"]:
                total_row[c] = pd.to_numeric(df[c], errors="coerce").fillna(0).sum()
        if total_oficial is not None:
            # Este es el dato oficial del PDF; evita que una mala extracción de una línea desvíe el total informado.
            total_row["Neto a pagar"] = float(total_oficial)
        for c in cols:
            total_row.setdefault(c, "")
        df = pd.concat([df, pd.DataFrame([total_row])], ignore_index=True)

    total_informado = total_oficial
    if total_informado is None and not df.empty:
        mask_total = df["Compañia"].astype(str).eq("TOTAL")
        if mask_total.any():
            total_informado = float(pd.to_numeric(df.loc[mask_total, "Neto a pagar"], errors="coerce").fillna(0).iloc[0])

    if pdf_file is not None and df.empty:
        sample = " | ".join(lines[:15])[:1000]
        df = pd.DataFrame([{
            "Categoria":"ERROR","Codigo":"","Sigla":"",
            "Compañia":f"PDF leído ({diag}) pero no parseé compañías. Muestra: {sample}",
            "FOP":"","Cash":0.0,"CC":0.0,"Total":0.0,"RFND Cash":0.0,"RFND CC":0.0,"RFND Total":0.0,
            "ADMS":0.0,"ACM":0.0,"Tasas y Cargos":0.0,"Monto Cash":0.0,"Taxs sin Comi":0.0,"Neto a pagar":0.0,"Cantidad de docs":0
        }])

    return df, pd.DataFrame(columns=totals_cols), total_informado, diag


def excel_bytes(sheets):
    out, resumen_contable, pivot = tuki_prepare_output_sheets(sheets)
    output = io.BytesIO()

    order = ["Resumen","Resumen Contable","Resumen IATA","Espejo Maverick","Diferencias","Falta en Maverick",
             "No encontrada en periodo IATA","Fuera de Periodo IATA","Duplicados Maverick","RFND","ADM","ACM","TKTT","EMDS","CANX"]

    with pd.ExcelWriter(output, engine="xlsxwriter", datetime_format="ddmmmyy", date_format="ddmmmyy") as writer:
        wb = writer.book
        fmt_header = wb.add_format({"bold":True,"bg_color":"#1F4E78","font_color":"white","border":1,"align":"center"})
        fmt_cell_border = wb.add_format({"border":1})
        fmt_money_border = wb.add_format({"border":1, "num_format":"#,##0.00;[Red]-#,##0.00;-"})
        fmt_total_border = wb.add_format({"border":1, "bold":True, "bg_color":"#D9EAD3", "num_format":"#,##0.00;[Red]-#,##0.00;-"})
        fmt_total_text_border = wb.add_format({"border":1, "bold":True, "bg_color":"#D9EAD3"})
        fmt_money = wb.add_format({"num_format":"#,##0.00;[Red]-#,##0.00;-", "font_size":12})
        fmt_date = wb.add_format({"num_format":"ddmmmyy"})
        fmt_text = wb.add_format({})
        fmt_total = wb.add_format({"bold":True,"bg_color":"#D9EAD3","num_format":"#,##0.00;[Red]-#,##0.00;-", "font_size":12})
        fmt_total_label = wb.add_format({"bold":True,"bg_color":"#D9EAD3"})
        fmt_yellow = wb.add_format({"bg_color":"#FFF2CC","num_format":"#,##0.00;[Red]-#,##0.00;-"})
        fmt_red = wb.add_format({"bg_color":"#FFC7CE"})
        fmt_estado_ok = wb.add_format({"bg_color":"#E2F0D9"})
        fmt_estado_diff = wb.add_format({"bg_color":"#FCE4D6", "font_color":"#C00000"})
        fmt_estado_no = wb.add_format({"bg_color":"#FFF2CC"})
        fmt_estado_fuera = wb.add_format({"bg_color":"#D9EAF7"})
        fmt_emitido_web = wb.add_format({"bg_color":"#EADCF8"})
        fmt_emitido_bsp = wb.add_format({"bg_color":"#DDEBF7"})
        fmt_ok = wb.add_format({"bg_color":"#E2F0D9"})
        fmt_diff = wb.add_format({"bg_color":"#FCE4D6", "font_color":"#C00000"})
        fmt_no = wb.add_format({"bg_color":"#FFF2CC"})
        fmt_fuera = wb.add_format({"bg_color":"#D9EAF7"})
        fmt_web = wb.add_format({"bg_color":"#EADCF8"})
        fmt_bsp = wb.add_format({"bg_color":"#DDEBF7"})
        fmt_title = wb.add_format({"bold":True,"font_size":14,"font_color":"#1F4E78"})
        fmt_note = wb.add_format({"italic": True, "font_color": "#666666"})
        fmt_semana_label = wb.add_format({"bold": True, "font_size": 14, "bg_color": "#D9D9D9", "border": 2, "align": "center", "valign": "vcenter"})
        fmt_int = wb.add_format({"num_format":"#,##0;[Red]-#,##0;-", "font_size":12})
        fmt_int_border = wb.add_format({"border":1, "num_format":"#,##0;[Red]-#,##0;-"})

        fmt_diff_label_resumen = wb.add_format({"bold": True, "font_size": 14, "bg_color": "#D9D9D9", "border": 2, "align": "center", "valign": "vcenter"})
        fmt_semana_ok = wb.add_format({"bold": True, "font_size": 14, "font_color": "#006100", "bg_color": "#C6EFCE", "align":"center", "valign":"vcenter", "border":2, "num_format":"#,##0.00;[Red]-#,##0.00;-"})
        fmt_diff_rojo_resumen = wb.add_format({"bold": True, "font_size": 14, "font_color": "#9C0006", "bg_color": "#FFC7CE", "align":"center", "valign":"vcenter", "border":2, "num_format":"#,##0.00;[Red]-#,##0.00;-"})
        fmt_diff_zero_resumen = wb.add_format({"bold": True, "font_size": 14, "font_color": "#006100", "bg_color": "#C6EFCE", "num_format":"#,##0.00;[Red]-#,##0.00;-"})
        fmt_diff_bad_resumen = wb.add_format({"bold": True, "font_size": 14, "font_color": "#006100", "bg_color": "#C6EFCE", "num_format":"#,##0.00;[Red]-#,##0.00;-"})

        total_cols = {
            "Espejo Maverick":["Monto Tarjeta"," Costo de Res.","Total a pagar Maverick","Neto IATA","Diferencia Maverick-IATA"],
            "Diferencias":["Monto Tarjeta"," Costo de Res.","Total a pagar Maverick","Neto IATA","Diferencia Maverick-IATA"],
            "Falta en Maverick":["Neto a pagar"],
            "No encontrada en periodo IATA":["Monto Tarjeta"," Costo de Res.","Total a pagar Maverick"],
            "Fuera de Periodo IATA":["Monto Tarjeta"," Costo de Res.","Total a pagar Maverick","Neto IATA","Diferencia Maverick-IATA"],
            "RFND":["Importe Cash","Importe CC"],
            "ADM":["Importe ADM"],
            "ACM":["Importe ACM"],
            "TKTT":["Monto Tarjeta","Neto IATA"],
            "EMDS":["Importe EMD"],
        }

        for name in order:
            df = resumen_contable if name == "Resumen Contable" else out.get(name)
            if df is None:
                continue

            df.to_excel(writer, sheet_name=name[:31], index=False)
            ws = writer.sheets[name[:31]]

            # v3.3.6: marcar fila TOTAL en negrita y formato numérico
            try:
                total_fmt_v336 = writer.book.add_format({"bold": True, "num_format": "#,##0.00;[Red]-#,##0.00;-"})
                total_label_fmt_v336 = writer.book.add_format({"bold": True})
                if len(df) > 0 and str(df.iloc[-1, 0]).upper() == "TOTAL":
                    total_excel_row = len(df)  # header is row 0; last df row is len(df)
                    ws.write(total_excel_row, 0, "TOTAL", total_label_fmt_v336)
                    for _c_idx, _c_name in enumerate(df.columns):
                        if _c_idx == 0:
                            continue
                        _v = df.iloc[-1, _c_idx]
                        if pd.notna(_v) and isinstance(_v, (int, float)):
                            ws.write_number(total_excel_row, _c_idx, float(_v), total_fmt_v336)
                        elif pd.notna(_v) and str(_v) != "":
                            ws.write(total_excel_row, _c_idx, _v, total_label_fmt_v336)
            except Exception:
                pass

            for c,h in enumerate(df.columns):
                ws.write(0,c,h,fmt_header)
                hlow = str(h).lower()
                if "fecha" in hlow:
                    ws.set_column(c,c,12,fmt_date)
                elif "cantidad" in hlow or "docs" in hlow:
                    ws.set_column(c,c,14,fmt_int)
                elif any(k in hlow for k in ["monto","costo","total","neto","diferencia","importe","cash","cc"]) and "campo" not in hlow and "comisión" not in hlow and "comision" not in hlow:
                    ws.set_column(c,c,16,fmt_money)
                elif "aerolínea" in hlow:
                    ws.set_column(c,c,28,fmt_text)
                else:
                    vals = df[h].dropna().astype(str).head(100).tolist() if h in df.columns else []
                    ws.set_column(c,c,min(max([len(str(h))]+[len(x) for x in vals])+2,60),fmt_text)

            if name == "Resumen IATA" and len(df):
                ws.set_column(0, 3, 24)
                ws.set_column(4, 4, 10)
                ws.set_column(5, len(df.columns)-1, 18)
                # Bordes en toda la tabla y fila TOTAL destacada.
                numeric_cols_ri = {"Cash","CC","Total","RFND Cash","RFND CC","RFND Total","ADMS","ACM","Tasas y Cargos","Monto Cash","Taxs sin Comi","Neto a pagar","Cantidad de docs"}
                for rr in range(1, len(df)+1):
                    is_total_row = str(df.iloc[rr-1].get("Compañia","")).upper() == "TOTAL"
                    for cc_i, col_name in enumerate(df.columns):
                        val = df.iloc[rr-1, cc_i]
                        if col_name == "Cantidad de docs":
                            try:
                                ws.write_number(rr, cc_i, int(float(val or 0)), fmt_total_border if is_total_row else fmt_int_border)
                            except Exception:
                                ws.write(rr, cc_i, val, fmt_total_text_border if is_total_row else fmt_cell_border)
                        elif col_name in numeric_cols_ri:
                            try:
                                ws.write_number(rr, cc_i, float(val or 0), fmt_total_border if is_total_row else fmt_money_border)
                            except Exception:
                                ws.write(rr, cc_i, val, fmt_total_border if is_total_row else fmt_cell_border)
                        else:
                            ws.write(rr, cc_i, val, fmt_total_text_border if is_total_row else fmt_cell_border)

            if name == "Resumen Contable":
                ws.set_column(0,0,90)
                ws.set_column(1,1,18)
                idx_calc = df.index[df["Concepto"].astype(str).str.contains("TOTAL A PAGAR EN IATA calculado", case=False, na=False)][0] + 2
                idx_info = df.index[df["Concepto"].eq("TOTAL informado por IATA")][0] + 2
                diff_rows = df.index[df["Concepto"].astype(str).eq("Diferencia de la Semana")]
                if len(diff_rows) == 0:
                    diff_rows = df.index[df["Concepto"].astype(str).str.contains("Diferencia", case=False, na=False)]
                idx_diff = int(diff_rows[0]) + 2
                # B13 queda con el total informado del PDF si vino cargado.
                try:
                    val_info = df.loc[df["Concepto"].eq("TOTAL informado por IATA"), "Importe"].iloc[0]
                    if val_info != "" and pd.notna(val_info):
                        ws.write_number(idx_info-1, 1, float(val_info), fmt_money)
                    else:
                        ws.write_blank(idx_info-1, 1, None, fmt_yellow)
                except Exception:
                    ws.write_blank(idx_info-1, 1, None, fmt_yellow)
                # Fila real de Diferencia de la Semana, no arriba del resumen.
                ws.write(idx_diff-1, 0, "Diferencia de la Semana", fmt_semana_label)
                ws.write_formula(idx_diff-1, 1, f'=IF(ABS(B{idx_calc}-B{idx_info})<0.01,"SEMANA OK",B{idx_calc}-B{idx_info})', fmt_semana_ok)
                ws.conditional_format(idx_diff-1, 1, idx_diff-1, 1, {"type":"formula", "criteria":f'=AND(ISNUMBER(B{idx_diff}),ABS(B{idx_diff})>=0.01)', "format":fmt_diff_rojo_resumen})

                note_rows = df.index[df["Concepto"].astype(str).str.startswith("* Nota")]
                for nr in note_rows:
                    ws.write(nr+1, 0, df.loc[nr, "Concepto"], fmt_note)

                if not pivot.empty:
                    start = len(df)+5
                    ws.write(start,0,"Resumen por compañía desde Espejo Maverick",fmt_title)
                    pivot_data = pivot[pivot["Aerolínea"].astype(str).str.upper() != "TOTAL"].copy() if "Aerolínea" in pivot.columns else pivot.copy()
                    pivot_total = pivot[pivot["Aerolínea"].astype(str).str.upper() == "TOTAL"].copy() if "Aerolínea" in pivot.columns else pd.DataFrame()
                    pivot_data.to_excel(writer, sheet_name=name[:31], startrow=start+1, startcol=0, index=False)
                    for c,h in enumerate(pivot_data.columns):
                        ws.write(start+1,c,h,fmt_header)
                    if len(pivot_data):
                        ws.autofilter(start+1,0,start+1+len(pivot_data),len(pivot_data.columns)-1)
                    total_row = start+3+len(pivot_data)
                    if not pivot_total.empty:
                        for c in range(len(pivot.columns)):
                            val = pivot_total.iloc[0,c]
                            if c == 0:
                                ws.write(total_row,c,val,fmt_total_label)
                            elif isinstance(val,(int,float)):
                                ws.write_number(total_row,c,float(val),fmt_total)
                            else:
                                ws.write(total_row,c,val,fmt_total_label)

            elif name != "Resumen" and len(df):
                ws.autofilter(0,0,len(df),len(df.columns)-1)

            if "Aerolínea" in df.columns:
                ci = list(df.columns).index("Aerolínea")
                for ri,val in enumerate(df["Aerolínea"],start=1):
                    if str(val).startswith("FALTA NOMBRE"):
                        ws.write(ri,ci,val,fmt_red)

            # Colores visuales para estados, aplicado dentro de cada hoja
            for estado_col_name in ["Estado", "Estado Maverick"]:
                if estado_col_name in df.columns:
                    estado_ci = list(df.columns).index(estado_col_name)
                    for estado_ri, estado_val in enumerate(df[estado_col_name], start=1):
                        estado_txt = str(estado_val or "").upper()
                        if "RFND EN MAVERIC" in estado_txt:
                            ws.write(estado_ri, estado_ci, estado_val, fmt_estado_ok)
                        elif "RFND FUERA" in estado_txt:
                            ws.write(estado_ri, estado_ci, estado_val, fmt_estado_no)
                        elif "DUPLICADO" in estado_txt:
                            ws.write(estado_ri, estado_ci, estado_val, fmt_estado_no)
                        elif "FUERA" in estado_txt:
                            ws.write(estado_ri, estado_ci, estado_val, fmt_estado_fuera)
                        elif "DIF" in estado_txt:
                            ws.write(estado_ri, estado_ci, estado_val, fmt_estado_diff)
                        elif "NO" in estado_txt:
                            ws.write(estado_ri, estado_ci, estado_val, fmt_estado_no)
                        elif "OK" in estado_txt:
                            ws.write(estado_ri, estado_ci, estado_val, fmt_estado_ok)

            if "Emitido en:" in df.columns:
                emitido_ci = list(df.columns).index("Emitido en:")
                for emitido_ri, emitido_val in enumerate(df["Emitido en:"], start=1):
                    emitido_txt = str(emitido_val or "").upper()
                    if emitido_txt == "WEB":
                        ws.write(emitido_ri, emitido_ci, emitido_val, fmt_emitido_web)
                    elif emitido_txt == "BSP":
                        ws.write(emitido_ri, emitido_ci, emitido_val, fmt_emitido_bsp)
                    elif emitido_txt == "???":
                        ws.write(emitido_ri, emitido_ci, emitido_val, fmt_estado_no)

            # Congelar siempre primera fila
            ws.freeze_panes(1, 0)

    output.seek(0)
    output.seek(0)
    return output.getvalue()


def output_name(start, end):
    s = pd.to_datetime(start)
    e = pd.to_datetime(end)
    meses = {
        1: "ene", 2: "feb", 3: "mar", 4: "abr", 5: "may", 6: "jun",
        7: "jul", 8: "ago", 9: "sep", 10: "oct", 11: "nov", 12: "dic"
    }
    mes = meses[e.month]
    creado = datetime.now()
    creado_txt = f"{creado.day}{meses[creado.month]}{str(creado.year)[-2:]}_{creado.strftime('%H%M')}"
    return f"Conciliacion_IATA_Maverick_{s.day}-{e.day}_{mes}_{e.strftime('%y')}_creado_{creado_txt}.xlsx"


# Autorización agregada v2.9.7
EXTRA_AUTHORIZED_UUIDS = {
    "D4157452-1745-11EC-B699-67F9496C3500": {"name": "Laura Techera PC", "role": "user"},
}

def get_app_root():
    p = Path(__file__).resolve()
    parts = list(p.parts)
    if "APP_MAC" in parts:
        return Path(*parts[:parts.index("APP_MAC")])
    if "APP_PC" in parts:
        return Path(*parts[:parts.index("APP_PC")])
    return p.parent

APP_BASE_DIR = get_app_root()

def get_reports_base_dir():
    home = Path.home()
    docs = home / "Documents"
    if not docs.exists():
        docs = home / "Documentos"
    if not docs.exists():
        docs = home
    base = docs / "archivos conciliados de iata"
    base.mkdir(parents=True, exist_ok=True)
    return base

REPORTS_DIR = get_reports_base_dir()
OUT_DIR = REPORTS_DIR

def period_folder_name(start, end):
    s = pd.to_datetime(start)
    e = pd.to_datetime(end)
    meses = {
        1: "ene", 2: "feb", 3: "mar", 4: "abr", 5: "may", 6: "jun",
        7: "jul", 8: "ago", 9: "sep", 10: "oct", 11: "nov", 12: "dic"
    }
    if s.month == e.month and s.year == e.year:
        return f"{s.day}-{e.day} {meses[e.month]} {str(e.year)[-2:]}"
    return f"{s.day} {meses[s.month]}-{e.day} {meses[e.month]} {str(e.year)[-2:]}"

def get_period_output_dir(start, end):
    folder = REPORTS_DIR / period_folder_name(start, end)
    folder.mkdir(parents=True, exist_ok=True)
    return folder

def get_conciliador_home():
    return REPORTS_DIR


def period_folder_name(start, end):
    s = pd.to_datetime(start)
    e = pd.to_datetime(end)
    meses = {
        1: "ene", 2: "feb", 3: "mar", 4: "abr", 5: "may", 6: "jun",
        7: "jul", 8: "ago", 9: "sep", 10: "oct", 11: "nov", 12: "dic"
    }
    if s.month == e.month and s.year == e.year:
        return f"{s.day}-{e.day} {meses[e.month]} {str(e.year)[-2:]}"
    return f"{s.day} {meses[s.month]}-{e.day} {meses[e.month]} {str(e.year)[-2:]}"

def get_period_output_dir(start, end):
    folder = REPORTS_DIR / period_folder_name(start, end)
    folder.mkdir(parents=True, exist_ok=True)
    return folder

def get_conciliador_home():
    return REPORTS_DIR


def period_folder_name(start, end):
    s = pd.to_datetime(start)
    e = pd.to_datetime(end)
    mes = e.strftime("%b").lower()
    return f"{s.day}-{e.day} {mes} {e.strftime('%y')}"

def get_period_output_dir(start, end):
    folder = REPORTS_DIR / period_folder_name(start, end)
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def period_folder_name(start, end):
    s = pd.to_datetime(start)
    e = pd.to_datetime(end)
    mes = e.strftime("%b").lower()
    return f"{s.day}-{e.day} {mes} {e.strftime('%y')}"

def get_period_output_dir(start, end):
    folder = REPORTS_DIR / period_folder_name(start, end)
    folder.mkdir(parents=True, exist_ok=True)
    return folder



def tuki_authorized_devices_table():
    data = [
        {"Nombre": "Tuki Mac Admin", "UUID/HWID": "LOCAL_ADMIN", "Rol": "admin"},
        {"Nombre": "Laura Techera PC", "UUID/HWID": "D4157452-1745-11EC-B699-67F9496C3500", "Rol": "user"},
    ]
    try:
        for k, v in AUTHORIZED_DEVICES.items():
            if isinstance(v, dict):
                data.append({"Nombre": v.get("name", k), "UUID/HWID": k, "Rol": v.get("role", "")})
            else:
                data.append({"Nombre": str(v), "UUID/HWID": k, "Rol": ""})
    except Exception:
        pass
    # dedupe por UUID/HWID
    seen = set()
    clean = []
    for row in data:
        key = row.get("UUID/HWID")
        if key not in seen:
            clean.append(row)
            seen.add(key)
    return pd.DataFrame(clean)

st.set_page_config(page_title=APP_NAME, page_icon="🧾", layout="wide")

st.markdown("""
<style>
.tuki-hero {
    background: linear-gradient(135deg, #eaf6ff 0%, #f5f7fa 100%);
    border: 1px solid #d6e7f5;
    border-radius: 18px;
    padding: 26px 30px;
    margin: 8px 0 22px 0;
    box-shadow: 0 2px 10px rgba(31,78,121,0.08);
}
.tuki-hero h1 {
    color: #111827;
    font-size: 36px;
    font-weight: 750;
    margin: 0;
    letter-spacing: -0.5px;
}
.tuki-hero p {
    color: #4b5563;
    margin: 8px 0 0 0;
    font-size: 15px;
}
section[data-testid="stSidebar"] { background: #f7fafc; }
</style>
<div class="tuki-hero">
  <h1>Conciliador IATA - Maveric</h1>
  <p>Conciliación operativa y contable de Subir TXT de la IATA contra Maveric original.</p>
</div>
""", unsafe_allow_html=True)

col_logo, col_title = st.columns([1, 5])
with col_logo:
    show_logo()
with col_title:
    # st.title(APP_NAME)  # reemplazado por tuki-hero
    st.caption(f"Versión {VERSION} · Creada {CREATED_LABEL}")

device_uuid, device_info = check_device_authorized()

if not device_info:
    st.error("Aplicación no autorizada para este dispositivo.")
    st.warning(f"UUID detectado: {device_uuid or 'No pude detectar UUID'}")
    st.info("Enviá este UUID a Tuki para autorizar el equipo.")
    st.stop()

st.sidebar.success(f"Autorizado: {device_info['name']} | Rol: {device_info['role']}")

if device_info["role"] == "admin":
    st.sidebar.caption("Modo admin habilitado.")

# Sidebar utilidades v2.8.9

try:
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
except Exception:
    pass

st.sidebar.markdown("---")
st.sidebar.markdown("### Utilidades")
if st.sidebar.button("Abrir carpeta de reportes", key="abrir_reportes_v285"):
    try:
        import subprocess, sys
        if sys.platform == "darwin":
            subprocess.Popen(["open", str(REPORTS_DIR)])
        elif sys.platform.startswith("win"):
            os.startfile(str(REPORTS_DIR))
        else:
            subprocess.Popen(["xdg-open", str(REPORTS_DIR)])
    except Exception as e:
        st.sidebar.warning(f"No pude abrir la carpeta: {e}")

if device_info.get("role") == "admin":
    with st.sidebar.expander("Admin"):
        st.caption("Diagnóstico")
        if st.button("Ver logs", key="ver_logs_v285"):
            try:
                logs = sorted(REPORTS_DIR.glob("*.log"), key=lambda p: p.stat().st_mtime, reverse=True)
                if logs:
                    st.text_area("Último log", logs[0].read_text(errors="ignore")[-8000:], height=260)
                else:
                    st.info("No encontré logs.")
            except Exception as e:
                st.warning(f"No pude leer logs: {e}")
        if st.button("Reiniciar motor", key="reiniciar_motor_v285"):
            st.warning("Cerrá esta pestaña y volvé a abrir la app.")


st.sidebar.markdown("---")
st.sidebar.caption("Conciliador Tuki")
st.sidebar.caption("Versión 2.9.8")
st.sidebar.caption("Creación 19may2026")

if device_info.get("role") == "admin":
    with st.sidebar.expander("Equipos autorizados"):
        st.dataframe(tuki_authorized_devices_table(), use_container_width=True)


if device_info.get("role") == "admin":
    with st.sidebar.expander("Notas de versión"):
        st.markdown("""
**v2.9.8 FINAL**
- Corrige subida/procesamiento de Maveric original sin títulos.
- Corrige ruta: no crea `archivos conciliados` en Escritorio ni en `/tmp`.
- Mantiene launcher estable.
- Recupera portada profesional.
""")


if st.sidebar.button("Cerrar aplicación", key="cerrar_sidebar_v287"):
    st.sidebar.warning("Cerrando servidor local...")
    os._exit(0)





st.markdown("""
<style>
/* Tuki custom css */
h1 { font-size: 2.4rem !important; white-space: normal !important; }
.block-container { padding-top: 3rem; }
</style>
""", unsafe_allow_html=True)

st.write("Subí el TXT largo de la IATA, el XLS de Maveric original sin títulos y, opcionalmente, el PDF de resumen IATA.")

col1, col2, col3 = st.columns(3)
with col1:
    txt_file = st.file_uploader("Subir TXT de la IATA", type=["txt","TXT"])
with col2:
    mav_file = st.file_uploader("Subir XLS de Maveric original sin títulos", type=["xlsx","xls"])
with col3:
    resumen_pdf_file = st.file_uploader("Subir PDF resumen IATA opcional", type=["pdf"])

periodo = st.date_input(
    "📅 Seleccionar el período IATA",
    value=(pd.Timestamp.today().date(), pd.Timestamp.today().date()),
    help="Elegí primero el día inicial y después el día final del período IATA."
)

if isinstance(periodo, tuple) and len(periodo) == 2:
    start_date, end_date = periodo
else:
    start_date = end_date = periodo

if st.button("GENERAR CONCILIACIÓN", type="primary"):
    if txt_file is None or mav_file is None:
        st.error("Tenés que subir Subir TXT de la IATA y Subir XLS de Maveric original sin títulos.")
    elif pd.Timestamp(start_date) > pd.Timestamp(end_date):
        st.error("La fecha desde no puede ser mayor que la fecha hasta.")
    else:
        try:
            sheets = build_beta2(txt_file, mav_file, start_date, end_date)
            resumen_iata_df, totales_iata_df, total_iata_pdf, diag_pdf_iata = parse_iata_summary_pdf(resumen_pdf_file)
            try:
                pdf_subido = resumen_pdf_file is not None
            except Exception:
                pdf_subido = False
            if pdf_subido:
                if resumen_iata_df is None or resumen_iata_df.empty:
                    resumen_iata_df = pd.DataFrame([{"Categoria":"ERROR","Codigo":"","Sigla":"","Compañia":f"PDF subido, pero sin filas parseadas. Diagnóstico: {diag_pdf_iata}","FOP":"","Cash":0.0,"CC":0.0,"Total":0.0,"RFND Cash":0.0,"RFND CC":0.0,"RFND Total":0.0,"ADMS":0.0,"ACM":0.0,"Tasas y Cargos":0.0,"Monto Cash":0.0,"Taxs sin Comi":0.0,"Neto a pagar":0.0,"Cantidad de docs":0}])
                sheets["Resumen IATA"] = resumen_iata_df
                if total_iata_pdf is not None:
                    sheets["_TOTAL_INFORMADO_IATA_PDF"] = float(total_iata_pdf)
            data = excel_bytes(sheets); filename = output_name(start_date, end_date)
            out_dir = get_period_output_dir(start_date, end_date); (out_dir / filename).write_bytes(data)
            st.success("Conciliación generada correctamente.")
            st.download_button("Descargar Excel conciliado", data=data, file_name=filename, mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            st.info(f"También se guardó una copia en: {out_dir}")
        except Exception as e:
            st.exception(e)
