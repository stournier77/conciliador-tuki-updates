#!/bin/bash
set -e
BASE="$HOME/Desktop/Conciliador_Tuki_FINAL"
TARGET="$BASE/APP_MAC/Conciliador Tuki Secure.app/Contents/Resources/app.py"
PATCH_DIR="$(cd "$(dirname "$0")" && pwd)"
SRC="$PATCH_DIR/app.py"

echo "Instalando Conciliador MAC PATCH v3.4.8 RFND POSICIONAL ESTABLE..."
if [ ! -f "$SRC" ]; then
  echo "No encuentro app.py dentro del parche."
  exit 1
fi
if [ ! -f "$TARGET" ]; then
  echo "No encuentro el app.py real en:"
  echo "$TARGET"
  echo "Verificá que la carpeta Conciliador_Tuki_FINAL esté en el Escritorio."
  exit 1
fi
BACKUP="$TARGET.backup_v3_4_8_$(date +%Y%m%d_%H%M%S)"
cp "$TARGET" "$BACKUP"
cp "$SRC" "$TARGET"
chmod 644 "$TARGET"
echo "OK. Backup creado en: $BACKUP"
echo "Ahora abrí con ABRIR_CONCILIADOR_TUKI.command como siempre."
