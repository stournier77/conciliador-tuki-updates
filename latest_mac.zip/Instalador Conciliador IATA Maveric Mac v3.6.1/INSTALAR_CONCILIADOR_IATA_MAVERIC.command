#!/bin/bash
set -e
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET="$HOME/Documents/App Conciliador IATA Maveric"
APPFILES="$TARGET/Archivos APP"
RESULTS="$TARGET/archivos conciliados de iata"
DESKTOP="$HOME/Desktop"
LAUNCHER_APP="$DESKTOP/Conciliador IATA Maveric.app"
REAL_COMMAND="$APPFILES/Abrir Conciliador IATA Maveric.command"
ICON_SOURCE="$APPFILES/assets/Conciliador_IATA_Maveric.icns"

mkdir -p "$APPFILES" "$RESULTS"
rsync -a --delete "$SRC_DIR/Archivos APP/" "$APPFILES/"
chmod +x "$REAL_COMMAND"
rm -rf "$DESKTOP/Conciliador IATA Maveric.app" "$DESKTOP/Conciliador IATA Maveric" "$DESKTOP/Conciliador IATA Maveric.command" 2>/dev/null || true

TMP_SCRIPT="$(mktemp /tmp/conciliador_iata_XXXXXX.applescript)"
cat > "$TMP_SCRIPT" <<'EOF'
on run
    do shell script "nohup " & quoted form of (POSIX path of (path to home folder) & "Documents/App Conciliador IATA Maveric/Archivos APP/Abrir Conciliador IATA Maveric.command") & " >/tmp/conciliador_iata_launcher.log 2>&1 &"
end run
EOF
/usr/bin/osacompile -o "$LAUNCHER_APP" "$TMP_SCRIPT"
rm -f "$TMP_SCRIPT"

cp "$ICON_SOURCE" "$LAUNCHER_APP/Contents/Resources/applet.icns"
/usr/libexec/PlistBuddy -c "Set :CFBundleName Conciliador IATA Maveric" "$LAUNCHER_APP/Contents/Info.plist" 2>/dev/null || true
/usr/libexec/PlistBuddy -c "Set :CFBundleDisplayName Conciliador IATA Maveric" "$LAUNCHER_APP/Contents/Info.plist" 2>/dev/null || true
/usr/libexec/PlistBuddy -c "Set :CFBundleIdentifier uy.sevens.conciliador.iata.maveric.launcher" "$LAUNCHER_APP/Contents/Info.plist" 2>/dev/null || true
/usr/libexec/PlistBuddy -c "Set :CFBundleIconFile applet" "$LAUNCHER_APP/Contents/Info.plist" 2>/dev/null || true
touch "$LAUNCHER_APP"
killall Finder >/dev/null 2>&1 || true
osascript -e 'display dialog "Instalación lista. Se actualizó el ícono y se eliminó la información vieja del panel lateral." buttons {"OK"} default button "OK"' >/dev/null 2>&1 || true
