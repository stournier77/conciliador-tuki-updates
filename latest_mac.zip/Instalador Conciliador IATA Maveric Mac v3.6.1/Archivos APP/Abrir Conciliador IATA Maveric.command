#!/bin/bash
set -u
BASE="$HOME/Documents/App Conciliador IATA Maveric"
APPFILES="$BASE/Archivos APP"
APP_DIR="$APPFILES/APP_MAC"
APP_FILE="$APP_DIR/app.py"
VERSION_FILE="$APPFILES/installed_version.txt"
LOG_DIR="$APPFILES/logs"
PID_FILE="$LOG_DIR/streamlit_iata.pid"
PORT=8761
REPO="stournier77/conciliador-tuki-updates"
API="https://api.github.com/repos/$REPO/releases/latest"
mkdir -p "$LOG_DIR"
LOG="$LOG_DIR/actualizador.log"

log(){ printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$LOG"; }

update_if_needed(){
  local installed remote api_json asset_url tmp zip root
  installed="$(tr -d '\r\n ' < "$VERSION_FILE" 2>/dev/null || echo 0)"
  api_json="$(curl -fsSL --connect-timeout 8 --max-time 20 -H 'Accept: application/vnd.github+json' "$API" 2>>"$LOG" || true)"
  [ -n "$api_json" ] || { log "Sin conexión a GitHub; abro versión $installed"; return 0; }
  remote="$(printf '%s' "$api_json" | python3 -c 'import json,sys; print(json.load(sys.stdin).get("tag_name","").lstrip("v"))' 2>>"$LOG" || true)"
  [ -n "$remote" ] || { log "No pude leer tag remoto"; return 0; }
  if [ "$remote" = "$installed" ]; then log "Versión al día: $installed"; return 0; fi
  asset_url="$(printf '%s' "$api_json" | python3 -c 'import json,sys; d=json.load(sys.stdin); print(next((a["browser_download_url"] for a in d.get("assets",[]) if a.get("name")=="latest_mac.zip"),""))' 2>>"$LOG" || true)"
  [ -n "$asset_url" ] || { log "No existe asset latest_mac.zip en v$remote"; return 0; }
  tmp="$(mktemp -d /tmp/conciliador_iata_update.XXXXXX)" || return 0
  zip="$tmp/latest_mac.zip"
  log "Actualizando $installed -> $remote"
  if ! curl -fL --connect-timeout 10 --max-time 180 "$asset_url" -o "$zip" >>"$LOG" 2>&1; then rm -rf "$tmp"; log "Falló descarga"; return 0; fi
  if ! /usr/bin/unzip -q "$zip" -d "$tmp/unzip" >>"$LOG" 2>&1; then rm -rf "$tmp"; log "Falló descompresión"; return 0; fi
  root="$(find "$tmp/unzip" -type d -name 'Archivos APP' -print -quit)"
  [ -n "$root" ] || { rm -rf "$tmp"; log "Paquete sin Archivos APP"; return 0; }
  /usr/bin/rsync -a "$root/APP_MAC/" "$APPFILES/APP_MAC/" >>"$LOG" 2>&1 || true
  /usr/bin/rsync -a "$root/assets/" "$APPFILES/assets/" >>"$LOG" 2>&1 || true
  cp "$root/installed_version.txt" "$VERSION_FILE" 2>>"$LOG" || printf '%s\n' "$remote" > "$VERSION_FILE"
  rm -rf "$tmp"
  log "Actualización completada a $remote"
}

if ! command -v python3 >/dev/null 2>&1; then
  osascript -e 'display alert "Conciliador IATA Maveric" message "No encuentro Python 3 instalado."'
  exit 1
fi
update_if_needed
if ! python3 -c "import streamlit,pandas,openpyxl,xlsxwriter,pypdf" >/dev/null 2>&1; then
  python3 -m pip install --user streamlit pandas openpyxl xlsxwriter PyPDF2 pypdf xlrd
fi
# detener solo instancia IATA guardada
if [ -f "$PID_FILE" ]; then
  oldpid="$(cat "$PID_FILE" 2>/dev/null || true)"
  if [ -n "$oldpid" ] && kill -0 "$oldpid" 2>/dev/null; then kill "$oldpid" 2>/dev/null || true; sleep 1; fi
fi
cd "$APP_DIR"
python3 -m streamlit run "$APP_FILE" --server.headless false --server.port "$PORT" >>"$LOG_DIR/streamlit.log" 2>&1 &
pid=$!
printf '%s\n' "$pid" > "$PID_FILE"
sleep 2
open "http://localhost:$PORT" >/dev/null 2>&1 || true
wait "$pid"
