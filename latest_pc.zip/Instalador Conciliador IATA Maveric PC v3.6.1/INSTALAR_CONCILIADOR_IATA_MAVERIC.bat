@echo off
set "SRC=%~dp0"
set "TARGET=%USERPROFILE%\Documents\App Conciliador IATA Maveric"
set "APPFILES=%TARGET%\Archivos APP"
set "RESULTS=%TARGET%\archivos conciliados de iata"
if not exist "%APPFILES%" mkdir "%APPFILES%"
if not exist "%RESULTS%" mkdir "%RESULTS%"
xcopy "%SRC%Archivos APP" "%APPFILES%" /E /I /Y >nul
set "SHORTCUT=%USERPROFILE%\Desktop\Conciliador IATA Maveric.lnk"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut('%SHORTCUT%'); $s.TargetPath='%APPFILES%\Abrir Conciliador IATA Maveric.bat'; $s.WorkingDirectory='%APPFILES%'; $s.IconLocation='%APPFILES%\assets\Conciliador_IATA_Maveric.ico'; $s.Save()"
echo Instalacion lista.
pause
