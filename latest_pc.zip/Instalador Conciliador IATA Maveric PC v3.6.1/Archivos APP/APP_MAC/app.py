
import io
import re
from pathlib import Path
from datetime import datetime
import pandas as pd
import streamlit as st
import subprocess
import platform
import os

VERSION = "3.6.1"
APP_NAME = "Conciliador IATA - Maveric"
APP_DIR = Path(__file__).resolve().parent
LOGO_PATH = APP_DIR / "sevens_logo.png"
CREATED_LABEL = "02oct2026"

def show_logo():
    try:
        if LOGO_PATH.exists():
            st.image(str(LOGO_PATH), width=130)
        else:
            st.markdown("**SEVENS TRAVEL**")
    except Exception:
        st.markdown("**SEVENS TRAVEL**")


ACMA_OVERRIDES = {
    "8996000581": -68512.00,
}


AUTHORIZED_DEVICES = {
    "00000000-0000-0000-0000-309C230BAEF1": {"name": "Tuki PC", "role": "admin"},
    "D4157452-1745-11EC-B699-67F9496C3500": {"name": "Laura Techera PC", "role": "user"},
    "86FE5326-6706-53D3-97C4-442452FDC186": {"name": "Tuki Mac Admin", "role": "admin"},
    "0C8703A9-3F15-54CD-A977-B4D2B4CFE266": {"name": "Federico Mac", "role": "user"},
    "C1C28570-D1CF-0000-0000-000000000000": {"name": "Federico PC", "role": "user"},
    "60658200-1690-11EC-8AD9-C282CD8C3500": {"name": "Karen PC", "role": "user"},
}

def get_device_uuid():
    system = platform.system().lower()
    try:
        if system == "darwin":
            out = subprocess.check_output(
                ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                stderr=subprocess.DEVNULL,
                text=True,
                timeout=5
            )
            m = re.search(r'"IOPlatformUUID"\s*=\s*"([^"]+)"', out)
            return m.group(1).strip().upper() if m else None

        if system == "windows":
            try:
                out = subprocess.check_output(
                    ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command",
                     "(Get-CimInstance -ClassName Win32_ComputerSystemProduct -ErrorAction Stop).UUID"],
                    stderr=subprocess.DEVNULL,
                    text=True,
                    timeout=5
                )
                m = re.search(r"(?im)^\s*([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\s*$", out)
                if m:
                    return m.group(1).upper()
            except Exception:
                pass
            out = subprocess.check_output(
                ["wmic", "csproduct", "get", "uuid"],
                stderr=subprocess.DEVNULL,
                text=True,
                timeout=5
            )
            lines = [x.strip() for x in out.splitlines() if x.strip() and "UUID" not in x.upper()]
            return lines[0].upper() if lines else None
    except Exception:
        return None
    return None


def get_conciliador_home():
    return REPORTS_DIR

def periodo_label(start_date, end_date):
    start = pd.Timestamp(start_date)
    end = pd.Timestamp(end_date)
    meses = {
        1: "ene", 2: "feb", 3: "mar", 4: "abr", 5: "may", 6: "jun",
        7: "jul", 8: "ago", 9: "sep", 10: "oct", 11: "nov", 12: "dic"
    }
    if start.month == end.month and start.year == end.year:
        return f"{start.day}-{end.day} {meses[end.month]} {str(end.year)[-2:]}"
    return f"{start.day} {meses[start.month]}-{end.day} {meses[end.month]} {str(end.year)[-2:]}"


def check_device_authorized():
    uuid = get_device_uuid()
    info = AUTHORIZED_DEVICES.get((uuid or "").upper())
    return uuid, info


def read_txt_file(uploaded_file):
    raw = uploaded_file.read()
    return raw.decode("latin-1", errors="ignore").splitlines()

def parse_iata_date(line, date_re):
    m = date_re.search(line)
    if not m:
        return pd.NaT
    y = m.group(3)
    try:
        return pd.Timestamp(2000 + int(y[:2]), int(y[2:4]), int(y[4:6]))
    except Exception:
        return pd.NaT

def parse_txt_blocks(lines):
    doc_re = re.compile(r"(TKTT|ADMA|SPDR|EMDS|EMDA|CANX|CANN|ACMA|SPCR|RFND)(\d{10})")
    date_re = re.compile(r"(TKTT|ADMA|SPDR|EMDS|EMDA|CANX|CANN|ACMA|SPCR|RFND)(\d{10})(?:\d)?(\d{6})")
    blocks = {}
    cur = None
    for i, line in enumerate(lines, start=1):
        m = doc_re.search(line)
        if line.startswith("DET") and m:
            cur = m.group(2)
            if cur not in blocks:
                blocks[cur] = {
                    "Documento IATA": cur,
                    "Tipo TXT": m.group(1),
                    "Aerolínea TXT": line[3:6] if len(line) >= 6 else "",
                    "Fecha IATA": parse_iata_date(line, date_re),
                    "Linea TXT": i,
                    "DET TXT": line,
                    "Bloque TXT": line,
                    "Cantidad DET": 1,
                }
            else:
                blocks[cur]["DET TXT"] += "\n" + line
                blocks[cur]["Bloque TXT"] += "\n" + line
                blocks[cur]["Cantidad DET"] += 1
        elif cur:
            blocks[cur]["Bloque TXT"] += "\n" + line
    return blocks

def section_after_usd2(det):
    if not det:
        return ""
    s = str(det)
    if "USD2" in s:
        s = s.split("USD2", 1)[1]
    elif "USD" in s:
        s = s.split("USD", 1)[1]
    else:
        return ""
    m = re.search(r"\s{4,}[A-Z]\s", s)
    return s[:m.start()] if m else s[:230]

def signed_amount_from_chunk(raw, max_chars=12):
    raw = str(raw)
    if not raw.startswith("-"):
        return None, ""
    part = raw[:max_chars] if len(raw) >= max_chars else raw
    digits = re.sub(r"^-0+", "", part)
    if digits == "":
        return 0.0, part
    return -int(digits) / 100, part

def parse_acma_importe(det, doc=None):
    if doc in ACMA_OVERRIDES:
        return ACMA_OVERRIDES[doc], "override_usuario"

    # v3.5.27 ACMA:
    # El ACM correcto es el mayor valor absoluto negativo encontrado en USD2/tail.
    # Validados:
    # - 8012720151: 399.04, no 34.90.
    # - 8012720157/8012720158: 217.00, no 88.00 ni 129.00.
    s = str(det or "")
    sec = section_after_usd2(s)
    vals = []

    # Negativos en la zona USD2 antes de la marca I: formato típico "-" + 11 dígitos.
    for m in re.finditer(r"-0+\d+", sec[:260]):
        val, part = signed_amount_from_chunk(m.group(0), 12)
        if val is not None and abs(val) > 0:
            vals.append((round(val, 2), part, m.start(), "usd2"))

    # Negativos en tail post-I: en estos registros el formato útil es "-" + 10 dígitos.
    raw_after_usd = s
    if "USD2" in raw_after_usd:
        raw_after_usd = raw_after_usd.split("USD2", 1)[1]
    elif "USD" in raw_after_usd:
        raw_after_usd = raw_after_usd.split("USD", 1)[1]
    m_tail_marker = re.search(r"\s{4,}I\s+", raw_after_usd)
    if m_tail_marker:
        tail_post_i = raw_after_usd[m_tail_marker.end():]
        for m in re.finditer(r"-0+\d+", tail_post_i[:120]):
            raw = m.group(0)
            part = raw[:11] if len(raw) >= 11 else raw  # "-" + 10 dígitos
            try:
                val = -int(re.sub(r"^-0+", "", part) or "0") / 100
            except Exception:
                val = None
            if val is not None and abs(val) > 0:
                vals.append((round(val, 2), part, m_tail_marker.end()+m.start(), "tail_post_I"))

    if vals:
        val, part, pos, src = max(vals, key=lambda x: abs(x[0]))
        return val, f"{part}_acma_total_mayor_abs_{src}_pos_{pos}"

    return None, "sin_candidato_acma"


def parse_adma_importe(det):
    """
    ADMA/SPDR siempre positivos.
    ADMA: -000000043800... => 4.38
    SPDR: 000001201460000... => 1201.46
    """
    s = str(det)
    sec = section_after_usd2(s)

    if "SPDR" in s:
        tail = s.split(" I ", 1)[-1] if " I " in s else s
        m_tail = re.search(r"(?<!\d)(0{1,}\d{6,})(?=0{6,})", tail)
        if m_tail:
            field = m_tail.group(1)[:11]
            try:
                return round(int(field) / 100, 2), field
            except Exception:
                pass
        m = re.search(r"USD2(0+\d{6,})", s)
        if m:
            field = m.group(1)[:11]
            try:
                return round(int(field) / 100, 2), field
            except Exception:
                pass

    # v3.5.23 ADM POSICIONAL:
    # El total real del ADM está en la zona USD2 posiciones 60:72, como campo de 12 dígitos.
    # Corrige casos:
    # - 6006001512: 000000001034 => 10.34 (antes podía leer 103.40)
    # - 6013950244: 000001007299 => 10072.99 (antes 72.99)
    # - 6013950259: 000001162209 => 11622.09
    # - 6013950385: 000001197005 => 11970.05
    # También mantiene los ADM con MF/total positivo anteriores:
    # - 6012724122: 000000002281 => 22.81
    fld_total_12 = sec[60:72]
    if re.fullmatch(r"\d{12}", fld_total_12):
        try:
            v_total_12 = int(fld_total_12) / 100
            if v_total_12 > 0 and v_total_12 < 100000:
                return round(v_total_12, 2), f"{fld_total_12}_adm_total_pos_60_72"
        except Exception:
            pass

    # ADMA especial: algunas ADM vienen con un componente negativo en USD2
    # (por ejemplo -2.81) y un cargo/tasa MF positivo dentro del mismo DET.
    # La lógica vieja tomaba el primer negativo y perdía el total real.
    # En esos casos el neto real de la ADM está en el campo posicional 66:77
    # de la zona USD2: abs(componente) + tasas/cargos, ej. 2.81 + 20.00 = 22.81.
    negs = []
    for m in re.finditer(r"-0+\d+", sec[:220]):
        val, part = signed_amount_from_chunk(m.group(0), 11)
        if val is not None and abs(val) > 0:
            negs.append((round(abs(val), 2), part))

    if negs:
        base_neg, neg_part = negs[0]
        for st in [66, 61, 65, 62]:
            fld = sec[st:st+11]
            if re.fullmatch(r"\d{11}", fld):
                v = clean_positive_or_regular_amount(fld)
                if v is not None and v > base_neg and v < 100000:
                    return round(v, 2), f"{fld}_adm_total_pos_{st}"

        return base_neg, neg_part

    aud, afield, ameth = audit_net(s)
    return (round(abs(aud), 2) if aud is not None else None), afield


def _rfnd_parse_fixed_usd2(det):
    """
    RFND v3.4.8 - lectura posicional estable.
    Regla base detectada en TXT BSP:
    - Cash real = campo posicional USD2[60:72] (12 caracteres, centavos, puede ser + / - / cero).
    - CC real = último importe de la cola antes de RFxxx cuando hay al menos dos importes en esa cola.
      Ej: 00000000000-00000013377RF -> cash blanco, CC -133.77.
      Ej: -0000008802-00000012700RF -> cash -88.02, CC -127.00.
    - No tomar el primer importe de USD2 ni el último negativo largo de USD2 como cash.
    - Si el cash posicional es cero, se devuelve blanco/None para no inventar cash.
    """
    det = str(det or "")

    def _amt(field):
        f = str(field or "").strip()
        if not f or not re.fullmatch(r"-?\d+", f):
            return None
        sign = -1 if f.startswith("-") else 1
        digits = f[1:] if f.startswith("-") else f
        if not digits or set(digits) == {"0"}:
            return None
        return round(sign * int(digits) / 100.0, 2)

    pre = ""
    tail = ""
    if "USD2" in det:
        after_usd2 = det.split("USD2", 1)[1]

        # Parser estable v3.5.38: único cambio, aceptar espacios variables alrededor de I.
        m_sep = re.search(r"\s+I\s+", after_usd2)
        if m_sep:
            pre = after_usd2[:m_sep.start()]
            rest = after_usd2[m_sep.end():]
            tail = rest.split("RF", 1)[0] if "RF" in rest else rest
        else:
            pre = after_usd2

    cash_field = pre[60:72] if len(pre) >= 72 else ""
    cash = _amt(cash_field)

    # CC: cola antes de RF. Ignora códigos tipo W05 / OPERINT5 tomando solo bloques largos.
    tail_tokens = re.findall(r"-?\d{10,22}", tail)
    cc_field = ""
    cc = None
    if len(tail_tokens) >= 2:
        cc_field = tail_tokens[-1]
        cc = _amt(cc_field)

    # Comisión informativa: marcador habitual 0100/0500 en USD2.
    campo_comision = ""
    comision = 0
    m_com = re.search(r"0000(100|500)", pre)
    if m_com:
        campo_comision = "0" + m_com.group(1)
        try:
            comision = round(int(m_com.group(1)) / 100.0, 2)
        except Exception:
            comision = 0

    metodo = "rfnd_v348_posicional_usd2_60_72_cash_tail_cc"
    return cash, cc, cash_field, cc_field, metodo, comision, campo_comision


def parse_rfnd_cash_cc(det):
    """Wrapper compatible con build_beta2."""
    return _rfnd_parse_fixed_usd2(det)


def parse_acma_rfnd_importe(det, doc=None):
    s = str(det)
    if "RFND" in s:
        cash, cc, cash_field, cc_field, metodo, com, campo_com = parse_rfnd_cash_cc(det)
        return cash, cash_field
    if "ACMA" in s:
        return parse_acma_importe(det, doc)
    return None, "tipo_no_acma_rfnd"

def negative_digits_after_dash(raw):
    m = re.search(r"-(0+)(\d+)", str(raw))
    if not m:
        return None, None
    return m.group(2), m.group(0)

def parse_negative_suggest(raw):
    """
    Toma el campo monetario negativo como signo + 11 dígitos.
    Corrige -000000001180... para leer -00000000118 = -1.18.
    """
    val, part = signed_amount_from_chunk(raw, 12)
    return val


def clean_positive_or_regular_amount(field):
    raw = str(field).strip()
    if not raw:
        return None
    if raw.startswith("-"):
        return parse_negative_suggest(raw)
    if not re.fullmatch(r"\d+", raw):
        return None
    if int(raw) == 0:
        return 0.0
    if len(raw) == 11 and raw.endswith("00000") and int(raw[:6]) != 0:
        return int(raw[:6]) / 100
    return int(raw) / 100

def to_cents(x):
    if pd.isna(x):
        return None
    return int(round(float(x) * 100))

def audit_net(det):
    sec = section_after_usd2(det)
    if not sec:
        return None, "", "sin_usd2"
    control = sec[65:86]
    if not re.search(r"[1-9-]", control):
        return 0.0, control, "cero_control_65_85"
    area = sec[40:120]
    neg = re.search(r"-0+\d+", area)
    if neg:
        v = parse_negative_suggest(neg.group(0))
        return (round(v, 2) if v is not None else None), neg.group(0), "posicional_negativo_regla_guion_ceros_4dig"
    for st in [66,65,67,64,68,63,69,62,70]:
        fld = sec[st:st+11]
        if re.fullmatch(r"\d{11}", fld):
            v = clean_positive_or_regular_amount(fld)
            if v is not None and abs(v) > 0:
                return round(v, 2), fld, f"posicional_campo_{st}_{st+10}"
    return None, control, "posicional_no_interpretable"

def find_exact(det, amount):
    c = to_cents(amount)
    if c is None:
        return None, "", "sin_neto_maverick"
    sec = section_after_usd2(det)
    if not sec:
        return None, "", "sin_usd2"
    if c == 0:
        control = sec[65:86]
        if not re.search(r"[1-9-]", control):
            return 0.0, control, "cero_validado_control_65_85"
        return None, control, "maverick_cero_con_control_no_cero"
    area = sec[40:120]
    if c < 0:
        target = str(abs(c))
        for m in re.finditer(r"-0+\d+", area):
            digits, full = negative_digits_after_dash(m.group(0))
            if digits and digits.startswith(target):
                return float(amount), m.group(0), "negativo_exacto_regla_guion_ceros"
        return None, area, "no_encontre_negativo_exacto"
    target = str(abs(c))
    # v3.5.26:
    # buscar importes positivos en toda la sección después de USD2/USD, no solo en sec[40:120].
    raw_after_usd = str(det or "")
    if "USD2" in raw_after_usd:
        raw_after_usd = raw_after_usd.split("USD2", 1)[1]
    elif "USD" in raw_after_usd:
        raw_after_usd = raw_after_usd.split("USD", 1)[1]
    else:
        raw_after_usd = sec
    for p in [
        re.compile(r"0+" + re.escape(target) + r"(?!\d)"),
        re.compile(r"0+" + re.escape(target) + r"0{2,}"),
        re.compile(re.escape(target) + r"0{2,}")
    ]:
        m = p.search(raw_after_usd)
        if m:
            metodo = "positivo_en_seccion_usd2_completa"
            if m.start() >= len(sec):
                metodo = "positivo_en_tail_usd2_post_I"
            return abs(c)/100, m.group(0), metodo
    for p in [re.compile(r"0+" + re.escape(target) + r"(?!\d)"), re.compile(r"0+" + re.escape(target) + r"0{2,}"), re.compile(re.escape(target) + r"0{2,}")]:
        m = p.search(area)
        if m:
            return abs(c)/100, m.group(0), "positivo_en_seccion_financiera_40_120"
    v, fld, meth = audit_net(det)
    if v is not None and abs(round(float(v)-float(amount),2)) < 0.01:
        return float(v), fld, "positivo_por_neto_posicional"
    return None, area, "no_encontre_positivo_exacto"

def candidates(det):
    sec = section_after_usd2(det)
    vals = []
    starts = list(range(0, min(len(sec),154), 11)) + [40,45,50,55,60,62,63,64,65,66,67,68,69,70]
    for st in starts:
        fld = sec[st:st+11]
        if re.fullmatch(r"\d{11}", fld):
            v = clean_positive_or_regular_amount(fld)
            if v is not None and 0 < abs(v) < 100000:
                vals.append(round(v,2))
    for m in re.finditer(r"-0+\d+", sec):
        v = parse_negative_suggest(m.group(0))
        if v is not None and abs(v) < 100000:
            vals.append(round(v,2))
    out, seen = [], set()
    for v in vals:
        if v not in seen:
            seen.add(v); out.append(v)
    return out

def period_status(fecha, doc, p0, p1, g0, blocks):
    """
    Antes solo conciliaba día anterior si estaba en TXT.
    Ahora: cualquier fecha Maverick fuera del período IATA se concilia si el documento existe en TXT.
    Si no existe en TXT, queda como fuera de período para no ensuciar No encontrada en IATA.
    """
    if pd.isna(fecha):
        return ""
    if p0 <= fecha <= p1:
        return "DENTRO_PERIODO_IATA"
    return "FUERA_PERIODO_CON_TXT" if doc in blocks else "FUERA_PERIODO_IATA"

def acma_sheet_from_txt(txt_leido):
    rows = []
    for _, r in txt_leido[txt_leido["Tipo TXT"].isin(["ACMA","SPCR"])].iterrows():
        tipo = str(r.get("Tipo TXT",""))
        val, field = parse_acma_importe(r.get("DET TXT",""), str(r.get("Documento IATA","")))
        rows.append({"Documento IATA": r.get("Documento IATA"), "Tipo": tipo, "Aerolínea": r.get("Aerolínea TXT"), "Fecha IATA": r.get("Fecha IATA"), "Importe ACM": val, "": "", "Linea TXT": r.get("Linea TXT"), "Campo usado": field, "DET TXT": r.get("DET TXT")})
    return pd.DataFrame(rows)

def rfnd_sheet_from_txt(txt_leido):
    rows = []
    for _, r in txt_leido[txt_leido["Tipo TXT"] == "RFND"].iterrows():
        cash, cc, com, campo_cash, campo_cc, campo_com, metodo = parse_rfnd_importes(r.get("DET TXT",""), str(r.get("Documento IATA","")))
        doc_iata = str(r.get("Documento IATA",""))
        rows.append({
            "Fecha IATA": r.get("Fecha IATA"),
            "Documento IATA": doc_iata,
            "Tipo": "RFND",
            "Aerolínea": r.get("Aerolínea TXT"),
            "Número de billete": doc_iata,
            "Billete relacionado": tuki_rfnd_boleto_from_line(r),
            "Estado Maverick": "NO EN MAVERICK",
            "Importe Cash": cash,
            "Importe CC": cc,
            "Comisión descontada": com,
            "Campo Cash": campo_cash,
            "Campo CC": campo_cc,
            "Campo Comisión": campo_com,
            "Metodo RFND": metodo,
            "Linea TXT": r.get("Linea TXT"),
            "DET TXT": r.get("DET TXT"),
        })
    return pd.DataFrame(rows)



def read_maverick_excel_file(mav_file):
    """
    Lee el Excel Maveric subido por Streamlit forzando motor.
    Evita: ValueError: Excel file format cannot be determined.
    """
    name = str(getattr(mav_file, "name", "") or "").lower()

    if hasattr(mav_file, "getvalue"):
        raw = mav_file.getvalue()
    else:
        try:
            pos = mav_file.tell()
        except Exception:
            pos = None
        raw = mav_file.read()
        try:
            if pos is not None:
                mav_file.seek(pos)
        except Exception:
            pass

    if name.endswith(".xls") and not name.endswith(".xlsx"):
        engines = ["xlrd", "openpyxl"]
    elif name.endswith(".xlsx") or name.endswith(".xlsm"):
        engines = ["openpyxl", "xlrd"]
    else:
        engines = ["openpyxl", "xlrd"]

    last_error = None
    for engine in engines:
        try:
            return pd.read_excel(io.BytesIO(raw), header=None, engine=engine)
        except Exception as e:
            last_error = e

    raise ValueError(
        "No pude leer el Excel Maveric. Probé openpyxl/xlrd. "
        "Verificá que sea .xls o .xlsx original de Maveric. "
        f"Último error: {last_error}"
    )



# --- Parche v3.3.0: códigos aerolínea especiales ---
try:
    _tuki_airline_from_code_original_v330 = tuki_airline_from_code
    def tuki_airline_from_code(code):
        c = str(code or "").strip().zfill(3)
        if c == "952":
            return "IATA"
        if c == "083":
            return "SOUTH AFRICAN AIRWAYS"
        return _tuki_airline_from_code_original_v330(code)
except Exception:
    pass


# --- Parche v3.3.0: lógica RFND validada ---
def _rfnd_v330_signed_amount(raw):
    s = str(raw or "").strip()
    if not s:
        return None
    sign = -1 if s.startswith("-") else 1
    digits = re.sub(r"\D", "", s)
    if not digits:
        return None
    return sign * (int(digits) / 100.0)

def _rfnd_v330_tokens(det):
    # campos firmados de 11 dígitos usados al final de la línea IATA
    return re.findall(r"-?\d{11}", str(det or ""))

def parse_rfnd_importes(det_txt, documento=""):
    """
    RFND v3.4.8 - función única: devuelve siempre 7 valores.
    Orden histórico: cash, cc, comision, campo_cash, campo_cc, campo_comision, metodo.
    """
    cash, cc, campo_cash, campo_cc, metodo, comision, campo_comision = _rfnd_parse_fixed_usd2(det_txt)
    return cash, cc, comision, campo_cash, campo_cc, campo_comision, metodo


def parse_rfnd_cash_cc(det):
    """Wrapper único para compatibilidad con build_beta2 y hojas RFND."""
    cash, cc, comision, campo_cash, campo_cc, campo_comision, metodo = parse_rfnd_importes(det, "")
    return cash, cc, campo_cash, campo_cc, metodo + "_via_wrapper_v347", comision, campo_comision

def build_beta2(txt_file, mav_file, p0, p1):
    p0 = pd.Timestamp(p0); p1 = pd.Timestamp(p1); g0 = p0 - pd.Timedelta(days=1)
    blocks = parse_txt_blocks(read_txt_file(txt_file))
    mav0 = ensure_maverick_format(read_maverick_excel_file(mav_file))
    required_mav_cols = ["Fecha", "Boleto", "Total a pagar Maverick"]
    missing_mav_cols = [c for c in required_mav_cols if c not in mav0.columns]
    if missing_mav_cols:
        raise ValueError("No pude interpretar el Maveric original. Faltan columnas normalizadas: " + ", ".join(missing_mav_cols))

    fc = "Fecha"; dc = "Boleto"; nc = "Total a pagar Maverick"
    mav = mav0.copy()
    mav["_Fecha Maverick"] = pd.to_datetime(mav[fc], errors="coerce", dayfirst=True)
    mav["_Documento Maverick"] = mav[dc].astype(str).str.extract(r"(\d{10})")
    mav["_Neto Maverick"] = pd.to_numeric(mav[nc], errors="coerce")

    doc_counts = mav["_Documento Maverick"].dropna().value_counts().to_dict()
    doc_seen = {}

    neto_iata_col=[]; diferencia_col=[]; estado_col=[]; tipo_col=[]; aer_col=[]; linea_col=[]; metodo_col=[]; campo_col=[]
    dup_flag_col=[]; cuenta_iata_col=[]; datos_rows=[]

    for _, r in mav.iterrows():
        doc = r["_Documento Maverick"]; neto = r["_Neto Maverick"]; fecha = r["_Fecha Maverick"]
        is_dup = bool(pd.notna(doc) and doc_counts.get(doc, 0) > 1)
        n_seen = doc_seen.get(doc, 0) + 1 if pd.notna(doc) else 1
        if pd.notna(doc):
            doc_seen[doc] = n_seen
        cuenta_iata = (not is_dup) or n_seen == 1

        ep = period_status(fecha, doc, p0, p1, g0, blocks)
        base = {"Fecha Maverick": fecha, "Documento Maverick": doc, "A pagar Maverick": neto, "Tipo TXT": None, "Aerolínea TXT": None, "Fecha IATA": pd.NaT, "Linea TXT": None, "Neto IATA": None, "Diferencia Maverick-IATA": None, "Estado": None, "Estado técnico": None, "Método": "", "Campo control/neto": "", "Importe Cash RFND": None, "Importe CC RFND": None, "Comisión descontada RFND": None, "DET TXT": "", "Bloque TXT": "", "Duplicado Maverick": "SI" if is_dup else "", "Cuenta Neto IATA": "SI" if cuenta_iata else "NO"}

        if pd.isna(doc):
            estado, technical = "NO ENCONTRADO", "SIN_DOCUMENTO_MAVERICK"
        elif ep == "FUERA_PERIODO_IATA":
            estado, technical = "FUERA DE PERIODO", "FUERA_PERIODO_IATA"
        else:
            b = blocks.get(doc)
            if not b:
                estado, technical = "NO ENCONTRADO", "NO EN TXT"
            else:
                tipo = b["Tipo TXT"]
                found, field, method = find_exact(b["DET TXT"], neto)
                aud, afield, ameth = audit_net(b["DET TXT"])
                base.update({"Tipo TXT": tipo, "Aerolínea TXT": b["Aerolínea TXT"], "Fecha IATA": b["Fecha IATA"], "Linea TXT": b["Linea TXT"], "Método": method, "Campo control/neto": field, "DET TXT": b["DET TXT"], "Bloque TXT": b["Bloque TXT"]})

                if tipo in {"ACMA","SPCR"}:
                    val, fld = parse_acma_importe(b["DET TXT"], doc)
                    estado, technical = "ACMA_DETALLE", "ACMA_DETALLE"
                    base["Neto IATA"] = val
                    base["Campo control/neto"] = fld

                elif tipo == "RFND":
                    cash, cc, cash_field, cc_field, metodo_rfnd, comision, campo_com = parse_rfnd_cash_cc(b["DET TXT"])
                    estado, technical = "RFND", "RFND"
                    base["Neto IATA"] = cash
                    base["Importe Cash RFND"] = cash
                    base["Importe CC RFND"] = cc
                    base["Comisión descontada RFND"] = comision
                    base["Método"] = metodo_rfnd
                    base["Campo control/neto"] = cash_field

                elif tipo in {"ADMA","SPDR"}:
                    adm_val, adm_field = parse_adma_importe(b["DET TXT"])
                    base["Neto IATA"] = adm_val
                    base["Campo control/neto"] = adm_field
                    if pd.notna(neto) and adm_val is not None:
                        base["Diferencia Maverick-IATA"] = round(float(neto) - float(adm_val), 2)
                        if abs(base["Diferencia Maverick-IATA"]) <= 0.50:
                            estado, technical = "ADM OK", "ADMA_OK"
                        else:
                            estado, technical = "ADM CON DIFERENCIA", "ADMA_CON_DIFERENCIA"
                    else:
                        estado, technical = "ADM", "ADMA"

                elif tipo in {"CANX","CANN"}:
                    # CANX/CANN en IATA no genera importe a pagar: IATA = 0.
                    # Si Maverick trae un valor, debe quedar como diferencia,
                    # no como simple detalle, porque hay valor en Maverick y cero en IATA.
                    base["Neto IATA"] = 0.0
                    if pd.notna(neto) and abs(float(neto)) > 0.50:
                        base["Diferencia Maverick-IATA"] = round(float(neto), 2)
                        estado = f"{tipo} CON DIFERENCIA"
                        technical = f"{tipo}_CON_DIFERENCIA_MAVERICK_CON_VALOR"
                    else:
                        base["Diferencia Maverick-IATA"] = 0.0 if pd.notna(neto) else None
                        estado = f"{tipo}_DETALLE"
                        technical = estado

                else:
                    if found is not None:
                        estado = "OK"
                        technical = "OK_CERO" if abs(found)<0.01 and pd.notna(neto) and abs(float(neto))<0.01 else "OK"
                        if ep in {"DIA_ANTERIOR_EN_TXT","FUERA_PERIODO_CON_TXT"}:
                            technical += "_FUERA_PERIODO_IATA"
                        base["Neto IATA"] = found
                        base["Diferencia Maverick-IATA"] = round(float(neto)-float(found),2) if pd.notna(neto) else None
                    else:
                        base["Neto IATA"] = aud
                        base["Diferencia Maverick-IATA"] = round(float(neto)-float(aud),2) if (pd.notna(neto) and aud is not None) else None
                        if base["Diferencia Maverick-IATA"] is not None and abs(base["Diferencia Maverick-IATA"]) <= 0.50:
                            estado = "OK"
                            technical = "OK_TOLERANCIA_050"
                        else:
                            estado = "CON DIFERENCIA"
                            technical = "NO ENCONTRE_COSTO_FUERA_PERIODO_IATA" if ep in {"DIA_ANTERIOR_EN_TXT","FUERA_PERIODO_CON_TXT"} else "NO ENCONTRE COSTO"

        if is_dup and not cuenta_iata and ep != "FUERA_PERIODO_IATA" and base.get("Tipo TXT") not in {"ADMA","SPDR"}:
            # No duplicar cobro IATA para líneas Maverick con mismo ticket/base de 10 dígitos.
            # ADM/SPDR duplicados se concilian después por suma grupal.
            estado = "DUPLICADO MAVERICK"
            technical = "DUPLICADO_MAVERICK_NO_SUMA_IATA"
            base["Neto IATA"] = None
            base["Diferencia Maverick-IATA"] = None
            base["Método"] = "duplicado_maverick_no_suma_iata"

        base["Estado"] = estado
        base["Estado técnico"] = technical
        datos_rows.append(base)

        neto_iata_col.append(base["Neto IATA"])
        diferencia_col.append(base["Diferencia Maverick-IATA"])
        estado_col.append(base["Estado"])
        tipo_col.append(base["Tipo TXT"])
        aer_col.append(base["Aerolínea TXT"])
        linea_col.append(base["Linea TXT"])
        metodo_col.append(base["Método"])
        campo_col.append(base["Campo control/neto"])
        dup_flag_col.append(base["Duplicado Maverick"])
        cuenta_iata_col.append(base["Cuenta Neto IATA"])

    datos_leidos = pd.DataFrame(datos_rows)

    # Reconciliación especial duplicados ADM/SPDR:
    # Si Maverick tiene varias líneas con el mismo documento base y en TXT hay un único ADM/SPDR,
    # se compara la suma Maverick contra el ADM IATA. Si cierra con tolerancia 0.50, todas quedan ADM OK.
    if not datos_leidos.empty and "Documento Maverick" in datos_leidos.columns:
        for d, grp in datos_leidos.groupby("Documento Maverick", dropna=True):
            if pd.isna(d) or len(grp) <= 1:
                continue
            idxs = list(grp.index)
            tipos = grp["Tipo TXT"].fillna("").astype(str).str.upper() if "Tipo TXT" in grp.columns else pd.Series([""]*len(grp), index=grp.index)
            if not tipos.isin(["ADMA","SPDR"]).any():
                continue
            iata_vals = pd.to_numeric(grp.get("Neto IATA"), errors="coerce").dropna().unique()
            if len(iata_vals) == 0:
                continue
            iata_val = float(iata_vals[0])
            mav_sum = float(pd.to_numeric(grp["A pagar Maverick"], errors="coerce").fillna(0).sum())
            diff_group = round(mav_sum - iata_val, 2)
            new_estado = "ADM OK" if abs(diff_group) <= 0.50 else "ADM CON DIFERENCIA"
            new_technical = "ADMA_DUP_GRUPO_OK" if abs(diff_group) <= 0.50 else "ADMA_DUP_GRUPO_CON_DIFERENCIA"
            for n_ix, ix in enumerate(idxs):
                # Solo la primera línea muestra el único Neto IATA. Las otras quedan visibles como parte del grupo.
                datos_leidos.at[ix, "Neto IATA"] = iata_val if n_ix == 0 else None
                datos_leidos.at[ix, "Diferencia Maverick-IATA"] = diff_group if n_ix == 0 else None
                datos_leidos.at[ix, "Estado"] = new_estado
                datos_leidos.at[ix, "Estado técnico"] = new_technical
                datos_leidos.at[ix, "Método"] = "adm_duplicado_maverick_conciliado_por_suma"
                datos_leidos.at[ix, "Cuenta Neto IATA"] = "SI" if n_ix == 0 else "NO"



    main = mav0.copy()
    main["Total a pagar Maverick"] = pd.to_numeric(main["Total a pagar Maverick"], errors="coerce").fillna(0.0)
    # Las columnas se toman desde datos_leidos para incorporar ajustes grupales ADM duplicados.
    neto_iata_col = datos_leidos["Neto IATA"].tolist()
    diferencia_col = datos_leidos["Diferencia Maverick-IATA"].tolist()
    estado_col = datos_leidos["Estado"].tolist()
    tipo_col = datos_leidos["Tipo TXT"].tolist()
    aer_col = datos_leidos["Aerolínea TXT"].tolist()
    linea_col = datos_leidos["Linea TXT"].tolist()
    metodo_col = datos_leidos["Método"].tolist()
    campo_col = datos_leidos["Campo control/neto"].tolist()
    dup_flag_col = datos_leidos["Duplicado Maverick"].tolist()
    cuenta_iata_col = datos_leidos["Cuenta Neto IATA"].tolist()
    main["Neto IATA"] = neto_iata_col
    main["Diferencia Maverick-IATA"] = diferencia_col
    main["Estado"] = estado_col
    main["Tipo TXT"] = tipo_col
    main["Aerolínea TXT"] = aer_col
    main["Línea TXT"] = linea_col
    main["Método"] = metodo_col
    main["Campo control/neto"] = campo_col
    main["Duplicado Maverick"] = dup_flag_col
    main["Cuenta Neto IATA"] = cuenta_iata_col
    main["Estado RFND Maverick"] = ""
    try:
        mask_rfnd_main = main["Tipo TXT"].fillna("").astype(str).str.upper().eq("RFND")
        main.loc[mask_rfnd_main, "Estado RFND Maverick"] = "RFND en Maveric"
    except Exception:
        pass

    txt_rows=[]
    for doc, b in blocks.items():
        aud, afield, ameth = audit_net(b.get("DET TXT",""))
        adma_val=adma_field=acma_val=acma_field=rfnd_cash=rfnd_cc=rfnd_cash_field=rfnd_cc_field=rfnd_method=comision=campo_com=None
        if b["Tipo TXT"] in {"ADMA","SPDR"}:
            adma_val, adma_field = parse_adma_importe(b.get("DET TXT",""))
            aud, afield = adma_val, adma_field
        if b["Tipo TXT"] in {"ACMA","SPCR"}:
            acma_val, acma_field = parse_acma_importe(b.get("DET TXT",""), doc)
        if b["Tipo TXT"] == "RFND":
            rfnd_cash, rfnd_cc, rfnd_cash_field, rfnd_cc_field, rfnd_method, comision, campo_com = parse_rfnd_cash_cc(b.get("DET TXT",""))
        txt_rows.append({"Documento IATA": doc, "Tipo TXT": b["Tipo TXT"], "Aerolínea TXT": b["Aerolínea TXT"], "Fecha IATA": b["Fecha IATA"], "Linea TXT": b["Linea TXT"], "Neto posicional auditoría": aud, "Importe ADM": adma_val, "Importe ACM": acma_val, "Campo ACM": acma_field, "Importe Cash RFND": rfnd_cash, "Importe CC RFND": rfnd_cc, "Comisión descontada RFND": comision, "Campo Cash RFND": rfnd_cash_field, "Campo CC RFND": rfnd_cc_field, "Campo Comisión RFND": campo_com, "Metodo RFND": rfnd_method, "Metodo neto posicional": ameth, "Campo control/neto": afield, "Candidatos DET": " | ".join(f"{x:.2f}" for x in candidates(b.get("DET TXT",""))[:80]), "DET TXT": b.get("DET TXT"), "Bloque TXT": b.get("Bloque TXT")})
    txt_leido = pd.DataFrame(txt_rows)

    mav_docs = set(mav["_Documento Maverick"].dropna())
    not_in_mav = txt_leido[~txt_leido["Documento IATA"].isin(mav_docs)].copy()
    faltan_en_maverick = not_in_mav[~not_in_mav["Tipo TXT"].isin(["ADMA","SPDR","ACMA","SPCR","CANX","CANN","RFND"])].copy()
    acma_sheet = acma_sheet_from_txt(txt_leido)
    rfnd_sheet = rfnd_sheet_from_txt(txt_leido)
    # Ajuste final de estados Maverick:
    # - dentro del período y sin TXT: NO ENCONTRADO EN IATA
    # - fuera del período y sin TXT: FUERA DE PERIODO
    try:
        fecha_main = pd.to_datetime(main["Fecha"], errors="coerce")
        mask_no = main["Estado"].astype(str).eq("NO ENCONTRADO")
        mask_in_period = fecha_main.between(p0, p1)
        main.loc[mask_no & mask_in_period, "Estado"] = "NO ENCONTRADO EN IATA"
        main.loc[mask_no & ~mask_in_period, "Estado"] = "FUERA DE PERIODO"
    except Exception:
        pass

    # Duplicados Maverick: no considerar duplicados fuera del período que no estén en TXT.
    try:
        fecha_main = pd.to_datetime(main["Fecha"], errors="coerce")
        mask_fuera_sin_txt = main["Estado"].astype(str).eq("FUERA DE PERIODO")
        main.loc[mask_fuera_sin_txt, "Duplicado Maverick"] = ""
        main.loc[mask_fuera_sin_txt, "Cuenta Neto IATA"] = "NO"
    except Exception:
        pass

    duplicados_maverick = main[main["Duplicado Maverick"].astype(str).eq("SI")].copy()

    resumen = pd.DataFrame([
        ["Periodo IATA desde", p0], ["Periodo IATA hasta", p1],
        ["Total filas Maverick originales", len(mav0)], ["OK", int((main["Estado"]=="OK").sum())],
        ["CON DIFERENCIA", int((main["Estado"]=="CON DIFERENCIA").sum())],
        ["ADM OK", int((main["Estado"]=="ADM OK").sum())],
        ["ADM CON DIFERENCIA", int((main["Estado"]=="ADM CON DIFERENCIA").sum())],
        ["DUPLICADO MAVERICK", int((main["Estado"]=="DUPLICADO MAVERICK").sum())],
        ["NO ENCONTRADO EN IATA", int((main["Estado"]=="NO ENCONTRADO EN IATA").sum())],
        ["FUERA DE PERIODO", int((main["Estado"]=="FUERA DE PERIODO").sum())], ["ADMA", int((txt_leido["Tipo TXT"].isin(["ADMA","SPDR"])).sum())],
        ["RFND", int((txt_leido["Tipo TXT"]=="RFND").sum())], ["ACMA/SPCR", int((txt_leido["Tipo TXT"].isin(["ACMA","SPCR"])).sum())],
        ["Faltan en Maverick TKTT/EMD", len(faltan_en_maverick)]
    ], columns=["Concepto","Cantidad"])

    return {
        "Resumen": resumen,
        "Espejo maverick conciliado": main,
        "Con_Diferencia": main[main["Estado"].isin(["CON DIFERENCIA","ADM CON DIFERENCIA"])].copy(),
        "No encontrada en periodo IATA": main[main["Estado"]=="NO ENCONTRADO EN IATA"].copy(),
        "Fuera de Periodo IATA": main[main["Estado"]=="FUERA DE PERIODO"].copy(),
        "Duplicados_Maverick": duplicados_maverick,
        "Faltan_en_Maverick": faltan_en_maverick,
        "TKTT": txt_leido[txt_leido["Tipo TXT"]=="TKTT"].copy(),
        "RFND": rfnd_sheet,
        "ACMA": acma_sheet,
        "ADMA": txt_leido[txt_leido["Tipo TXT"].isin(["ADMA","SPDR"])].copy(),
        "CANX": txt_leido[txt_leido["Tipo TXT"]=="CANX"].copy(),
        "CANN": txt_leido[txt_leido["Tipo TXT"]=="CANN"].copy(),
        "EMDS": txt_leido[txt_leido["Tipo TXT"]=="EMDS"].copy(),
        "EMDA": txt_leido[txt_leido["Tipo TXT"]=="EMDA"].copy(),
        "Control_ACMA_RFND": txt_leido[txt_leido["Tipo TXT"].isin(["ACMA","SPCR","RFND"])].copy(),
        "TXT_Leido": txt_leido,
        "Datos_leidos": datos_leidos,
    }


# ============================
# CAPA CONTABLE TUKI v2.8
# No toca la lógica de conciliación. Solo ordena hojas, columnas y resumen.
# ============================

AIR_NUM_TUKI = {
    "001":"American Airlines","006":"Delta Air Lines","014":"Air Canada","016":"United Airlines",
    "044":"Aerolineas Argentinas","045":"LATAM Airlines Group","047":"TAP Air Portugal","057":"Air France","071":"Ethiopian Airlines",
    "075":"IBERIA","125":"British Airways","127":"GOL Linhas Aereas","134":"Avianca","139":"Aeromexico",
    "157":"Qatar Airways","169":"Hahn Air Lines","176":"Emirates","220":"Lufthansa","230":"COPA Airlines",
    "235":"Turkish Airlines","275":"APG Airlines","291":"Euroairlines","365":"FlexFlight","445":"Paranair",
    "577":"Azul Brazilian Airlines","589":"Jet Airways","605":"SKY","633":"Código 633","692":"Latam PY",
    "888":"EasyJet","973":"JetSmart","974":"JetSmart","996":"Air Europa"
}
AIR_ALPHA_TUKI = {
    "AA":"American Airlines","AC":"Air Canada","AD":"Azul Brazilian Airlines","AF":"Air France",
    "AM":"Aeromexico","AR":"Aerolineas Argentinas","AV":"Avianca","BA":"British Airways",
    "CM":"COPA Airlines","DL":"Delta Air Lines","EK":"Emirates","G3":"GOL Linhas Aereas",
    "GP":"APG Airlines","H2":"SKY","HR":"Hahn Air Lines","IB":"IBERIA","JJ":"LATAM Airlines Brasil",
    "LA":"LATAM Airlines Group","LH":"Lufthansa","LP":"LATAM Airlines Peru","PZ":"LATAM Airlines Paraguay",
    "QR":"Qatar Airways","TK":"Turkish Airlines","UA":"United Airlines","UX":"Air Europa",
    "W2":"FlexFlight","XL":"LATAM Airlines Ecuador","ZP":"Paranair"
}

def tuki_airline_from_code(code):
    if code is None or str(code).strip() == "":
        return "NO COMPAÑIA"
    c = str(code).strip().upper()
    if c.isdigit():
        c = c.zfill(3)
        return AIR_NUM_TUKI.get(c, f"FALTA NOMBRE {c}")
    return AIR_ALPHA_TUKI.get(c, f"FALTA NOMBRE {c}")

def tuki_code_from_boleto(v):
    s = str(v or "").strip().upper()
    if "ADM" in s or "-" not in s:
        return None
    m = re.match(r"^([A-Z0-9]{2,3})-", s)
    return m.group(1) if m else None

def tuki_doc_digits(v):
    s = str(v or "")
    m = re.search(r"(\d{10,13})", s)
    return m.group(1) if m else ""

def tuki_det_code(row):
    for col in ["Código compañía", "Codigo compañía", "Codigo compania", "Código", "Codigo", "Sigla"]:
        if col in row.index and pd.notna(row.get(col)):
            raw = str(row.get(col)).strip().upper()
            if raw:
                if raw in {"JA", "0JA"}:
                    return "JA"
                if raw.isdigit():
                    return raw.zfill(3)
                return raw
    if "Aerolínea" in row.index and pd.notna(row.get("Aerolínea")):
        val = str(row.get("Aerolínea")).strip().upper()
        if val in {"JA", "0JA"}:
            return "JA"
        if val.isdigit():
            return val.zfill(3)
    for k in ["DET TXT", "Linea TXT", "Línea TXT"]:
        if k in row.index and pd.notna(row.get(k)):
            m = re.search(r"DET(\d{3})", str(row.get(k)))
            if m:
                return m.group(1)
    return None

def tuki_emitido_en(row):
    txt = ""
    for k in ["DET TXT", "Linea TXT", "Línea TXT"]:
        if k in row.index and pd.notna(row.get(k)):
            txt += " " + str(row.get(k)).upper()
    if "WEB" in txt or "FLGXBSP" in txt:
        return "WEB"
    if "BSP" in txt:
        return "BSP"
    return "???"

def tuki_drop_cols(df, cols):
    return df.drop(columns=[c for c in cols if c in df.columns], errors="ignore")

def tuki_move_to_end(df, cols):
    present = [c for c in cols if c in df.columns]
    return df[[c for c in df.columns if c not in present] + present]


def tuki_rfnd_boleto_from_line(row):
    txt = ""
    for k in ["DET TXT", "Linea TXT", "Línea TXT"]:
        if k in row.index and pd.notna(row.get(k)):
            txt += " " + str(row.get(k))
    # v3.6: tomar literalmente el billete informado por IATA tras RF + codigo de compania.
    # Se conserva incluso cuando coincide con el propio RFND (ej. RF04522047023511200).
    m = re.search(r"RF(\d{3})(\d{10})", txt)
    return m.group(2) if m else ""

def tuki_order_cols(df, desired):
    return df[[c for c in desired if c in df.columns] + [c for c in df.columns if c not in desired]]

def tuki_rename_first(df, names, new_name):
    df = df.copy()
    for n in names:
        if n in df.columns:
            return df.rename(columns={n:new_name})
    return df


def tuki_add_airline_mav(df):
    df = df.copy()
    for c in list(df.columns):
        if str(c).strip().lower() in {
            "aerolínea","aerolinea","aerolínea nombre","aerolinea nombre",
            "código compañía","codigo compañía","codigo compania","aerolínea txt","aerolinea txt"
        }:
            df = df.drop(columns=[c])
    names = []
    if len(df):
        for _, row in df.iterrows():
            tipo = str(row.get("Tipo TXT","")).upper()
            estado = str(row.get("Estado","")).upper()
            boleto = row.get("Boleto")
            if "ADM" in tipo or "ADM" in estado:
                names.append("ADM")
            elif "Boleto" in df.columns:
                code = tuki_code_from_boleto(boleto)
                names.append(tuki_airline_from_code(code) if code else "NO COMPAÑIA")
            else:
                names.append("NO COMPAÑIA")
    if "Estado" in df.columns:
        idx = list(df.columns).index("Estado") + 1
        df.insert(idx, "Aerolínea", names)
    else:
        df["Aerolínea"] = names
    return df


def tuki_add_airline_iata(df):
    df = df.copy()
    for c in list(df.columns):
        if str(c).strip().lower() in {"aerolínea","aerolinea","aerolínea nombre","aerolinea nombre","aerolínea txt","aerolinea txt"}:
            df = df.drop(columns=[c])
    names = [tuki_airline_from_code(tuki_det_code(row)) for _, row in df.iterrows()]
    if "Código compañía" in df.columns:
        idx = list(df.columns).index("Código compañía") + 1
    elif "Documento IATA" in df.columns:
        idx = list(df.columns).index("Documento IATA") + 1
    else:
        idx = min(3, len(df.columns))
    df.insert(idx, "Aerolínea", names)
    return df

def tuki_numeric_sum(df, col):
    if df is None or col not in df.columns:
        return 0.0
    return float(pd.to_numeric(df[col], errors="coerce").fillna(0).sum())



# --- Parche v3.3.3: normalización final de códigos de compañía ---
def _tuki_fix_airline_name_by_code_final(row):
    # Busca código en columnas típicas o en documento/DET.
    code = ""
    for col in ["Código Aerolínea", "Codigo Aerolinea", "Código", "Codigo", "Prefijo", "Aerolínea Código"]:
        try:
            val = row.get(col, "")
            if pd.notna(val) and str(val).strip():
                code = str(val).strip().zfill(3)[-3:]
                break
        except Exception:
            pass

    if not code:
        # Si no hay columna código, intentar extraerlo del DET TXT: RF/AC/SP + 3 dígitos, o DET + 3 dígitos.
        txt_det = str(row.get("DET TXT", "") or row.get("Linea TXT", "") or "")
        m = re.search(r"(?:RF|AC|AD|SP)(\d{3})", txt_det)
        if not m:
            m = re.search(r"^DET(\d{3})", txt_det)
        if m:
            code = m.group(1)

    if code == "083":
        return "SOUTH AFRICAN AIRWAYS"
    if code == "952":
        return "IATA"

    try:
        current = row.get("Aerolínea", row.get("Aerolínea TXT", ""))
        if isinstance(current, str) and current.strip().upper().startswith("FALTA NOMBRE"):
            c2 = re.sub(r"\D", "", current)
            if c2.endswith("083"):
                return "SOUTH AFRICAN AIRWAYS"
            if c2.endswith("952"):
                return "IATA"
    except Exception:
        pass

    return None

def _tuki_apply_airline_code_fixes(df):
    try:
        if df is None or df.empty:
            return df
        out = df.copy()
        target_cols = [c for c in ["Aerolínea", "Aerolínea TXT", "Compañia Aerea", "Compañía aérea"] if c in out.columns]
        if not target_cols:
            return out
        target = target_cols[0]
        for idx, row in out.iterrows():
            fixed = _tuki_fix_airline_name_by_code_final(row)
            if fixed:
                out.at[idx, target] = fixed
        return out
    except Exception:
        return df

# Reforzar función principal si existe.
try:
    _tuki_airline_from_code_base_333 = tuki_airline_from_code
    def tuki_airline_from_code(code):
        c = str(code or "").strip().zfill(3)
        if c == "083":
            return "SOUTH AFRICAN AIRWAYS"
        if c == "952":
            return "IATA"
        return _tuki_airline_from_code_base_333(code)
except Exception:
    pass



# --- Parche v3.3.4: JA = Jetsmart / código 973 ---
try:
    _tuki_airline_from_code_base_334 = tuki_airline_from_code
    def tuki_airline_from_code(code):
        c_raw = str(code or "").strip().upper()
        c = c_raw.zfill(3)
        if c_raw == "JA" or c == "973":
            return "Jetsmart"
        if c == "083":
            return "SOUTH AFRICAN AIRWAYS"
        if c == "952":
            return "IATA"
        return _tuki_airline_from_code_base_334(code)
except Exception:
    pass

try:
    _tuki_apply_airline_code_fixes_base_334 = _tuki_apply_airline_code_fixes
    def _tuki_apply_airline_code_fixes(df):
        out = _tuki_apply_airline_code_fixes_base_334(df)
        try:
            if out is None or out.empty:
                return out
            target_cols = [c for c in ["Aerolínea", "Aerolínea TXT", "Compañia Aerea", "Compañía aérea"] if c in out.columns]
            if not target_cols:
                return out
            target = target_cols[0]
            for idx, row in out.iterrows():
                vals = " ".join([str(row.get(c, "")) for c in out.columns if c in ["Aerolínea", "Aerolínea TXT", "DET TXT", "Linea TXT", "Código", "Codigo", "Código Aerolínea"]])
                vals_u = vals.upper()
                if "FALTA NOMBRE JA" in vals_u or re.search(r"\bJA\b", vals_u):
                    out.at[idx, target] = "Jetsmart"
                if "FALTA NOMBRE 973" in vals_u or re.search(r"DET973|RF973|AC973|AD973|SP973", vals_u):
                    out.at[idx, target] = "Jetsmart"
                if "FALTA NOMBRE 083" in vals_u or re.search(r"DET083|RF083|AC083|AD083|SP083", vals_u):
                    out.at[idx, target] = "SOUTH AFRICAN AIRWAYS"
                if "FALTA NOMBRE 952" in vals_u or re.search(r"DET952|RF952|AC952|AD952|SP952", vals_u):
                    out.at[idx, target] = "IATA"
            return out
        except Exception:
            return out
except Exception:
    pass



# --- Parche v3.3.5: normalización definitiva de compañías ---
def _tuki_company_fixed_name(code_or_text):
    """
    FIX v3.3.6:
    No usar terminaciones de documento/boleto para mapear compañía.
    Solo mapear si viene como código explícito o patrón DET/RF/AC/AD/SP.
    """
    s = str(code_or_text or "").strip().upper()
    s_clean = s.replace("FALTA NOMBRE", "").strip()
    if s in {"JA", "0JA"} or s_clean in {"JA", "0JA"} or "JA-" in s or re.fullmatch(r"JA", s_clean or ""):
        return "Jetsmart"
    if re.search(r"(?:DET|RF|AC|AD|SP)973", s):
        return "Jetsmart"
    if re.search(r"(?:DET|RF|AC|AD|SP)083", s):
        return "SOUTH AFRICAN AIRWAYS"
    if re.search(r"(?:DET|RF|AC|AD|SP)952", s):
        return "IATA"
    if re.search(r"(?:DET|RF|AC|AD|SP)169", s):
        return "Hahn Air Lines"
    if re.search(r"(?:DET|RF|AC|AD|SP)692", s):
        return "Latam PY"
    if re.search(r"(?:DET|RF|AC|AD|SP)799", s):
        return "SPDR IATA"
    if s_clean in {"HR", "169"} or "FALTA NOMBRE HR" in s or "HR-" in s:
        return "Hahn Air Lines"
    if s_clean == "692" or "FALTA NOMBRE 692" in s:
        return "Latam PY"
    if s_clean == "799":
        return "SPDR IATA"
    if "FALTA NOMBRE 799" in s:
        return "SPDR IATA"
    if s_clean == "973":
        return "Jetsmart"
    if s_clean == "083":
        return "SOUTH AFRICAN AIRWAYS"
    if s_clean == "952":
        return "IATA"
    return None


def _tuki_apply_company_names_final(df):
    try:
        if df is None or df.empty:
            return df
        out = df.copy()
        target_cols = [c for c in ["Aerolínea", "Aerolínea TXT", "Compañia Aerea", "Compañía aérea", "Compañía"] if c in out.columns]
        if not target_cols:
            return out
        target = target_cols[0]
        scan_cols = [c for c in [
            "Código compañía", "Codigo compañía", "Codigo compania", "Código", "Codigo", "Sigla",
            "Aerolínea", "Aerolínea TXT", "Compañia Aerea", "Compañía aérea", "Compañía",
            "DET TXT", "Linea TXT", "Línea TXT", "Boleto", "Documento IATA", "Número de billete"
        ] if c in out.columns]
        for idx, row in out.iterrows():
            fixed = None
            for col in scan_cols:
                fixed = _tuki_company_fixed_name(row.get(col, ""))
                if fixed:
                    break
            if fixed:
                out.at[idx, target] = fixed
        # reemplazo de texto por si quedó en otra columna visible
        for col in out.columns:
            if out[col].dtype == object:
                out[col] = out[col].replace({
                    "FALTA NOMBRE JA": "Jetsmart",
                    "FALTA NOMBRE 0JA": "Jetsmart",
                    "FALTA NOMBRE 973": "Jetsmart",
                    "FALTA NOMBRE 083": "SOUTH AFRICAN AIRWAYS",
                    "FALTA NOMBRE 952": "IATA",
                    "FALTA NOMBRE HR": "Hahn Air Lines",
                    "FALTA NOMBRE 169": "Hahn Air Lines",
                    "FALTA NOMBRE 692": "Latam PY",
                    "FALTA NOMBRE 799": "SPDR IATA",
                    "FALTA NOMBRE 799": "SPDR IATA",
                    "International Air Transport As": "SPDR IATA",
                })
        return out
    except Exception:
        return df



# --- Parche v3.3.6: totales finales por hoja ---
def _tuki_norm_col_name(c):
    return re.sub(r"[^a-z0-9]", "", str(c or "").lower())

def _tuki_find_col(df, candidates):
    norm_map = {_tuki_norm_col_name(c): c for c in df.columns}
    for cand in candidates:
        n = _tuki_norm_col_name(cand)
        if n in norm_map:
            return norm_map[n]
    for cand in candidates:
        n = _tuki_norm_col_name(cand)
        for k, real in norm_map.items():
            if n and (n in k or k in n):
                return real
    return None

def _tuki_add_total_row(df, columns_to_sum):
    try:
        if df is None or df.empty:
            return df
        out = df.copy()
        cols = []
        for cand_list in columns_to_sum:
            col = _tuki_find_col(out, cand_list if isinstance(cand_list, (list, tuple)) else [cand_list])
            if col and col in out.columns and col not in cols:
                cols.append(col)
        if not cols:
            return out
        total = {c: "" for c in out.columns}
        if len(out.columns) > 0:
            total[out.columns[0]] = "TOTAL"
        for col in cols:
            vals = pd.to_numeric(out[col], errors="coerce")
            total[col] = float(vals.sum(skipna=True))
        return pd.concat([out, pd.DataFrame([total])], ignore_index=True)
    except Exception:
        return df





def _tuki_fix_resumen_diferencias_count(out):
    """
    Actualiza SOLO la fila general 'CON DIFERENCIA' del Resumen usando la hoja Diferencias.
    No toca filas específicas como 'ADM CON DIFERENCIA', 'RFND CON DIFERENCIA', etc.
    """
    try:
        if not isinstance(out, dict):
            return out
        if "Resumen" not in out or "Diferencias" not in out:
            return out
        res = out.get("Resumen")
        dif = out.get("Diferencias")
        if res is None or dif is None or not isinstance(res, pd.DataFrame) or not isinstance(dif, pd.DataFrame):
            return out

        res = res.copy()
        diff_count = int(len(dif))

        for idx in res.index:
            vals = [str(x).strip().upper() for x in res.loc[idx].tolist()]
            # Exacto: solo la fila general, no ADM CON DIFERENCIA ni similares.
            if "CON DIFERENCIA" not in vals:
                continue

            done = False
            for col in res.columns:
                cname = str(col).lower()
                if any(k in cname for k in ["cantidad", "cant", "total", "valor", "conteo", "docs", "documentos"]):
                    try:
                        res.at[idx, col] = diff_count
                        done = True
                    except Exception:
                        pass
            if not done and len(res.columns) > 1:
                try:
                    res.at[idx, res.columns[-1]] = diff_count
                except Exception:
                    pass

        out["Resumen"] = res
        return out
    except Exception:
        return out


def _tuki_tktt_post_i_net_from_det(det):
    """
    Lee el primer campo de 11 dígitos posterior al marcador ' I '.
    En TKTT grandes puede traer el neto correcto:
      I 00001507560000000000000 => 15075.60
    Evita truncamientos tipo 5075.60.
    """
    try:
        s = str(det or "")
        # buscar zona después de ' I ' o ' I' seguido de espacios
        m = re.search(r"\sI\s+([0-9]{11})", s)
        if not m:
            return None, ""
        fld = m.group(1)
        val = int(fld) / 100.0
        if val > 0 and val < 1000000:
            return round(val, 2), fld
        return None, fld
    except Exception:
        return None, ""


def _tuki_fix_espejo_tktt_from_txt_leido(out):
    """
    Corrige Espejo Maverick para TKTT usando el Neto IATA ya calculado en TXT Leido/TKTT.

    Motivo:
    La hoja TKTT/TXT Leido tenía bien el neto IATA, pero Espejo Maverick podía recalcular
    o enganchar un campo auxiliar por importe de Maverick, generando falsos:
      - 0.10 / 0.39
      - 109.00 en lugar de 107.91
    No se cambia la lógica de TKTT. Solo se reutiliza el resultado correcto ya leído.

    Clave:
    Documento IATA / Boleto + Tipo TXT + ocurrencia.
    """
    try:
        if not isinstance(out, dict):
            return out
        if "Espejo Maverick" not in out:
            return out

        mav = out.get("Espejo Maverick")
        if mav is None or not isinstance(mav, pd.DataFrame) or mav.empty:
            return out

        # Buscar hoja fuente con los valores ya bien calculados.
        src_df = None
        for k in ["TXT Leido", "TXT_Leido", "TKTT", "TKT"]:
            if k in out and isinstance(out[k], pd.DataFrame) and not out[k].empty:
                src_df = out[k].copy()
                break
        if src_df is None:
            return out

        # Detectar columnas fuente.
        doc_col = None
        for c in ["Documento IATA", "Boleto", "Número de billete", "Numero de billete"]:
            if c in src_df.columns:
                doc_col = c
                break
        if doc_col is None:
            return out

        tipo_col = None
        for c in ["Tipo TXT", "Tipo"]:
            if c in src_df.columns:
                tipo_col = c
                break

        net_col = None
        for c in ["Neto IATA", "Audit net", "Neto", "Importe IATA"]:
            if c in src_df.columns:
                net_col = c
                break
        if net_col is None:
            # En algunas versiones el neto TKTT queda como Audit net.
            numeric_candidates = [c for c in src_df.columns if str(c).lower() in {"audit net", "neto iata", "neto"}]
            net_col = numeric_candidates[0] if numeric_candidates else None
        if net_col is None:
            return out

        det_col = "DET TXT" if "DET TXT" in src_df.columns else None
        metodo_col = "Método" if "Método" in src_df.columns else ("Metodo" if "Metodo" in src_df.columns else None)
        campo_col = "Campo control/neto" if "Campo control/neto" in src_df.columns else None

        src2 = src_df.copy()
        src2["_doc_key_fix"] = src2[doc_col].astype(str).str.replace(r"\.0$", "", regex=True).str.extract(r"(\d{10,13})", expand=False).fillna("")
        if tipo_col:
            src2["_tipo_fix"] = src2[tipo_col].astype(str).str.upper()
            src2 = src2[src2["_tipo_fix"].eq("TKTT")]
        # Solo documentos con clave.
        src2 = src2[src2["_doc_key_fix"].ne("")]
        if src2.empty:
            return out

        # Si hay duplicados, conservar orden y ocurrencia.
        src2["_occ_fix"] = src2.groupby(["_doc_key_fix"]).cumcount() + 1

        mav2 = mav.copy()
        if "Boleto" not in mav2.columns:
            return out
        mav2["_doc_key_fix"] = mav2["Boleto"].astype(str).str.replace(r"\.0$", "", regex=True).str.extract(r"(\d{10,13})", expand=False).fillna("")
        # Espejo también puede tener ocurrencias repetidas por mismo boleto.
        mav2["_occ_fix"] = mav2.groupby(["_doc_key_fix"]).cumcount() + 1

        # Mapa por doc + ocurrencia; fallback por doc si único.
        map_cols = ["_doc_key_fix", "_occ_fix", net_col]
        if det_col: map_cols.append(det_col)
        if metodo_col: map_cols.append(metodo_col)
        if campo_col: map_cols.append(campo_col)
        src_map = src2[map_cols].copy()

        mav2 = mav2.merge(src_map, on=["_doc_key_fix", "_occ_fix"], how="left", suffixes=("", "_txtfix"))

        # Aplicar solo donde hay valor fuente TKTT.
        net_fix_col = net_col if net_col not in mav.columns else f"{net_col}_txtfix"
        if net_fix_col not in mav2.columns:
            net_fix_col = net_col

        mask = pd.to_numeric(mav2.get(net_fix_col), errors="coerce").notna()

        # Evitar tocar ADM/RFND/ACM/CANX si estuvieran mezclados: solo si la fuente viene de TKTT.
        if "Tipo TXT" in mav2.columns:
            # si ya existe tipo en espejo, aplicar cuando es TKTT o vacío pero hay fuente.
            tipo_m = mav2["Tipo TXT"].astype(str).str.upper()
            mask = mask & (tipo_m.eq("TKTT") | tipo_m.eq("") | tipo_m.eq("NAN"))

        if "Neto IATA" in mav2.columns:
            mav2.loc[mask, "Neto IATA"] = pd.to_numeric(mav2.loc[mask, net_fix_col], errors="coerce")

            # Corrección TKTT montos grandes:
            # si DET TXT trae un campo posterior a I más grande que el neto heredado,
            # usarlo como Neto IATA correcto. Ej: 5075.60 -> 15075.60.
            if "DET TXT" in mav2.columns:
                for _idx in mav2.index[mask]:
                    try:
                        current_val = pd.to_numeric(pd.Series([mav2.at[_idx, "Neto IATA"]]), errors="coerce").iloc[0]
                        det_val, det_field = _tuki_tktt_post_i_net_from_det(mav2.at[_idx, "DET TXT"])
                        if det_val is not None and pd.notna(current_val) and det_val > float(current_val) and (det_val - float(current_val)) >= 1000:
                            mav2.at[_idx, "Neto IATA"] = det_val
                            if "Campo control/neto" in mav2.columns:
                                mav2.at[_idx, "Campo control/neto"] = det_field
                            if "Método" in mav2.columns:
                                mav2.at[_idx, "Método"] = "tktt_post_i_neto_monto_grande"
                    except Exception:
                        pass

        if "Total a pagar Maverick" in mav2.columns and "Diferencia Maverick-IATA" in mav2.columns:
            mav2.loc[mask, "Diferencia Maverick-IATA"] = (
                pd.to_numeric(mav2.loc[mask, "Total a pagar Maverick"], errors="coerce").fillna(0)
                - pd.to_numeric(mav2.loc[mask, "Neto IATA"], errors="coerce").fillna(0)
            ).round(2)

        if "Estado" in mav2.columns and "Diferencia Maverick-IATA" in mav2.columns:
            diff_abs = pd.to_numeric(mav2["Diferencia Maverick-IATA"], errors="coerce").abs()
            mav2.loc[mask & (diff_abs <= 0.50), "Estado"] = "OK"
            mav2.loc[mask & (diff_abs > 0.50), "Estado"] = "CON DIFERENCIA"

        if "Método" in mav2.columns:
            mav2.loc[mask, "Método"] = "tktt_desde_txt_leido_misma_logica"
        if campo_col and campo_col in mav2.columns:
            fix_c = campo_col if campo_col not in mav.columns else f"{campo_col}_txtfix"
            if fix_c in mav2.columns:
                mav2.loc[mask, campo_col] = mav2.loc[mask, fix_c]
        if det_col:
            fix_det = det_col if det_col not in mav.columns else f"{det_col}_txtfix"
            if "DET TXT" not in mav2.columns:
                mav2["DET TXT"] = ""
            if fix_det in mav2.columns:
                mav2.loc[mask, "DET TXT"] = mav2.loc[mask, fix_det]

        # Limpiar columnas auxiliares/merge.
        drop_cols = [c for c in mav2.columns if c.endswith("_txtfix") or c in ["_doc_key_fix", "_occ_fix"]]
        mav2 = mav2.drop(columns=drop_cols, errors="ignore")

        out["Espejo Maverick"] = mav2
        return out
    except Exception:
        return out



def _tuki_append_resumen_iata_conciliador_check(out, total_rfnd_cash, total_rfnd_cc, total_adm, total_acm, total_a_pagar_iata):
    """
    Agrega al final de Resumen IATA:
      - fila en blanco
      - TOTAL SEGUN CONCILIADOR
      - DIFERENCIA CONCILIADOR-PDF

    Compara contra la fila TOTAL del PDF ya parseado.
    No toca la lógica de cálculo; solo cruza los totales que ya bajó el conciliador.
    """
    try:
        if not isinstance(out, dict) or "Resumen IATA" not in out:
            return out
        df = out.get("Resumen IATA")
        if df is None or not isinstance(df, pd.DataFrame) or df.empty:
            return out

        df = df.copy()
        cols = list(df.columns)

        def empty_row():
            return {c: "" for c in cols}

        def set_if_col(row, col, val):
            if col in row:
                row[col] = val

        # Buscar la fila TOTAL del PDF/resumen oficial.
        total_pdf = None
        try:
            mask = pd.Series([False] * len(df))
            if "Categoria" in df.columns:
                mask = mask | df["Categoria"].astype(str).str.upper().eq("TOTAL")
            if "Compañia" in df.columns:
                mask = mask | df["Compañia"].astype(str).str.upper().eq("TOTAL")
            if mask.any():
                total_pdf = df.loc[mask].iloc[-1]
        except Exception:
            total_pdf = None

        check_cols = ["RFND Cash", "RFND CC", "RFND Total", "ADMS", "ACM", "Neto a pagar"]
        conc_vals = {
            "RFND Cash": round(float(total_rfnd_cash or 0), 2),
            "RFND CC": round(float(total_rfnd_cc or 0), 2),
            "RFND Total": round(float((total_rfnd_cash or 0) + (total_rfnd_cc or 0)), 2),
            "ADMS": round(float(total_adm or 0), 2),
            "ACM": round(float(total_acm or 0), 2),
            "Neto a pagar": round(float(total_a_pagar_iata or 0), 2),
        }

        blank = empty_row()

        conc_row = empty_row()
        set_if_col(conc_row, "Categoria", "TOTAL SEGUN CONCILIADOR")
        set_if_col(conc_row, "Compañia", "TOTAL SEGUN CONCILIADOR")
        set_if_col(conc_row, "FOP", "")
        for c in check_cols:
            if c in conc_row:
                conc_row[c] = conc_vals[c]

        diff_row = empty_row()
        set_if_col(diff_row, "Categoria", "DIFERENCIA CONCILIADOR-PDF")
        set_if_col(diff_row, "Compañia", "DIFERENCIA CONCILIADOR-PDF")
        set_if_col(diff_row, "FOP", "")
        for c in check_cols:
            if c not in diff_row:
                continue
            pdf_val = 0.0
            if total_pdf is not None and c in df.columns:
                try:
                    pdf_val = float(pd.to_numeric(pd.Series([total_pdf.get(c)]), errors="coerce").fillna(0).iloc[0])
                except Exception:
                    pdf_val = 0.0
            diff = round(conc_vals[c] - pdf_val, 2)
            diff_row[c] = "OK" if abs(diff) < 0.01 else diff

        # Evitar duplicar si el usuario vuelve a generar usando una hoja ya enriquecida.
        try:
            if "Categoria" in df.columns:
                df = df[~df["Categoria"].astype(str).str.upper().isin(["TOTAL SEGUN CONCILIADOR", "DIFERENCIA CONCILIADOR-PDF"])]
        except Exception:
            pass

        out["Resumen IATA"] = pd.concat([df, pd.DataFrame([blank, conc_row, diff_row], columns=cols)], ignore_index=True)
        return out
    except Exception:
        return out


def _tuki_apply_total_rows_to_sheets(out):
    try:
        if not isinstance(out, dict):
            return out
        rules = {
            "espejo": [
                ["Monto tarjeta", "Monto Tarjeta", "Monto tarjeta Maverick"],
                ["Costo de Res.", "Costo reserva", "Costo reserva Maverick"],
                ["Total a pagar Maverick", "Total a pagar Maveric"],
                ["Neto IATA", "Neto IATA según Maverick", "A pagar IATA"],
                ["Diferencia", "Diferencia Maverick-IATA"],
            ],
            "diferencias": [
                ["Monto tarjeta", "Monto Tarjeta", "Monto tarjeta Maverick"],
                ["Costo de Res.", "Costo reserva", "Costo reserva Maverick"],
                ["Total a pagar Maverick", "Total a pagar Maveric"],
                ["Neto IATA", "Neto IATA según Maverick", "A pagar IATA"],
                ["Diferencia", "Diferencia Maverick-IATA"],
            ],
            "duplicados": [
                ["Monto tarjeta", "Monto Tarjeta", "Monto tarjeta Maverick"],
                ["Costo de Res.", "Costo reserva", "Costo reserva Maverick"],
                ["Total a pagar Maverick", "Total a pagar Maveric"],
                ["Neto IATA", "Neto IATA según Maverick", "A pagar IATA"],
                ["Diferencia", "Diferencia Maverick-IATA"],
            ],
            "falta": [["Neto a pagar", "Neto IATA", "A pagar IATA"]],
            "rfnd": [["Importe Cash", "RFND Cash"], ["Importe CC", "RFND CC"]],
            "adm": [["Importe ADM", "Total ADM", "ADM"]],
            "adms": [["Importe ADM", "Total ADM", "ADM"]],
            "acm": [["Importe ACM", "Total ACM", "ACM"]],
            "acma": [["Importe ACM", "Total ACM", "ACM"]],
        }
        for name in list(out.keys()):
            if not isinstance(out[name], pd.DataFrame):
                continue
            lname = str(name).lower()
            selected = None
            # avoid resumen/pivot sheets
            if "resumen" in lname:
                continue
            for key, cols in rules.items():
                if key in lname:
                    selected = cols
                    break
            if selected:
                # do not add twice
                df = out[name]
                if not df.empty and str(df.iloc[-1,0]).upper() == "TOTAL":
                    continue
                out[name] = _tuki_add_total_row(df, selected)
        return out
    except Exception:
        return out



# --- Parche v3.4.0: RFND no se deduplica por documento ---

# --- Parche v3.4.1: RFND usando la línea DET exacta ---
def _tuki_split_det_lines_v341(text):
    """
    Divide un bloque que puede traer:
    DET...TKTT...
    DET...RFND...
    en líneas DET individuales. Importante para no tomar TKTT como RFND.
    """
    s = str(text or "")
    parts = re.split(r"(?=DET\d{3})", s)
    return [p.strip() for p in parts if p.strip().startswith("DET")]

def _tuki_doc_rfnd_from_line_v340(line):
    m = re.search(r"RFND(\d{10})", str(line or ""))
    return m.group(1) if m else ""

def _tuki_find_sheet_v340(sheets, names):
    for n in names:
        for k in sheets.keys():
            if str(k).strip().lower() == n.strip().lower():
                return k
    return None

def _tuki_force_all_rfnd_from_txt_v340(sheets):
    """
    Un mismo documento puede aparecer como TKTT y RFND.
    Para RFND SIEMPRE tomar la sublínea DET que contiene RFND,
    nunca el bloque completo ni la línea TKTT.
    """
    try:
        if not isinstance(sheets, dict):
            return sheets
        txt_key = _tuki_find_sheet_v340(sheets, ["TXT_Leido","TXT Leido","TXT leído","IATA LEÍDO","IATA_LEIDO"])
        if txt_key is None:
            return sheets
        txt_df = sheets.get(txt_key)
        if txt_df is None or not isinstance(txt_df, pd.DataFrame) or txt_df.empty:
            return sheets

        rfnd_key = _tuki_find_sheet_v340(sheets, ["RFND"])
        if rfnd_key is None:
            rfnd_key = "RFND"
            sheets[rfnd_key] = pd.DataFrame()
        rfnd_df = sheets.get(rfnd_key)
        if rfnd_df is None or not isinstance(rfnd_df, pd.DataFrame):
            rfnd_df = pd.DataFrame()

        existing = set()
        if not rfnd_df.empty:
            for _, rr in rfnd_df.iterrows():
                doc = ""
                for c in ["Documento IATA", "Número de billete", "Documento"]:
                    if c in rfnd_df.columns and str(rr.get(c, "")).strip():
                        doc = re.sub(r"\D", "", str(rr.get(c, "")))
                        break
                line = ""
                for c in ["DET TXT", "Linea TXT", "Línea TXT"]:
                    if c in rfnd_df.columns and str(rr.get(c, "")).strip():
                        line = str(rr.get(c, ""))
                        break
                for det_line in _tuki_split_det_lines_v341(line):
                    if "RFND" in det_line:
                        existing.add(("RFND", doc, det_line[:160]))

        add = []
        for _, r in txt_df.iterrows():
            raw = ""
            for c in ["DET TXT", "Linea TXT", "Línea TXT", "Raw TXT", "Linea"]:
                if c in txt_df.columns and str(r.get(c, "")).strip():
                    raw = str(r.get(c, ""))
                    break

            # Puede venir bloque multi-DET; tomar solo DET...RFND.
            det_lines = _tuki_split_det_lines_v341(raw)
            if not det_lines and "RFND" in raw:
                det_lines = [raw]

            for det_line in det_lines:
                if "RFND" not in det_line:
                    continue
                doc = _tuki_doc_rfnd_from_line_v340(det_line)
                if not doc:
                    continue
                key = ("RFND", doc, det_line[:160])
                if key in existing:
                    continue

                cash, cc, com, campo_cash, campo_cc, campo_com, metodo = parse_rfnd_importes(det_line, doc)
                add.append({
                    "Fecha IATA": r.get("Fecha IATA", r.get("Fecha", "")),
                    "Documento IATA": doc,
                    "Tipo": "RFND",
                    "Aerolínea": r.get("Aerolínea TXT", r.get("Aerolínea", "")),
                    "Número de billete": doc,
                    "Estado Maverick": "RFND Fuera de Maveric",
                    "Importe Cash": cash,
                    "Importe CC": cc,
                    "Comisión descontada": com,
                    "Campo Cash": campo_cash,
                    "Campo CC": campo_cc,
                    "Campo Comisión": campo_com,
                    "Metodo RFND": metodo,
                    "Linea TXT": r.get("Linea TXT", r.get("Línea TXT", "")),
                    "DET TXT": det_line,
                })
                existing.add(key)

        if add:
            add_df = pd.DataFrame(add)
            if not rfnd_df.empty:
                for c in add_df.columns:
                    if c not in rfnd_df.columns:
                        rfnd_df[c] = ""
                for c in rfnd_df.columns:
                    if c not in add_df.columns:
                        add_df[c] = ""
                add_df = add_df[rfnd_df.columns]
                sheets[rfnd_key] = pd.concat([rfnd_df, add_df], ignore_index=True)
            else:
                sheets[rfnd_key] = add_df
        return sheets
    except Exception:
        return sheets


def tuki_prepare_output_sheets(sheets):
    try:
        sheets = _tuki_force_all_rfnd_from_txt_v340(sheets)
    except Exception:
        pass

    out = {}
    # Pasar hojas opcionales ya armadas antes de la capa contable.
    if "Resumen IATA" in sheets:
        out["Resumen IATA"] = sheets["Resumen IATA"].copy()

    if "Resumen" in sheets:
        out["Resumen"] = sheets["Resumen"].copy()

    mav_desired = ["Fecha","Boleto","Sistema","Ciudad de Emision","Agente Emisor","Pasajero","Reserva","Forma de Pago",
                   "Monto Tarjeta"," Costo de Res.","Total a pagar Maverick","Neto IATA",
                   "Diferencia Maverick-IATA","Estado","Estado RFND Maverick","Aerolínea","Duplicado Maverick","Cuenta Neto IATA",
                   "Tipo TXT","Línea TXT","Método","Campo control/neto","DET TXT"]

    for src, dst in [
        ("Espejo maverick conciliado","Espejo Maverick"),
        ("Con_Diferencia","Diferencias"),
        ("No encontrada en periodo IATA","No encontrada en periodo IATA"),
        ("Fuera de Periodo IATA","Fuera de Periodo IATA"),
        ("Duplicados_Maverick","Duplicados Maverick"),
    ]:
        if src in sheets:
            out[dst] = tuki_order_cols(tuki_add_airline_mav(sheets[src].copy()), mav_desired)

    # Estado Maverick, para ADM/RFND/ACM
    esp_tmp = out.get("Espejo Maverick", pd.DataFrame())
    estado_map = {}
    if not esp_tmp.empty and "Boleto" in esp_tmp.columns and "Estado" in esp_tmp.columns:
        for _, row in esp_tmp.iterrows():
            d = tuki_doc_digits(row.get("Boleto"))
            if d:
                estado_map[d] = row.get("Estado")

    def add_estado_mav(df):
        df = df.copy()
        vals = []
        tipo_series = None
        if "Tipo" in df.columns:
            tipo_series = df["Tipo"].astype(str).str.upper()
        elif "Tipo TXT" in df.columns:
            tipo_series = df["Tipo TXT"].astype(str).str.upper()
        is_rfnd_df = bool(tipo_series.eq("RFND").any()) if tipo_series is not None else False
        is_adm_df = bool(tipo_series.isin(["ADMA","SPDR"]).any()) if tipo_series is not None else False
        for i, row in df.iterrows():
            d = tuki_doc_digits(row.get("Documento IATA") if "Documento IATA" in df.columns else row.iloc[0])
            raw_estado = estado_map.get(d, "NO EN MAVERICK")
            tipo_row = str(tipo_series.loc[i]) if tipo_series is not None and i in tipo_series.index else ""
            if tipo_row == "RFND" or is_rfnd_df:
                vals.append("RFND en Maveric" if raw_estado != "NO EN MAVERICK" else "RFND Fuera de Maveric")
            elif tipo_row in {"ADMA","SPDR"} or is_adm_df:
                vals.append(raw_estado if raw_estado != "NO EN MAVERICK" else "ADM FUERA DE MAVERIC")
            else:
                vals.append(raw_estado)
        insert_at = list(df.columns).index("Aerolínea") + 1 if "Aerolínea" in df.columns else min(5, len(df.columns))
        if "Estado Maverick" in df.columns:
            df["Estado Maverick"] = vals
        else:
            df.insert(insert_at, "Estado Maverick", vals)
        return df

    # Falta en Maverick
    if "Faltan_en_Maverick" in sheets:
        df = tuki_add_airline_iata(sheets["Faltan_en_Maverick"].copy())
        df = tuki_rename_first(df, ["Neto posicional auditoría","Neto a Pagar","Neto a pagar"], "Neto a pagar")
        df.insert(3, "Emitido en:", [tuki_emitido_en(row) for _, row in df.iterrows()])
        df = tuki_drop_cols(df, ["Importe ACM","Campo ACM","Importe Cash RFND","Importe CC RFND",
                                 "Comisión descontada RFND","Campo Cash RFND","Campo CC RFND","Campo Comisión RFND","Metodo RFND"])
        df = tuki_move_to_end(df, ["Linea TXT","DET TXT","Candidatos DET","Metodo neto posicional","Campo control/neto"])
        out["Falta en Maverick"] = tuki_order_cols(df, ["Fecha IATA","Documento IATA","Tipo","Emitido en:","Código compañía","Aerolínea","Neto a pagar"])

    # RFND
    if "RFND" in sheets:
        df = tuki_add_airline_iata(sheets["RFND"].copy())
        if "Número de billete" not in df.columns:
            insert_at = list(df.columns).index("Aerolínea") + 1 if "Aerolínea" in df.columns else min(5, len(df.columns))
            df.insert(insert_at, "Número de billete", [tuki_rfnd_boleto_from_line(row) for _, row in df.iterrows()])
        df = add_estado_mav(df)
        df = tuki_move_to_end(df, ["Linea TXT","DET TXT"])
        out["RFND"] = tuki_order_cols(df, ["Fecha IATA","Documento IATA","Tipo","Código compañía","Aerolínea","Número de billete","Billete relacionado","Estado Maverick",
                                           "Importe Cash","Importe CC","Comisión descontada","Campo Cash","Campo CC","Campo Comisión","Metodo RFND"])

    # ADM
    if "ADMA" in sheets or "SPDR" in sheets:
        df = tuki_add_airline_iata(pd.concat([sheets[x].copy() for x in ["ADMA","SPDR"] if x in sheets], ignore_index=True))
        df = add_estado_mav(df)
        df = tuki_rename_first(df, ["Importe ADM","Neto posicional auditoría"], "Importe ADM")
        df = tuki_drop_cols(df, ["Importe ACM","Campo ACM","Importe Cash RFND","Importe CC RFND",
                                 "Comisión descontada RFND","Campo Cash RFND","Campo CC RFND","Campo Comisión RFND","Metodo RFND"])
        df = tuki_move_to_end(df, ["Linea TXT","DET TXT","Candidatos DET","Metodo neto posicional","Campo control/neto"])
        out["ADM"] = tuki_order_cols(df, ["Fecha IATA","Documento IATA","Tipo","Código compañía","Aerolínea","Estado Maverick","Importe ADM"])

    # ACM
    if "ACMA" in sheets:
        df = tuki_add_airline_iata(sheets["ACMA"].copy())
        df = add_estado_mav(df)
        df = tuki_rename_first(df, ["Importe ACM","Neto posicional auditoría"], "Importe ACM")
        df = tuki_move_to_end(df, ["Linea TXT","DET TXT","Campo usado"])
        out["ACM"] = tuki_order_cols(df, ["Fecha IATA","Documento IATA","Tipo","Código compañía","Aerolínea","Estado Maverick","Importe ACM"])

    # TKTT
    if "TKTT" in sheets:
        esp_ok_tktt = out.get("Espejo Maverick", pd.DataFrame())
        if not esp_ok_tktt.empty and "Tipo TXT" in esp_ok_tktt.columns and "Estado" in esp_ok_tktt.columns:
            ok_docs = set(esp_ok_tktt[
                esp_ok_tktt["Tipo TXT"].fillna("").astype(str).str.upper().eq("TKTT")
                & esp_ok_tktt["Estado"].fillna("").astype(str).str.upper().eq("OK")
            ]["Boleto"].astype(str).str.extract(r"(\d{10})")[0].dropna())
            df = sheets["TKTT"].copy()
            if "Documento IATA" in df.columns and ok_docs:
                df = df[df["Documento IATA"].astype(str).isin(ok_docs)].copy()
            df = tuki_add_airline_iata(df)
        else:
            df = tuki_add_airline_iata(sheets["TKTT"].copy())
        df = tuki_rename_first(df, ["Neto a Pagar","Neto a pagar","Neto posicional auditoría"], "Neto IATA")
        fp_map, mt_map = {}, {}
        esp = out.get("Espejo Maverick", pd.DataFrame())
        if not esp.empty and "Boleto" in esp.columns:
            for _, row in esp.iterrows():
                d = tuki_doc_digits(row.get("Boleto"))
                if d:
                    fp_map[d] = row.get("Forma de Pago")
                    mt_map[d] = row.get("Monto Tarjeta")
        docs = df["Documento IATA"].astype(str) if "Documento IATA" in df.columns else pd.Series([""]*len(df))
        df["Forma de Pago"] = docs.map(fp_map)
        df["Monto Tarjeta"] = docs.map(mt_map)
        df = tuki_drop_cols(df, ["Importe ACM","Campo ACM","Importe Cash RFND","Importe CC RFND",
                                 "Comisión descontada RFND","Campo Cash RFND","Campo CC RFND","Campo Comisión RFND","Metodo RFND"])
        df = tuki_move_to_end(df, ["Linea TXT","DET TXT","Candidatos DET","Metodo neto posicional","Campo control/neto"])
        out["TKTT"] = tuki_order_cols(df, ["Fecha IATA","Documento IATA","Tipo","Código compañía","Aerolínea","Forma de Pago","Monto Tarjeta","Neto IATA"])

    # EMDS + EMDA
    emds = []
    for nm in ["EMDS","EMDA"]:
        if nm in sheets:
            x = sheets[nm].copy()
            if "Tipo" in x.columns:
                x["Tipo"] = nm
            else:
                x.insert(1, "Tipo", nm)
            emds.append(x)
    if emds:
        df = tuki_add_airline_iata(pd.concat(emds, ignore_index=True))
        df = tuki_rename_first(df, ["Importe EMD","Neto posicional auditoría","Neto a Pagar"], "Importe EMD")
        df = tuki_drop_cols(df, ["Linea TXT","Importe ACM","Campo ACM","Importe Cash RFND","Importe CC RFND",
                                 "Comisión descontada RFND","Campo Cash RFND","Campo CC RFND","Campo Comisión RFND","Metodo RFND"])
        df = tuki_move_to_end(df, ["DET TXT","Candidatos DET","Metodo neto posicional","Campo control/neto"])
        out["EMDS"] = tuki_order_cols(df, ["Fecha IATA","Documento IATA","Tipo","Código compañía","Aerolínea","Importe EMD"])

    # CANX + CANN
    canx = []
    for nm in ["CANX","CANN"]:
        if nm in sheets:
            x = sheets[nm].copy()
            if "Tipo" in x.columns:
                x["Tipo"] = nm
            else:
                x.insert(1, "Tipo", nm)
            canx.append(x)
    if canx:
        df = tuki_add_airline_iata(pd.concat(canx, ignore_index=True))
        df = tuki_drop_cols(df, ["Linea TXT","Importe ACM","Campo ACM","Importe Cash RFND","Importe CC RFND",
                                 "Comisión descontada RFND","Campo Cash RFND","Campo CC RFND","Campo Comisión RFND","Metodo RFND","Neto posicional auditoría"])
        df = tuki_move_to_end(df, ["DET TXT","Candidatos DET","Metodo neto posicional","Campo control/neto"])
        out["CANX"] = tuki_order_cols(df, ["Fecha IATA","Documento IATA","Tipo","Código compañía","Aerolínea"])

    # v3.5.30: fix temprano antes de Resumen Contable/Diferencias.
    # Si un boleto Maverick con sigla aérea (QR/HR/etc.) ya tiene DET TXT de IATA
    # pero Neto IATA quedó 0 por control cero, usar tail post-I solo si coincide exacto
    # con Total a pagar Maverick. Esto corrige QR-4885904565 sin tocar tickets CC
    # que correctamente tienen Neto IATA 0.
    try:
        if "Espejo Maverick" in out:
            _em_fix_pre = out["Espejo Maverick"].copy()
            if not _em_fix_pre.empty and "Boleto" in _em_fix_pre.columns and "DET TXT" in _em_fix_pre.columns:
                for _idx_pre, _row_pre in _em_fix_pre.iterrows():
                    _boleto_pre = _row_pre.get("Boleto")
                    _code_pre, _num_pre = _tuki_v3524_split_maverick_airline_ticket(_boleto_pre)
                    if not _code_pre:
                        continue
                    try:
                        _total_mav_pre = float(_row_pre.get("Total a pagar Maverick") or 0)
                    except Exception:
                        _total_mav_pre = 0
                    try:
                        _neto_actual_pre = float(_row_pre.get("Neto IATA") or 0)
                    except Exception:
                        _neto_actual_pre = 0
                    if abs(_total_mav_pre) <= 0.01 or abs(_neto_actual_pre) > 0.01:
                        continue
                    _tail_val_pre, _tail_field_pre, _tail_method_pre = _tuki_v3528_tail_post_i_amount_if_matches(_row_pre.get("DET TXT"), _total_mav_pre)
                    if _tail_val_pre is None:
                        continue
                    if "Neto IATA" in _em_fix_pre.columns:
                        _em_fix_pre.at[_idx_pre, "Neto IATA"] = _tail_val_pre
                    if "Diferencia Maverick-IATA" in _em_fix_pre.columns:
                        _em_fix_pre.at[_idx_pre, "Diferencia Maverick-IATA"] = round(_total_mav_pre - _tail_val_pre, 2)
                    if "Estado" in _em_fix_pre.columns:
                        _em_fix_pre.at[_idx_pre, "Estado"] = "OK" if abs(_total_mav_pre - _tail_val_pre) <= 0.01 else "CON DIFERENCIA"
                    if "Campo control/neto" in _em_fix_pre.columns:
                        _em_fix_pre.at[_idx_pre, "Campo control/neto"] = _tail_field_pre
                    if "Método" in _em_fix_pre.columns:
                        _em_fix_pre.at[_idx_pre, "Método"] = _tail_method_pre
            out["Espejo Maverick"] = _em_fix_pre
    except Exception:
        pass

    # Resumen contable
    esp = out.get("Espejo Maverick", pd.DataFrame())
    rfnd = out.get("RFND", pd.DataFrame())
    acm = out.get("ACM", pd.DataFrame())
    adm = out.get("ADM", pd.DataFrame())

    if not esp.empty and "Estado" in esp.columns:
        estados = esp["Estado"].fillna("").astype(str).str.upper()
        base_mask = estados.isin(["OK","CON DIFERENCIA","ADM OK","ADM CON DIFERENCIA"])
        ok_mask = estados.str.contains("OK", na=False)
        esp_base = esp[base_mask].copy()
        esp_ok = esp[ok_mask].copy()
    else:
        esp_base = esp.copy()
        esp_ok = esp.copy()

    monto_tarjeta_mav = tuki_numeric_sum(esp_base, "Monto Tarjeta")
    costo_res_mav = tuki_numeric_sum(esp_base, " Costo de Res.")
    neto_iata_mav = tuki_numeric_sum(esp_base, "Neto IATA")
    tkts_adms_pagar_iata = tuki_numeric_sum(esp_ok, "Neto IATA")
    total_rfnd_cash = tuki_numeric_sum(rfnd, "Importe Cash")
    total_rfnd_cc = tuki_numeric_sum(rfnd, "Importe CC")
    total_adm = tuki_numeric_sum(adm, "Importe ADM")
    total_spdr = 0.0
    if not adm.empty and "Importe ADM" in adm.columns:
        if "Tipo" in adm.columns:
            total_spdr = pd.to_numeric(adm.loc[adm["Tipo"].astype(str).str.upper().eq("SPDR"), "Importe ADM"], errors="coerce").fillna(0).sum()
        elif "Tipo TXT" in adm.columns:
            total_spdr = pd.to_numeric(adm.loc[adm["Tipo TXT"].astype(str).str.upper().eq("SPDR"), "Importe ADM"], errors="coerce").fillna(0).sum()
    total_acm = tuki_numeric_sum(acm, "Importe ACM")
    total_a_pagar_iata = tkts_adms_pagar_iata + total_rfnd_cash + total_acm

    total_informado_pdf = sheets.get("_TOTAL_INFORMADO_IATA_PDF", "")
    # Normalización final de nombres de aerolínea por código 083/952 en todas las hojas.
    try:
        for _k in list(out.keys()):
            if isinstance(out[_k], pd.DataFrame):
                out[_k] = _tuki_apply_airline_code_fixes(out[_k])
    except Exception:
        pass

    try:
        for _k in list(out.keys()):
            if isinstance(out[_k], pd.DataFrame):
                out[_k] = _tuki_apply_company_names_final(out[_k])
    except Exception:
        pass

    # Espejo Maverick: para TKTT usar el Neto IATA ya calculado en TXT/TKTT.
    try:
        out = _tuki_fix_espejo_tktt_from_txt_leido(out)
    except Exception:
        pass

    # v3.5.31: fix final después de _tuki_fix_espejo_tktt_from_txt_leido.
    # Esa función puede volver a pisar Neto IATA con 0 desde TXT Leído.
    # Reaplicamos el match quirúrgico antes de reconstruir la hoja Diferencias.
    try:
        if "Espejo Maverick" in out:
            _em_fix_post = out["Espejo Maverick"].copy()
            if not _em_fix_post.empty and "Boleto" in _em_fix_post.columns and "DET TXT" in _em_fix_post.columns:
                for _idx_post, _row_post in _em_fix_post.iterrows():
                    _boleto_post = _row_post.get("Boleto")
                    _code_post, _num_post = _tuki_v3524_split_maverick_airline_ticket(_boleto_post)
                    if not _code_post:
                        continue
                    try:
                        _total_mav_post = float(_row_post.get("Total a pagar Maverick") or 0)
                    except Exception:
                        _total_mav_post = 0
                    try:
                        _neto_actual_post = float(_row_post.get("Neto IATA") or 0)
                    except Exception:
                        _neto_actual_post = 0
                    if abs(_total_mav_post) <= 0.01 or abs(_neto_actual_post) > 0.01:
                        continue
                    _tail_val_post, _tail_field_post, _tail_method_post = _tuki_v3528_tail_post_i_amount_if_matches(_row_post.get("DET TXT"), _total_mav_post)
                    if _tail_val_post is None:
                        continue
                    if "Neto IATA" in _em_fix_post.columns:
                        _em_fix_post.at[_idx_post, "Neto IATA"] = _tail_val_post
                    if "Diferencia Maverick-IATA" in _em_fix_post.columns:
                        _em_fix_post.at[_idx_post, "Diferencia Maverick-IATA"] = round(_total_mav_post - _tail_val_post, 2)
                    if "Estado" in _em_fix_post.columns:
                        _em_fix_post.at[_idx_post, "Estado"] = "OK" if abs(_total_mav_post - _tail_val_post) <= 0.01 else "CON DIFERENCIA"
                    if "Campo control/neto" in _em_fix_post.columns:
                        _em_fix_post.at[_idx_post, "Campo control/neto"] = _tail_field_post
                    if "Método" in _em_fix_post.columns:
                        _em_fix_post.at[_idx_post, "Método"] = _tail_method_post
            out["Espejo Maverick"] = _em_fix_post
    except Exception:
        pass


    # Reconstruir hoja de DIFERENCIAS después de corregir Espejo Maverick.
    try:
        if "Espejo Maverick" in out and isinstance(out["Espejo Maverick"], pd.DataFrame):
            _em = out["Espejo Maverick"].copy()
            if "Diferencia Maverick-IATA" in _em.columns:
                _diff_num = pd.to_numeric(_em["Diferencia Maverick-IATA"], errors="coerce").fillna(0).abs()
                _estado = _em["Estado"].astype(str).str.upper() if "Estado" in _em.columns else pd.Series([""] * len(_em))
                _mask = (_diff_num > 0.50) | _estado.str.contains("DIFERENCIA", na=False)
                out["Diferencias"] = _em.loc[_mask].copy()
    except Exception:
        pass

    # Actualizar conteo de Diferencias en Resumen, luego de reconstruir la hoja Diferencias.
    try:
        out = _tuki_fix_resumen_diferencias_count(out)
    except Exception:
        pass

    # Agregar filas de totales al final de hojas de datos.
    try:
        out = _tuki_apply_total_rows_to_sheets(out)
    except Exception:
        pass

    # Resumen IATA: agregar validación cruzada contra lo calculado por el conciliador.
    try:
        out = _tuki_append_resumen_iata_conciliador_check(
            out,
            total_rfnd_cash=total_rfnd_cash,
            total_rfnd_cc=total_rfnd_cc,
            total_adm=total_adm,
            total_acm=total_acm,
            total_a_pagar_iata=total_a_pagar_iata,
        )
    except Exception:
        pass

    resumen_contable = pd.DataFrame([
        ["Monto tarjeta Maverick (OK/ADM OK/Con diferencia)", monto_tarjeta_mav],
        ["Costo reserva Maverick (OK/ADM OK/Con diferencia)", costo_res_mav],
        ["Neto IATA según Maverick (OK/ADM OK/Con diferencia)", neto_iata_mav],
        ["Tkts y ADMS a Pagar Iata", tkts_adms_pagar_iata],
        ["Total refunds Cash", total_rfnd_cash],
        ["Total refunds CC", total_rfnd_cc],
        ["Total ADM", total_adm],
        ["Total SPDR informativo - ya incluido en Tkts y ADMS", total_spdr],
        ["Total ACM", total_acm],
        ["", ""],
        ["TOTAL A PAGAR EN IATA calculado por el conciliador", total_a_pagar_iata],
        ["TOTAL informado por IATA", total_informado_pdf],
        ["Diferencia de la Semana", ""],
        ["", ""],
        ["* Nota: TOTAL A PAGAR EN IATA calculado = Tkts y ADMS a Pagar Iata + refunds Cash + ACM. SPDR queda informativo porque ya está incluido en Tkts y ADMS.", ""],
    ], columns=["Concepto","Importe"])

    if not esp.empty and "Aerolínea" in esp.columns:
        pivot = esp.groupby("Aerolínea", dropna=False).agg(
            **{
                "Monto tarjeta": ("Monto Tarjeta","sum"),
                "Costo reserva": (" Costo de Res.","sum"),
                "Neto IATA": ("Neto IATA","sum"),
                "Diferencia": ("Diferencia Maverick-IATA","sum"),
                "Cantidad billetes": ("Boleto","count")
            }
        ).reset_index()
        pivot = pivot.sort_values("Monto tarjeta", ascending=False).reset_index(drop=True)
        pivot = pd.concat([pivot, pd.DataFrame([{
            "Aerolínea":"TOTAL",
            "Monto tarjeta": pivot["Monto tarjeta"].sum(),
            "Costo reserva": pivot["Costo reserva"].sum(),
            "Neto IATA": pivot["Neto IATA"].sum(),
            "Diferencia": pivot["Diferencia"].sum(),
            "Cantidad billetes": pivot["Cantidad billetes"].sum()
        }])], ignore_index=True)
    else:
        pivot = pd.DataFrame()

    # v3.5.24: reparar cruces NO ENCONTRADO IATA con boletos Maverick tipo QR-4885904565.
    try:
        if "Espejo Maverick" in out and "TXT Leído" in out:
            em = out["Espejo Maverick"].copy()
            txtdf = out["TXT Leído"].copy()
            if not em.empty and not txtdf.empty and "Boleto" in em.columns:
                doc_cols = [c for c in txtdf.columns if str(c).strip().lower() in ["documento iata", "documento", "boleto"]]
                tipo_cols = [c for c in txtdf.columns if str(c).strip().lower() in ["tipo", "tipo txt"]]
                code_cols = [c for c in txtdf.columns if "cod" in str(c).lower() or "código" in str(c).lower() or "codigo" in str(c).lower()]
                aer_cols = [c for c in txtdf.columns if "aerol" in str(c).lower() or "compañ" in str(c).lower() or "compania" in str(c).lower()]
                neto_cols = [c for c in txtdf.columns if str(c).strip().lower() in ["neto iata", "neto a pagar", "importe"]]
                det_cols = [c for c in txtdf.columns if "det" in str(c).lower()]
                doc_col = doc_cols[0] if doc_cols else None
                tipo_col = tipo_cols[0] if tipo_cols else None
                code_col = code_cols[0] if code_cols else None
                aer_col = aer_cols[0] if aer_cols else None
                neto_col = neto_cols[0] if neto_cols else None
                det_col = det_cols[0] if det_cols else None
                if doc_col:
                    for idx, row in em.iterrows():
                        estado_txt = str(row.get("Estado", "")).upper()
                        # v3.5.25:
                        # No solo reparar NO ENCONTRADO IATA. También reparar CON DIFERENCIA
                        # cuando el boleto Maverick trae sigla aérea y el documento IATA existe.
                        # Caso real: QR-4885904565 quedó CON DIFERENCIA / no_encontre_positivo_exacto,
                        # aunque cruza con DET157 TKTT48859045651.
                        if (
                            "NO ENCONTRADO IATA" not in estado_txt
                            and "NO ENCONTRADO EN IATA" not in estado_txt
                            and "CON DIFERENCIA" not in estado_txt
                        ):
                            continue
                        boleto_mav = row.get("Boleto")
                        mav_code, mav_num = _tuki_v3524_split_maverick_airline_ticket(boleto_mav)
                        if not mav_code or not mav_num:
                            continue
                        candidates = txtdf.copy()
                        if tipo_col:
                            candidates = candidates[candidates[tipo_col].astype(str).str.upper().str.contains("TKTT", na=False)]
                        if code_col:
                            def _code_ok_v3524(x):
                                try:
                                    return str(int(float(x))).zfill(3) == mav_code
                                except Exception:
                                    return str(x).strip().zfill(3) == mav_code
                            candidates = candidates[candidates[code_col].apply(_code_ok_v3524)]
                        elif det_col:
                            candidates = candidates[candidates[det_col].astype(str).str.upper().str.contains("DET"+mav_code, na=False)]
                        match_row = None
                        for _, tr in candidates.iterrows():
                            if _tuki_v3524_ticket_match(boleto_mav, tr.get(doc_col), mav_code):
                                match_row = tr
                                break
                        if match_row is None:
                            continue
                        _neto_match_v3525 = None
                        if neto_col:
                            try:
                                _neto_match_v3525 = float(match_row.get(neto_col) or 0)
                            except Exception:
                                _neto_match_v3525 = None

                        # v3.5.28:
                        # Si TXT Leído dejó Neto IATA en 0 por control cero, pero Maverick tiene Total a pagar,
                        # usar el tail post-I únicamente si coincide exactamente con ese Total Maverick.
                        # Caso QR-4885904565: Total Maverick 2463.10 y tail 00000000000000000246310.
                        if (_neto_match_v3525 is None or abs(float(_neto_match_v3525 or 0)) <= 0.01) and "Total a pagar Maverick" in em.columns:
                            try:
                                _target_v3528 = float(em.at[idx, "Total a pagar Maverick"] or 0)
                            except Exception:
                                _target_v3528 = 0
                            if abs(_target_v3528) > 0.01:
                                _det_for_tail_v3528 = None
                                if det_col:
                                    _det_for_tail_v3528 = match_row.get(det_col)
                                if not _det_for_tail_v3528 and "DET TXT" in em.columns:
                                    _det_for_tail_v3528 = em.at[idx, "DET TXT"]
                                _tail_val_v3528, _tail_field_v3528, _tail_method_v3528 = _tuki_v3528_tail_post_i_amount_if_matches(_det_for_tail_v3528, _target_v3528)
                                if _tail_val_v3528 is not None:
                                    _neto_match_v3525 = _tail_val_v3528
                                    if "Campo control/neto" in em.columns:
                                        em.at[idx, "Campo control/neto"] = _tail_field_v3528
                                    if "Método" in em.columns:
                                        em.at[idx, "Método"] = _tail_method_v3528

                        if "Neto IATA" in em.columns and _neto_match_v3525 is not None:
                            try:
                                em.at[idx, "Neto IATA"] = _neto_match_v3525
                            except Exception:
                                pass

                        # Si al aplicar el match el total Maverick coincide con Neto IATA, pasa a OK.
                        # Si no coincide, queda CON DIFERENCIA pero ya con Documento/DET correctos.
                        _diff_v3525 = None
                        if "Total a pagar Maverick" in em.columns and _neto_match_v3525 is not None:
                            try:
                                _diff_v3525 = round(float(em.at[idx, "Total a pagar Maverick"] or 0) - float(_neto_match_v3525 or 0), 2)
                            except Exception:
                                _diff_v3525 = None

                        if "Diferencia Maverick-IATA" in em.columns and _diff_v3525 is not None:
                            try:
                                em.at[idx, "Diferencia Maverick-IATA"] = _diff_v3525
                            except Exception:
                                pass

                        if "Estado" in em.columns:
                            if _diff_v3525 is None or abs(_diff_v3525) <= 0.01:
                                em.at[idx, "Estado"] = "OK"
                            else:
                                em.at[idx, "Estado"] = "CON DIFERENCIA"
                        if "Aerolínea" in em.columns:
                            em.at[idx, "Aerolínea"] = "Qatar Airways" if mav_code == "157" else (str(match_row.get(aer_col)) if aer_col else em.at[idx, "Aerolínea"])
                        if "DET TXT" in em.columns and det_col:
                            em.at[idx, "DET TXT"] = match_row.get(det_col)
                        if "Documento IATA" in em.columns:
                            em.at[idx, "Documento IATA"] = match_row.get(doc_col)
                        if "Diferencia Maverick-IATA" in em.columns and "Total a pagar Maverick" in em.columns and "Neto IATA" in em.columns:
                            try:
                                em.at[idx, "Diferencia Maverick-IATA"] = round(float(em.at[idx, "Total a pagar Maverick"] or 0) - float(em.at[idx, "Neto IATA"] or 0), 2)
                            except Exception:
                                pass
                out["Espejo Maverick"] = em
    except Exception:
        pass

    # v3.5.28 FINAL: reparación directa por DET TXT de la propia fila Maverick.
    # Necesaria cuando el cruce ya encontró la línea IATA, pero TXT Leído dejó Neto IATA=0 por control cero.
    # Solo aplica si:
    # - boleto Maverick tiene sigla aérea (QR-..., HR-..., etc.)
    # - Total a pagar Maverick > 0
    # - Neto IATA actual está en 0
    # - el tail post-I coincide EXACTO con el Total Maverick
    # Así no vuelve a romper tickets CC con neto IATA 0.
    try:
        if "Espejo Maverick" in out:
            em2 = out["Espejo Maverick"].copy()
            if not em2.empty and "Boleto" in em2.columns and "DET TXT" in em2.columns:
                for idx2, row2 in em2.iterrows():
                    boleto2 = row2.get("Boleto")
                    code2, num2 = _tuki_v3524_split_maverick_airline_ticket(boleto2)
                    if not code2:
                        continue
                    try:
                        total_mav2 = float(row2.get("Total a pagar Maverick") or 0)
                    except Exception:
                        total_mav2 = 0
                    try:
                        neto_actual2 = float(row2.get("Neto IATA") or 0)
                    except Exception:
                        neto_actual2 = 0
                    if abs(total_mav2) <= 0.01 or abs(neto_actual2) > 0.01:
                        continue
                    det2 = row2.get("DET TXT")
                    tail_val2, tail_field2, tail_method2 = _tuki_v3528_tail_post_i_amount_if_matches(det2, total_mav2)
                    if tail_val2 is None:
                        continue
                    if "Neto IATA" in em2.columns:
                        em2.at[idx2, "Neto IATA"] = tail_val2
                    if "Diferencia Maverick-IATA" in em2.columns:
                        em2.at[idx2, "Diferencia Maverick-IATA"] = round(total_mav2 - tail_val2, 2)
                    if "Estado" in em2.columns:
                        em2.at[idx2, "Estado"] = "OK" if abs(total_mav2 - tail_val2) <= 0.01 else "CON DIFERENCIA"
                    if "Campo control/neto" in em2.columns:
                        em2.at[idx2, "Campo control/neto"] = tail_field2
                    if "Método" in em2.columns:
                        em2.at[idx2, "Método"] = tail_method2
            out["Espejo Maverick"] = em2
    except Exception:
        pass

    return out, resumen_contable, pivot



def normalize_maverick_original(df):
    """
    Maveric original sin títulos, por coordenadas fijas EXACTAS:
      A Fecha -> índice 0
      B Documento/Boleto -> índice 1
      D Ciudad emisión -> índice 3
      E Agente emisor -> índice 4
      F Pasajero -> índice 5
      G Forma de pago -> índice 6
      H Monto tarjeta -> índice 7
      J Reserva -> índice 9
      K Costo reserva -> índice 10
      L Sistema -> índice 11
      M Total a pagar Maverick -> índice 12
    C se ignora.
    """
    raw = df.copy()

    def colpos(idx):
        return raw.iloc[:, idx] if raw.shape[1] > idx else pd.Series([None] * len(raw))

    out = pd.DataFrame({
        "Fecha": colpos(0),
        "Boleto": colpos(1),
        "Ciudad de Emision": colpos(3),
        "Agente Emisor": colpos(4),
        "Pasajero": colpos(5),
        "Forma de Pago": colpos(6),
        "Monto Tarjeta": colpos(7),
        "Reserva": colpos(9),
        " Costo de Res.": colpos(10),
        "Sistema": colpos(11),
        "Total a pagar Maverick": colpos(12),
    })

    out = out.dropna(how="all")
    out = out[out["Boleto"].notna()]
    out["Boleto"] = out["Boleto"].astype(str).str.strip()
    out = out[(out["Boleto"] != "") & (~out["Boleto"].str.lower().isin(["nan", "none"]))]
    out = out[~out["Boleto"].str.upper().isin(["DOCUMENTO", "BOLETO", "DOCUMENTO/BOLETO"])]

    out["Fecha"] = pd.to_datetime(out["Fecha"], errors="coerce")
    for c in ["Monto Tarjeta", " Costo de Res.", "Total a pagar Maverick"]:
        out[c] = pd.to_numeric(out[c], errors="coerce").fillna(0.0)

    out["Forma de Pago"] = out["Forma de Pago"].fillna("").astype(str).str.strip()
    out.loc[(out["Forma de Pago"] == "") & (out["Monto Tarjeta"].fillna(0) == 0), "Forma de Pago"] = "CASH"
    return out


def ensure_maverick_format(df):
    # En esta versión NO se autodetectan encabezados: Maveric original siempre por coordenadas.
    return normalize_maverick_original(df)






# =========================
# Resumen IATA PDF opcional
# =========================




def _iata_pdf_num(x):
    if x is None:
        return 0.0
    s = str(x).strip().replace(",", "")
    if s in {"", "-", "None", "nan"}:
        return 0.0
    try:
        return float(s)
    except Exception:
        return 0.0

def _iata_pdf_text(pdf_file):
    if pdf_file is None:
        return "", "SIN_PDF"
    try:
        raw = pdf_file.getvalue() if hasattr(pdf_file, "getvalue") else pdf_file.read()
    except Exception as e:
        return "", f"NO_PUDE_LEER_BYTES: {e}"

    errors = []
    for modname in ("pypdf", "PyPDF2"):
        try:
            if modname == "pypdf":
                from pypdf import PdfReader
                reader = PdfReader(io.BytesIO(raw))
                # layout mantiene mejor columnas y evita mezclar encabezados con compañías
                text = "\n".join([(page.extract_text(extraction_mode="layout") or "") for page in reader.pages])
            else:
                from PyPDF2 import PdfReader
                reader = PdfReader(io.BytesIO(raw))
                text = "\n".join([(page.extract_text() or "") for page in reader.pages])
            if text.strip():
                return text, f"OK_{modname}"
            errors.append(f"{modname}: texto vacío")
        except Exception as e:
            errors.append(f"{modname}: {e}")
    return "", " | ".join(errors)

def _money_tokens(s):
    return re.findall(r"-?\d[\d,]*\.\d{2}", str(s or ""))

def _doc_count_from_block(block_lines):
    joined = " ".join(block_lines)
    # patrones como "39,134.54 8", "3EFECTIVO", "8CREDITO"
    candidates = []
    for ln in block_lines:
        for m in re.finditer(r"\.\d{2}\s+(\d{1,4})(?=\s|$)", ln):
            candidates.append(int(m.group(1).replace(",", "")))
        for m in re.finditer(r"(?<![\d.,])(\d{1,4})\s*(?:EFECTIVO|CREDITO)\b", ln, re.I):
            candidates.append(int(m.group(1).replace(",", "")))
    return candidates[-1] if candidates else 0

def _agent_total_from_text(text):
    # Fuente oficial del total informado: AGENT ... TOTAL / GRAND TOTAL.
    lines = [ln.strip() for ln in str(text or "").splitlines() if ln.strip()]
    for ln in reversed(lines):
        up = ln.upper()
        if ("AGENT" in up and "TOTAL" in up) or ("GRAND TOTAL" in up) or up.startswith("TOTAL"):
            vals = [_iata_pdf_num(x) for x in _money_tokens(ln)]
            if len(vals) >= 8:
                return float(vals[-1])
    # fallback global: buscar todas las líneas TOTAL con muchos importes y usar la última columna neto
    candidates = []
    for ln in lines:
        up = ln.upper()
        if "TOTAL" in up:
            vals = [_iata_pdf_num(x) for x in _money_tokens(ln)]
            if len(vals) >= 8:
                candidates.append(float(vals[-1]))
    return candidates[-1] if candidates else None

PDF_AIR_NAMES = {
    "001": "American Airlines",
    "006": "Delta Air Lines Inc.",
    "016": "United Airlines Inc",
    "044": "Aerolineas Argentinas S.A.",
    "045": "LATAM Airlines Group SA dba La",
    "057": "Air France",
    "071": "Ethiopian Airlines dba Ethiopi",
    "075": "Iberia Lineas Aereas de Espana",
    "127": "GOL Linhas Aereas S/A dba GOL",
    "134": "Aerovias del Continente Americ",
    "139": "Aerovias de Mexico SA de CV db",
    "169": "Hahn Air Lines",
    "176": "Emirates",
    "220": "Lufthansa",
    "230": "Compania Panamena de Aviacion,",
    "235": "Turkish Airlines Inc",
    "275": "APG Airlines",
    "365": "FlexFlight ApS",
    "445": "Compania De Aviacion Paraguaya",
    "577": "Azul Linhas Aereas Brasileiras",
    "605": "Sky Airline S.A.",
    "692": "Latam PY",
    "799": "SPDR IATA",
    "888": "EasyJet",
    "973": "JETSMART AIRLINES SpA",
    "974": "JetSmart",
    "996": "Air Europa Lineas Aereas, S.A.",
}

def _pdf_air_name(code, sigla, fallback=""):
    code = str(code or "").zfill(3)
    if code in PDF_AIR_NAMES:
        return PDF_AIR_NAMES[code]
    try:
        name = tuki_airline_from_code(code)
        if name and not str(name).startswith("FALTA"):
            return name
    except Exception:
        pass
    return str(fallback or "").strip()

def parse_iata_summary_pdf(pdf_file):
    """
    Parser FCAGBILLSUMNG usando layout text.
    Compañía por código, total informado desde PDF oficial.
    """
    cols = ["Categoria","Codigo","Sigla","Compañia","FOP","Cash","CC","Total",
            "RFND Cash","RFND CC","RFND Total","ADMS","ACM","Tasas y Cargos",
            "Monto Cash","Taxs sin Comi","Neto a pagar","Cantidad de docs"]
    totals_cols = ["Concepto","FOP","Cash","CC","Total","RFND Cash","RFND CC","RFND Total",
                   "ADMS","ACM","Tasas y Cargos","Monto Cash","Taxs sin Comi","Neto a pagar","Cantidad de docs"]

    text, diag = _iata_pdf_text(pdf_file)
    if not text.strip():
        if pdf_file is None:
            return pd.DataFrame(columns=cols), pd.DataFrame(columns=totals_cols), None, "SIN_PDF"
        df_diag = pd.DataFrame([{
            "Categoria":"ERROR","Codigo":"","Sigla":"",
            "Compañia":f"No pude leer texto del PDF. Diagnóstico: {diag}",
            "FOP":"","Cash":0.0,"CC":0.0,"Total":0.0,"RFND Cash":0.0,"RFND CC":0.0,"RFND Total":0.0,
            "ADMS":0.0,"ACM":0.0,"Tasas y Cargos":0.0,"Monto Cash":0.0,"Taxs sin Comi":0.0,"Neto a pagar":0.0,"Cantidad de docs":0
        }])
        return df_diag, pd.DataFrame(columns=totals_cols), None, diag

    lines = [ln.rstrip() for ln in text.splitlines() if ln.strip()]
    code_re = re.compile(r"^\s*(\d{3})\s+([A-Z0-9]{2})\b(.*)$")
    code_indices = []
    for i, ln in enumerate(lines):
        if code_re.match(ln):
            code_indices.append(i)

    rows = []
    total_oficial = _agent_total_from_text(text)

    def current_category(before_idx):
        cat = ""
        for j in range(before_idx, -1, -1):
            s = lines[j].strip()
            if s.startswith("CATEGORY "):
                cat = s.replace("CATEGORY", "").strip()
                break
        return cat

    for pos, i in enumerate(code_indices):
        m = code_re.match(lines[i])
        if not m:
            continue
        code, sigla, rest = m.group(1), m.group(2), m.group(3)
        # ignorar falsos positivos de encabezados
        if str(rest).upper().startswith(("NOMBRE", "FOP", "DEBITO", "CREDITO Y CARGOS")):
            continue

        next_i = code_indices[pos+1] if pos+1 < len(code_indices) else len(lines)
        block = lines[i:next_i]
        # cortar antes de totales / nueva categoría
        clean_block = []
        for ln in block:
            up = ln.strip().upper()
            if up.startswith(("COMBINED TOTALS", "BSP TOTAL", "WEBSALES-EDIS TOTAL", "AGENT ", "GRAND TOTAL", "CATEGORY ")):
                break
            # sacar encabezados/pies de página de la lectura
            if "FCAGBILLSUMNG AGENT BILLING SUMMARY" in up:
                continue
            if "PAGE :" in up and len(_money_tokens(ln)) == 0:
                continue
            clean_block.append(ln)
        block = clean_block
        if not block:
            continue

        cat = current_category(i)
        first_vals = [_iata_pdf_num(x) for x in _money_tokens(block[0])]
        all_lines = " ".join(block).upper()
        cash = cc = rf_cash = rf_cc = 0.0
        total_vals = None
        single_tail = None

        # línea de inicio: generalmente trae cash/rfnd cash
        if first_vals:
            if "CREDITO" in block[0].upper() and "EFECTIVO" not in block[0].upper():
                # caso crédito puro mal alineado; a veces emisión aparece al final
                if len(first_vals) >= 7 and first_vals[-2] > 0:
                    cc = first_vals[-2]
                    rf_cc = first_vals[-1] if len(first_vals) > 1 else 0.0
                    single_tail = first_vals[0:-2]
                else:
                    cc = first_vals[0]
                    rf_cc = first_vals[1] if len(first_vals) > 1 else 0.0
                    single_tail = first_vals[2:] if len(first_vals) > 2 else None
            else:
                cash = first_vals[0]
                rf_cash = first_vals[1] if len(first_vals) > 1 else 0.0
                if "EFECTIVO" in block[0].upper() and len(first_vals) > 2:
                    single_tail = first_vals[2:]

        for ln in block[1:]:
            up = ln.upper().strip()
            vals = [_iata_pdf_num(x) for x in _money_tokens(ln)]
            if up.startswith("CREDITO") or "CREDITO" in up:
                if vals:
                    # normal: CREDITO 154,137.28 -900.00
                    # crédito puro mal alineado: varios campos y emisión al final
                    if len(vals) >= 7 and vals[-2] > 0 and (vals[0] == 0 or vals[0] < vals[-2]):
                        cc = vals[-2]
                        rf_cc = vals[-1] if len(vals) > 1 else 0.0
                        single_tail = vals[0:-2]
                    else:
                        cc = vals[0]
                        rf_cc = vals[1] if len(vals) > 1 else 0.0
                        if len(vals) > 2:
                            single_tail = vals[2:]
                continue
            if up.startswith("EFECTIVO") or "EFECTIVO" in up:
                if vals:
                    # efectivo puro con todo en la misma línea: docs pueden aparecer pegados antes de EFECTIVO
                    if cash == 0 and rf_cash == 0:
                        cash = vals[0]
                        rf_cash = vals[1] if len(vals) > 1 else 0.0
                        if len(vals) > 2:
                            single_tail = vals[2:]
                    elif len(vals) >= 6:
                        single_tail = vals
                continue
            if up.startswith("TOTAL"):
                total_vals = vals
                continue

        if total_vals:
            total = total_vals[0] if len(total_vals) > 0 else cash + cc
            rf_total = total_vals[1] if len(total_vals) > 1 else rf_cash + rf_cc
            adms = total_vals[2] if len(total_vals) > 2 else 0.0
            acm = total_vals[3] if len(total_vals) > 3 else 0.0
            tasas = total_vals[4] if len(total_vals) > 4 else 0.0
            monto_cash = total_vals[5] if len(total_vals) > 5 else 0.0
            tax_sin_comi = total_vals[6] if len(total_vals) > 6 else 0.0
            neto = total_vals[7] if len(total_vals) > 7 else 0.0
            docs = _doc_count_from_block([ln for ln in block if ln.strip().upper().startswith("TOTAL")])
        else:
            tail = single_tail or []
            total = cash + cc
            rf_total = rf_cash + rf_cc
            adms = tail[0] if len(tail) > 0 else 0.0
            acm = tail[1] if len(tail) > 1 else 0.0
            tasas = tail[2] if len(tail) > 2 else 0.0
            monto_cash = tail[3] if len(tail) > 3 else 0.0
            tax_sin_comi = tail[4] if len(tail) > 4 else 0.0
            neto = tail[5] if len(tail) > 5 else cash + rf_cash + adms + acm - monto_cash
            docs = _doc_count_from_block(block)

        rows.append({
            "Categoria": cat,
            "Codigo": str(code).zfill(3),
            "Sigla": sigla,
            "Compañia": _pdf_air_name(code, sigla),
            "FOP": "TOTAL",
            "Cash": round(cash, 2),
            "CC": round(cc, 2),
            "Total": round(total, 2),
            "RFND Cash": round(rf_cash, 2),
            "RFND CC": round(rf_cc, 2),
            "RFND Total": round(rf_total, 2),
            "ADMS": round(adms, 2),
            "ACM": round(acm, 2),
            "Tasas y Cargos": round(tasas, 2),
            "Monto Cash": round(monto_cash, 2),
            "Taxs sin Comi": round(tax_sin_comi, 2),
            "Neto a pagar": round(neto, 2),
            "Cantidad de docs": int(docs or 0)
        })

    df = pd.DataFrame(rows, columns=cols)
    if not df.empty:
        # excluir filas claramente vacías
        df = df[~((pd.to_numeric(df["Total"], errors="coerce").fillna(0).eq(0)) & (pd.to_numeric(df["Neto a pagar"], errors="coerce").fillna(0).eq(0)) & (pd.to_numeric(df["ADMS"], errors="coerce").fillna(0).eq(0)))]
        df = df.sort_values("Total", ascending=False).reset_index(drop=True)
        total_row = {"Categoria": "TOTAL", "Codigo": "", "Sigla": "", "Compañia": "TOTAL", "FOP": ""}
        for c in cols:
            if c in ["Cash","CC","Total","RFND Cash","RFND CC","RFND Total","ADMS","ACM","Tasas y Cargos","Monto Cash","Taxs sin Comi","Neto a pagar","Cantidad de docs"]:
                total_row[c] = pd.to_numeric(df[c], errors="coerce").fillna(0).sum()
        if total_oficial is not None:
            # Este es el dato oficial del PDF; evita que una mala extracción de una línea desvíe el total informado.
            total_row["Neto a pagar"] = float(total_oficial)
        for c in cols:
            total_row.setdefault(c, "")
        df = pd.concat([df, pd.DataFrame([total_row])], ignore_index=True)

    total_informado = total_oficial
    if total_informado is None and not df.empty:
        mask_total = df["Compañia"].astype(str).eq("TOTAL")
        if mask_total.any():
            total_informado = float(pd.to_numeric(df.loc[mask_total, "Neto a pagar"], errors="coerce").fillna(0).iloc[0])

    if pdf_file is not None and df.empty:
        sample = " | ".join(lines[:15])[:1000]
        df = pd.DataFrame([{
            "Categoria":"ERROR","Codigo":"","Sigla":"",
            "Compañia":f"PDF leído ({diag}) pero no parseé compañías. Muestra: {sample}",
            "FOP":"","Cash":0.0,"CC":0.0,"Total":0.0,"RFND Cash":0.0,"RFND CC":0.0,"RFND Total":0.0,
            "ADMS":0.0,"ACM":0.0,"Tasas y Cargos":0.0,"Monto Cash":0.0,"Taxs sin Comi":0.0,"Neto a pagar":0.0,"Cantidad de docs":0
        }])

    return df, pd.DataFrame(columns=totals_cols), total_informado, diag



# --- v3.5.18: resumen contable por compañía + resúmenes por item sin romper formato previo ---
def _tuki_v3518_code_from_row(row):
    """
    v3.5.19 LOCAL: normalizacion conservadora para resumenes.
    Prioriza Aerolinea/Compania/Codigo ya normalizados antes de DET/Boleto.
    Evita FALTA NOMBRE 030/040/050/060/etc y acumulaciones falsas en AA.
    """
    try:
        # 1) Por nombre de aerolinea/compania primero
        for c in ["Aerolínea", "Compania", "Compañia", "Compañía"]:
            if c in row.index and pd.notna(row.get(c)):
                a = str(row.get(c)).strip().upper()
                if not a or a in ["NAN", "NONE", "0"]:
                    continue
                if "TAP" in a or "FALTA NOMBRE TP" in a: return "047"
                if "HANAIR" in a or "HAHN AIR" in a or "FALTA NOMBRE HR" in a: return "169"
                if "SPDR" in a or "FALTA NOMBRE 799" in a: return "799"
                aliases = {
                    "AMERICAN":"001", "DELTA":"006", "AIR CANADA":"014", "UNITED":"016",
                    "AEROLINEAS":"044", "LATAM":"045", "AIR FRANCE":"057", "IBERIA":"075",
                    "GOL":"127", "AVIANCA":"134", "AEROMEXICO":"139", "QATAR":"157",
                    "EMIRATES":"176", "LUFTHANSA":"220", "COPA":"230", "TURKISH":"235",
                    "APG":"275", "EUROAIRLINES":"291", "FLEXFLIGHT":"365", "PARANAIR":"445",
                    "AZUL":"577", "SKY AIRLINE":"605", "JETSMART":"973", "AIR EUROPA":"996",
                    "IATA":"952",
                }
                for k, code in aliases.items():
                    if k in a: return code
                for code, name in PDF_AIR_NAMES.items():
                    n = str(name).upper()
                    if n and (n in a or a in n):
                        return str(code).zfill(3)
        # 2) Codigo/sigla explicita
        for c in ["Código compañía", "Codigo compañía", "Codigo", "Código"]:
            if c in row.index and pd.notna(row.get(c)):
                s = str(row.get(c)).strip().upper()
                try:
                    if re.fullmatch(r"\d+(\.0+)?", s):
                        return str(int(float(s))).zfill(3)
                except Exception:
                    pass
                if s == "TP": return "047"
                if s == "HR": return "169"
                if s == "799": return "799"
        if "Sigla" in row.index and pd.notna(row.get("Sigla")):
            s = str(row.get("Sigla")).strip().upper()
            if s == "TP": return "047"
            if s == "HR": return "169"
        # 3) DET TXT solo si el codigo existe en PDF_AIR_NAMES o especiales
        if "DET TXT" in row.index and pd.notna(row.get("DET TXT")):
            txt = str(row.get("DET TXT")).upper()
            m = re.search(r"^DET(\d{3})", txt)
            if m:
                code = m.group(1)
                if code in PDF_AIR_NAMES or code in ["047", "169", "799"]:
                    return code
        # 4) Boleto real con prefijo de compañía.
        # IMPORTANTE:
        # No usar "Documento IATA" para inferir compañía en ADM/ACM/RFND.
        # Ejemplo real: ADM 6057002889 empieza con 605, pero NO es Sky.
        # Un boleto Sky real viene como 605-5460658957 / 605546...
        if "Boleto" in row.index and pd.notna(row.get("Boleto")):
            b = str(row.get("Boleto")).strip().upper()
            m = re.match(r"^(\d{3})[-\s]?\d{10,}", b)
            if m:
                code = m.group(1)
                if code in PDF_AIR_NAMES or code in ["047", "169", "799"]:
                    return code
            if b.startswith("TP"): return "047"
            if b.startswith("HR"): return "169"

        # Documento IATA solo si tiene formato inequívoco de boleto completo:
        # 000-0000000000 o 13 dígitos. Nunca un ADM/ACM de 10 dígitos.
        if "Documento IATA" in row.index and pd.notna(row.get("Documento IATA")):
            d = str(row.get("Documento IATA")).strip().upper()
            m = re.match(r"^(\d{3})-\d{10}$", d)
            if not m and re.fullmatch(r"\d{13}", d):
                m = re.match(r"^(\d{3})", d)
            if m:
                code = m.group(1)
                if code in PDF_AIR_NAMES or code in ["047", "169", "799"]:
                    return code
    except Exception:
        return None
    return None


# v3.5.21_LOCAL: ADM/ACM/RFND no infieren compañía por Documento IATA de 10 dígitos; evita ADM 6057002889 como Sky.

def _tuki_v3518_company_name(code):
    code = str(code or "").zfill(3)
    if code == "047":
        return "TAP Portugal"
    if code == "169":
        return "Hahn Air Lines"
    if code == "692":
        return "Latam PY"
    if code == "799":
        return "SPDR IATA"
    name = PDF_AIR_NAMES.get(code)
    if name:
        # nombres más amigables ya usados en hojas anteriores
        reps = {
            "LATAM Airlines Group SA dba La": "LATAM Airlines Group",
            "GOL Linhas Aereas S/A dba GOL": "GOL Linhas Aereas",
            "Compania Panamena de Aviacion,": "Copa Airlines",
            "Hahn Air Lines GmbH": "Hahn Air Lines",
            "Air Europa Lineas Aereas, S.A.": "Air Europa",
            "Iberia Lineas Aereas de Espana": "Iberia Lineas Aereas de Espana",
        }
        return reps.get(name, name)
    try:
        return tuki_airline_from_code(code)
    except Exception:
        return code


def _tuki_v3518_clean_totals(df):
    if df is None or not isinstance(df, pd.DataFrame) or df.empty:
        return pd.DataFrame()
    out = df.copy()
    mask = pd.Series(False, index=out.index)
    for c in out.columns:
        vals = out[c].astype(str).str.upper().str.strip()
        mask = mask | vals.eq("TOTAL") | vals.str.startswith("TOTAL ")
    return out[~mask].copy()


def _tuki_v3518_sum(df, col, code=None):
    if df is None or df.empty or col not in df.columns:
        return 0.0
    d = df
    if code is not None and "_codigo_v3518" in d.columns:
        d = d[d["_codigo_v3518"].astype(str).str.zfill(3).eq(str(code).zfill(3))]
    return round(float(pd.to_numeric(d[col], errors="coerce").fillna(0).sum()), 2)


def _tuki_v3518_build_summary_tables(out):
    try:
        ri = out.get("Resumen IATA", pd.DataFrame()).copy()
        em = out.get("Espejo Maverick", pd.DataFrame()).copy()
        rfnd = _tuki_v3518_clean_totals(out.get("RFND", pd.DataFrame())).copy()
        adm = _tuki_v3518_clean_totals(out.get("ADM", pd.DataFrame())).copy()
        acm = _tuki_v3518_clean_totals(out.get("ACM", pd.DataFrame())).copy()

        for df in [ri, em, rfnd, adm, acm]:
            if isinstance(df, pd.DataFrame) and not df.empty:
                df["_codigo_v3518"] = df.apply(_tuki_v3518_code_from_row, axis=1)

        if not ri.empty and "Categoria" in ri.columns:
            ri = ri[ri["Categoria"].astype(str).isin(["BSP", "WEBSALES-EDIS"])].copy()
            ri["Canal_v3518"] = ri["Categoria"].map({"BSP": "GDS", "WEBSALES-EDIS": "WEB"})
            for c in ["Neto a pagar", "RFND Cash", "RFND CC", "RFND Total", "ADMS", "ACM", "Cantidad de docs"]:
                if c in ri.columns:
                    ri[c] = pd.to_numeric(ri[c], errors="coerce").fillna(0)

        if not em.empty:
            if "Estado" in em.columns:
                est = em["Estado"].fillna("").astype(str).str.upper()
                # Resumen contable: excluir FUERA DE PERIODO y NO ENCONTRADO IATA.
                em = em[
                    ~est.str.contains("FUERA DE PERIODO", na=False)
                    & ~est.str.contains("NO ENCONTRADO IATA", na=False)
                    & ~est.str.contains("NO ENCONTRADO EN IATA", na=False)
                    & ~est.str.contains("RFND", na=False)
                ].copy()
                # RFND se controla aparte. No debe integrar "Neto a pagar Maverick".
                if "Tipo TXT" in em.columns:
                    _tipo_rfnd = em["Tipo TXT"].fillna("").astype(str).str.upper()
                    em = em[~_tipo_rfnd.str.contains("RFND", na=False)].copy()
            for c in ["Monto Tarjeta", " Costo de Res.", "Total a pagar Maverick", "Neto IATA", "Diferencia Maverick-IATA"]:
                if c in em.columns:
                    em[c] = pd.to_numeric(em[c], errors="coerce").fillna(0)

        for df, cols in [(rfnd, ["Importe Cash", "Importe CC"]), (adm, ["Importe ADM"]), (acm, ["Importe ACM"])]:
            for c in cols:
                if c in df.columns:
                    df[c] = pd.to_numeric(df[c], errors="coerce").fillna(0)

        codes = set()
        for df in [ri, em, rfnd, adm, acm]:
            if isinstance(df, pd.DataFrame) and not df.empty and "_codigo_v3518" in df.columns:
                codes |= set(df["_codigo_v3518"].dropna().astype(str).str.zfill(3))
        codes = sorted([c for c in codes if c and c.lower() != "nan"])
        codes = [c for c in codes if not str(_tuki_v3518_company_name(c)).upper().startswith("FALTA NOMBRE")]

        rows = []
        for code in codes:
            name = _tuki_v3518_company_name(code)
            mav_net = _tuki_v3518_sum(em, "Total a pagar Maverick", code)
            mav_card = _tuki_v3518_sum(em, "Monto Tarjeta", code)
            rf_cash = _tuki_v3518_sum(rfnd, "Importe Cash", code)
            adms = _tuki_v3518_sum(adm, "Importe ADM", code)
            acms = _tuki_v3518_sum(acm, "Importe ACM", code)
            total_conc = round(mav_net + adms + acms + rf_cash, 2)

            iata_gds = 0.0
            iata_web = 0.0
            cantidad = 0
            if not ri.empty:
                iata_gds = round(float(pd.to_numeric(ri[(ri["_codigo_v3518"].astype(str).str.zfill(3)==code) & (ri["Canal_v3518"].eq("GDS"))]["Neto a pagar"], errors="coerce").fillna(0).sum()), 2) if "Neto a pagar" in ri.columns else 0.0
                iata_web = round(float(pd.to_numeric(ri[(ri["_codigo_v3518"].astype(str).str.zfill(3)==code) & (ri["Canal_v3518"].eq("WEB"))]["Neto a pagar"], errors="coerce").fillna(0).sum()), 2) if "Neto a pagar" in ri.columns else 0.0
                if "Cantidad de docs" in ri.columns:
                    cantidad = int(round(float(pd.to_numeric(ri[ri["_codigo_v3518"].astype(str).str.zfill(3)==code]["Cantidad de docs"], errors="coerce").fillna(0).sum()), 0))
            iata_total = round(iata_gds + iata_web, 2)

            # v3.5.32:
            # Para la conciliación por compañía, si Resumen IATA queda incompleto por una
            # lectura especial validada en Espejo (ej. QR-4885904565 tail post-I),
            # usamos el Neto IATA ya corregido en Espejo siempre que explique exactamente
            # el Total Maverick conciliado de esa compañía.
            try:
                em_ok_neto = 0.0
                if not em.empty and "_codigo_v3518" in em.columns and "Neto IATA" in em.columns:
                    _em_code_all = em[em["_codigo_v3518"].astype(str).str.zfill(3) == code].copy()
                    if "Estado" in _em_code_all.columns:
                        _em_code_ok = _em_code_all[_em_code_all["Estado"].astype(str).str.upper().eq("OK")].copy()
                    else:
                        _em_code_ok = _em_code_all.copy()
                    # excluir RFND; RFND se controla aparte en columna RFND Cash
                    if "Tipo TXT" in _em_code_ok.columns:
                        _em_code_ok = _em_code_ok[~_em_code_ok["Tipo TXT"].astype(str).str.upper().str.contains("RFND", na=False)]
                    em_ok_neto = round(float(pd.to_numeric(_em_code_ok.get("Neto IATA", 0), errors="coerce").fillna(0).sum()), 2) if len(_em_code_ok) else 0.0

                # Si el Neto corregido desde Espejo cuadra con el Total Maverick conciliado,
                # reemplaza el total IATA por ese valor. Esto evita diferencia falsa QR/Qatar,
                # sin tocar compañías donde ADMS/RFND/ACMS hacen que no cuadre.
                if abs(em_ok_neto) > 0.01 and abs(total_conc - em_ok_neto) <= 0.01 and abs(iata_total - em_ok_neto) > 0.01:
                    iata_gds = em_ok_neto
                    iata_web = 0.0
                    iata_total = round(iata_gds + iata_web, 2)
            except Exception:
                pass

            diff = round(total_conc - iata_total, 2)
            rows.append([name, mav_net, mav_card, rf_cash, adms, acms, total_conc, iata_gds, iata_web, iata_total, diff, "OK" if abs(diff) <= 0.01 else "REVISAR", cantidad])

        comp = pd.DataFrame(rows, columns=[
            "Aerolínea", "Neto a pagar Maverick", "Total tarjeta Maverick", "RFND Cash", "ADMS", "ACMS",
            "Total Maverick conciliado", "Neto IATA GDS", "Neto IATA WEB", "Total Neto IATA", "Diferencia", "Estado", "Cantidad TKTT"
        ])

        def item_summary(label, ddf, dcol, rcol):
            item_rows = []
            for code in codes:
                iata_val = 0.0
                if not ri.empty and rcol in ri.columns:
                    iata_val = round(float(pd.to_numeric(ri[ri["_codigo_v3518"].astype(str).str.zfill(3)==code][rcol], errors="coerce").fillna(0).sum()), 2)
                det_val = _tuki_v3518_sum(ddf, dcol, code)
                if abs(iata_val) > 0.01 or abs(det_val) > 0.01:
                    diff = round(det_val - iata_val, 2)
                    item_rows.append([_tuki_v3518_company_name(code), iata_val, det_val, diff, "OK" if abs(diff) <= 0.01 else "REVISAR"])
            sdf = pd.DataFrame(item_rows, columns=["Aerolínea", f"Resumen IATA {label}", f"Hoja detalle {label}", "Diferencia", "Estado"])
            return sdf

        rfnd_sum = item_summary("RFND Cash", rfnd, "Importe Cash", "RFND Cash")
        adm_sum = item_summary("ADMS", adm, "Importe ADM", "ADMS")
        acm_sum = item_summary("ACMS", acm, "Importe ACM", "ACM")
        return comp, rfnd_sum, adm_sum, acm_sum
    except Exception:
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame(), pd.DataFrame()


def _tuki_v3518_total_row(df):
    vals = ["TOTAL"]
    try:
        for col in df.columns[1:]:
            if col == "Estado":
                vals.append("OK" if "Diferencia" in df.columns and abs(float(pd.to_numeric(df["Diferencia"], errors="coerce").fillna(0).sum())) <= 0.01 else "REVISAR")
            elif col == "Cantidad TKTT":
                vals.append(int(pd.to_numeric(df[col], errors="coerce").fillna(0).sum()))
            elif pd.api.types.is_numeric_dtype(df[col]):
                vals.append(round(float(pd.to_numeric(df[col], errors="coerce").fillna(0).sum()), 2))
            else:
                vals.append("")
    except Exception:
        vals += [""] * (len(df.columns)-1)
    return vals



# --- v3.5.24: normalización de boletos Maverick con sigla aérea ---
try:
    PDF_AIR_NAMES["157"] = PDF_AIR_NAMES.get("157", "Qatar Airways") or "Qatar Airways"
except Exception:
    pass

TUKI_AIRLINE_PREFIX_TO_IATA_V3524 = {
    "AA": "001", "DL": "006", "AC": "014", "UA": "016",
    "AR": "044", "LA": "045", "TP": "047", "AF": "057",
    "IB": "075", "G3": "127", "AV": "134", "AM": "139",
    "QR": "157", "HR": "169", "EK": "176", "LH": "220",
    "CM": "230", "TK": "235", "GP": "275", "AD": "577",
    "H2": "605", "JA": "973", "UX": "996",
}

def _tuki_v3524_split_maverick_airline_ticket(value):
    try:
        s = str(value or "").strip().upper()
        m = re.match(r"^([A-Z0-9]{2})[-\s]?(\d{6,13})$", s)
        if not m:
            return None, None
        pref, num = m.group(1), re.sub(r"\D", "", m.group(2))
        code = TUKI_AIRLINE_PREFIX_TO_IATA_V3524.get(pref)
        if code and num:
            return code, num
    except Exception:
        pass
    return None, None


def _tuki_v3528_tail_post_i_amount_if_matches(det, target_amount):
    """
    v3.5.28:
    Busca un importe positivo exacto después de la marca I, pero NO lo usa como neto general.
    Solo para reparar casos cash/sigla donde Maverick trae Total a pagar y el parser general dejó cero.
    Evita romper tickets con tarjeta donde ese tail es tarjeta/costo y el neto IATA debe ser 0.
    """
    try:
        if target_amount is None:
            return None, None, None
        cents = int(round(abs(float(target_amount)) * 100))
        if cents <= 0:
            return None, None, None
        s = str(det or "")
        raw_after_usd = s.split("USD2", 1)[1] if "USD2" in s else (s.split("USD", 1)[1] if "USD" in s else s)
        m_tail_marker = re.search(r"\s{4,}I\s+", raw_after_usd)
        if not m_tail_marker:
            return None, None, None
        tail_post_i = raw_after_usd[m_tail_marker.end():]

        # v3.5.42 - protección TKTT con tarjeta (especialmente Sabre).
        # En registros de tarjeta el bloque post-I puede contener el total del ticket,
        # pero ese importe NO es el neto que BSP debita a la agencia.
        # Ejemplo validado: ... 00000000000000000032497 ... NCCCA8146...
        # IATA/BSP cobra 0; 324.97 es el importe asociado a la tarjeta.
        # El fallback v3.5.28 existía solo para recuperar netos cash que habían quedado en 0.
        # Por eso, si el tail identifica tarjeta con NCC, no debe convertir ese total en Neto IATA.
        if re.search(r"\bNCC[A-Z0-9]*", tail_post_i[:220], flags=re.I):
            return None, None, "tail_post_I_tarjeta_NCC_no_es_neto"

        # tomar secuencias largas numéricas y mirar últimos 11 dígitos como importe con 2 decimales
        for m in re.finditer(r"\d{11,23}", tail_post_i[:160]):
            fld = m.group(0)
            last11 = fld[-11:]
            try:
                val = int(last11) / 100
            except Exception:
                continue
            if abs(val - abs(float(target_amount))) <= 0.01:
                return round(val, 2), fld, "positivo_tail_post_I_cash_match_total_maverick"
    except Exception:
        pass
    return None, None, None


def _tuki_v3524_ticket_match(mav_value, iata_doc_value, iata_code_value=None):
    try:
        mav_code, mav_num = _tuki_v3524_split_maverick_airline_ticket(mav_value)
        if not mav_num:
            return False
        iata_doc = re.sub(r"\D", "", str(iata_doc_value or ""))
        if not iata_doc:
            return False
        if mav_code and iata_code_value is not None and str(iata_code_value).strip() != "":
            ic = str(iata_code_value).strip()
            try:
                ic = str(int(float(ic))).zfill(3)
            except Exception:
                ic = ic.zfill(3) if ic.isdigit() else ic
            if ic and ic != mav_code:
                return False
        return (
            iata_doc == mav_num
            or iata_doc[:-1] == mav_num
            or iata_doc.startswith(mav_num)
            or mav_num.startswith(iata_doc)
        )
    except Exception:
        return False


def excel_bytes(sheets):
    out, resumen_contable, pivot = tuki_prepare_output_sheets(sheets)
    # v3.5.29: post-proceso final antes de escribir Excel.
    # Garantiza que QR-4885904565 quede OK incluso si la fila ya venía como CON DIFERENCIA
    # con DET TXT correcto pero Neto IATA 0. No toca tickets normales con tarjeta:
    # solo aplica a boletos con sigla aérea y si el tail post-I coincide exacto con Total Maverick.
    try:
        if "Espejo Maverick" in out:
            em_fix = out["Espejo Maverick"].copy()
            if not em_fix.empty and "Boleto" in em_fix.columns and "DET TXT" in em_fix.columns:
                for _idx, _row in em_fix.iterrows():
                    _boleto = _row.get("Boleto")
                    _code, _num = _tuki_v3524_split_maverick_airline_ticket(_boleto)
                    if not _code:
                        continue
                    try:
                        _total_mav = float(_row.get("Total a pagar Maverick") or 0)
                    except Exception:
                        _total_mav = 0
                    try:
                        _neto_actual = float(_row.get("Neto IATA") or 0)
                    except Exception:
                        _neto_actual = 0
                    if abs(_total_mav) <= 0.01 or abs(_neto_actual) > 0.01:
                        continue
                    _det_txt = _row.get("DET TXT")
                    _tail_val, _tail_field, _tail_method = _tuki_v3528_tail_post_i_amount_if_matches(_det_txt, _total_mav)
                    if _tail_val is None:
                        continue
                    if "Neto IATA" in em_fix.columns:
                        em_fix.at[_idx, "Neto IATA"] = _tail_val
                    if "Diferencia Maverick-IATA" in em_fix.columns:
                        em_fix.at[_idx, "Diferencia Maverick-IATA"] = round(_total_mav - _tail_val, 2)
                    if "Estado" in em_fix.columns:
                        em_fix.at[_idx, "Estado"] = "OK" if abs(_total_mav - _tail_val) <= 0.01 else "CON DIFERENCIA"
                    if "Campo control/neto" in em_fix.columns:
                        em_fix.at[_idx, "Campo control/neto"] = _tail_field
                    if "Método" in em_fix.columns:
                        em_fix.at[_idx, "Método"] = _tail_method
            out["Espejo Maverick"] = em_fix
    except Exception:
        pass

    resumen_comp_v3518, rfnd_sum_v3518, adm_sum_v3518, acm_sum_v3518 = _tuki_v3518_build_summary_tables(out)
    output = io.BytesIO()

    order = ["Resumen","Resumen Contable","Resumen IATA","Espejo Maverick","Diferencias","Falta en Maverick",
             "No encontrada en periodo IATA","Fuera de Periodo IATA","Duplicados Maverick","RFND","ADM","ACM","TKTT","EMDS","CANX","Resumen RFND Cash","Resumen ADMS","Resumen ACMS"]

    with pd.ExcelWriter(output, engine="xlsxwriter", datetime_format="ddmmmyy", date_format="ddmmmyy") as writer:
        wb = writer.book
        fmt_header = wb.add_format({"bold":True,"bg_color":"#1F4E78","font_color":"white","border":1,"align":"center"})
        fmt_cell_border = wb.add_format({"border":1})
        fmt_money_border = wb.add_format({"border":1, "num_format":"#,##0.00;[Red]-#,##0.00;-"})
        fmt_total_border = wb.add_format({"border":1, "bold":True, "bg_color":"#D9EAD3", "num_format":"#,##0.00;[Red]-#,##0.00;-"})
        fmt_total_text_border = wb.add_format({"border":1, "bold":True, "bg_color":"#D9EAD3"})
        fmt_money = wb.add_format({"num_format":"#,##0.00;[Red]-#,##0.00;-", "font_size":12})
        fmt_date = wb.add_format({"num_format":"ddmmmyy"})
        fmt_text = wb.add_format({})
        fmt_total = wb.add_format({"bold":True,"bg_color":"#D9EAD3","num_format":"#,##0.00;[Red]-#,##0.00;-", "font_size":12})
        fmt_total_label = wb.add_format({"bold":True,"bg_color":"#D9EAD3"})
        fmt_yellow = wb.add_format({"bg_color":"#FFF2CC","num_format":"#,##0.00;[Red]-#,##0.00;-"})
        fmt_red = wb.add_format({"bg_color":"#FFC7CE"})
        fmt_estado_ok = wb.add_format({"bg_color":"#E2F0D9"})
        fmt_estado_diff = wb.add_format({"bg_color":"#FCE4D6", "font_color":"#C00000"})
        fmt_estado_no = wb.add_format({"bg_color":"#FFF2CC"})
        fmt_estado_fuera = wb.add_format({"bg_color":"#D9EAF7"})
        fmt_emitido_web = wb.add_format({"bg_color":"#EADCF8"})
        fmt_emitido_bsp = wb.add_format({"bg_color":"#DDEBF7"})
        fmt_ok = wb.add_format({"bg_color":"#E2F0D9"})
        fmt_diff = wb.add_format({"bg_color":"#FCE4D6", "font_color":"#C00000"})
        fmt_no = wb.add_format({"bg_color":"#FFF2CC"})
        fmt_fuera = wb.add_format({"bg_color":"#D9EAF7"})
        fmt_web = wb.add_format({"bg_color":"#EADCF8"})
        fmt_bsp = wb.add_format({"bg_color":"#DDEBF7"})
        fmt_title = wb.add_format({"bold":True,"font_size":14,"font_color":"#1F4E78"})
        fmt_note = wb.add_format({"italic": True, "font_color": "#666666"})
        fmt_semana_label = wb.add_format({"bold": True, "font_size": 14, "bg_color": "#D9D9D9", "border": 2, "align": "center", "valign": "vcenter"})
        fmt_int = wb.add_format({"num_format":"#,##0;[Red]-#,##0;-", "font_size":12})
        fmt_int_border = wb.add_format({"border":1, "num_format":"#,##0;[Red]-#,##0;-"})

        fmt_diff_label_resumen = wb.add_format({"bold": True, "font_size": 14, "bg_color": "#D9D9D9", "border": 2, "align": "center", "valign": "vcenter"})
        fmt_semana_ok = wb.add_format({"bold": True, "font_size": 14, "font_color": "#006100", "bg_color": "#C6EFCE", "align":"center", "valign":"vcenter", "border":2, "num_format":"#,##0.00;[Red]-#,##0.00;-"})
        fmt_diff_rojo_resumen = wb.add_format({"bold": True, "font_size": 14, "font_color": "#9C0006", "bg_color": "#FFC7CE", "align":"center", "valign":"vcenter", "border":2, "num_format":"#,##0.00;[Red]-#,##0.00;-"})
        fmt_diff_zero_resumen = wb.add_format({"bold": True, "font_size": 14, "font_color": "#006100", "bg_color": "#C6EFCE", "num_format":"#,##0.00;[Red]-#,##0.00;-"})
        fmt_diff_bad_resumen = wb.add_format({"bold": True, "font_size": 14, "font_color": "#006100", "bg_color": "#C6EFCE", "num_format":"#,##0.00;[Red]-#,##0.00;-"})

        total_cols = {
            "Espejo Maverick":["Monto Tarjeta"," Costo de Res.","Total a pagar Maverick","Neto IATA","Diferencia Maverick-IATA"],
            "Diferencias":["Monto Tarjeta"," Costo de Res.","Total a pagar Maverick","Neto IATA","Diferencia Maverick-IATA"],
            "Falta en Maverick":["Neto a pagar"],
            "No encontrada en periodo IATA":["Monto Tarjeta"," Costo de Res.","Total a pagar Maverick"],
            "Fuera de Periodo IATA":["Monto Tarjeta"," Costo de Res.","Total a pagar Maverick","Neto IATA","Diferencia Maverick-IATA"],
            "RFND":["Importe Cash","Importe CC"],
            "ADM":["Importe ADM"],
            "ACM":["Importe ACM"],
            "TKTT":["Monto Tarjeta","Neto IATA"],
            "EMDS":["Importe EMD"],
        }

        for name in order:
            if name == "Resumen Contable":
                df = resumen_contable
            elif name == "Resumen RFND Cash":
                df = rfnd_sum_v3518
            elif name == "Resumen ADMS":
                df = adm_sum_v3518
            elif name == "Resumen ACMS":
                df = acm_sum_v3518
            else:
                df = out.get(name)
            if df is None:
                continue

            df.to_excel(writer, sheet_name=name[:31], index=False)
            ws = writer.sheets[name[:31]]
            if name in ["Resumen RFND Cash", "Resumen ADMS", "Resumen ACMS"]:
                try:
                    for _rr in range(1, len(df)+1):
                        for _cc, _col in enumerate(df.columns):
                            _val = df.iloc[_rr-1, _cc]
                            if _col == "Estado":
                                ws.write(_rr, _cc, _val, fmt_semana_ok if str(_val).upper()=="OK" else fmt_diff_rojo_resumen)
                            elif _col == "Diferencia":
                                _fval = float(_val or 0)
                                ws.write_number(_rr, _cc, _fval, fmt_semana_ok if abs(_fval)<=0.01 else fmt_diff_rojo_resumen)
                            elif pd.api.types.is_numeric_dtype(df[_col]):
                                ws.write_number(_rr, _cc, float(_val or 0), fmt_money_border)
                    ws.set_column(0, 0, 34)
                    ws.set_column(1, 3, 18)
                    ws.set_column(4, 4, 14)
                except Exception:
                    pass

            # v3.3.6: marcar fila TOTAL en negrita y formato numérico
            try:
                total_fmt_v336 = writer.book.add_format({"bold": True, "num_format": "#,##0.00;[Red]-#,##0.00;-"})
                total_label_fmt_v336 = writer.book.add_format({"bold": True})
                if len(df) > 0 and str(df.iloc[-1, 0]).upper() == "TOTAL":
                    total_excel_row = len(df)  # header is row 0; last df row is len(df)
                    ws.write(total_excel_row, 0, "TOTAL", total_label_fmt_v336)
                    for _c_idx, _c_name in enumerate(df.columns):
                        if _c_idx == 0:
                            continue
                        _v = df.iloc[-1, _c_idx]
                        if pd.notna(_v) and isinstance(_v, (int, float)):
                            ws.write_number(total_excel_row, _c_idx, float(_v), total_fmt_v336)
                        elif pd.notna(_v) and str(_v) != "":
                            ws.write(total_excel_row, _c_idx, _v, total_label_fmt_v336)
            except Exception:
                pass

            for c,h in enumerate(df.columns):
                ws.write(0,c,h,fmt_header)
                hlow = str(h).lower()
                if "fecha" in hlow:
                    ws.set_column(c,c,12,fmt_date)
                elif "cantidad" in hlow or "docs" in hlow:
                    ws.set_column(c,c,14,fmt_int)
                elif any(k in hlow for k in ["monto","costo","total","neto","diferencia","importe","cash","cc"]) and "campo" not in hlow and "comisión" not in hlow and "comision" not in hlow:
                    ws.set_column(c,c,16,fmt_money)
                elif "aerolínea" in hlow:
                    ws.set_column(c,c,28,fmt_text)
                else:
                    vals = df[h].dropna().astype(str).head(100).tolist() if h in df.columns else []
                    ws.set_column(c,c,min(max([len(str(h))]+[len(x) for x in vals])+2,60),fmt_text)

            if name == "Resumen IATA" and len(df):
                ws.set_column(0, 3, 24)
                ws.set_column(4, 4, 10)
                ws.set_column(5, len(df.columns)-1, 18)
                # Bordes en toda la tabla y fila TOTAL destacada.
                numeric_cols_ri = {"Cash","CC","Total","RFND Cash","RFND CC","RFND Total","ADMS","ACM","Tasas y Cargos","Monto Cash","Taxs sin Comi","Neto a pagar","Cantidad de docs"}
                for rr in range(1, len(df)+1):
                    row_cat = str(df.iloc[rr-1].get("Categoria","")).upper()
                    row_comp = str(df.iloc[rr-1].get("Compañia","")).upper()
                    is_total_row = row_comp == "TOTAL" or row_cat == "TOTAL"
                    is_conc_row = row_cat == "TOTAL SEGUN CONCILIADOR"
                    is_diff_row = row_cat == "DIFERENCIA CONCILIADOR-PDF"
                    for cc_i, col_name in enumerate(df.columns):
                        val = df.iloc[rr-1, cc_i]
                        cell_fmt_text = fmt_total_text_border if (is_total_row or is_conc_row) else fmt_cell_border
                        cell_fmt_num = fmt_total_border if (is_total_row or is_conc_row) else fmt_money_border

                        if is_diff_row:
                            if str(val).upper() == "OK":
                                ws.write(rr, cc_i, "OK", fmt_semana_ok)
                            elif col_name in numeric_cols_ri:
                                try:
                                    ws.write_number(rr, cc_i, float(val or 0), fmt_diff_rojo_resumen)
                                except Exception:
                                    ws.write(rr, cc_i, val, fmt_diff_rojo_resumen)
                            else:
                                ws.write(rr, cc_i, val, fmt_diff_label_resumen)
                            continue

                        if col_name == "Cantidad de docs":
                            try:
                                ws.write_number(rr, cc_i, int(float(val or 0)), fmt_total_border if is_total_row else fmt_int_border)
                            except Exception:
                                ws.write(rr, cc_i, val, fmt_total_text_border if is_total_row else fmt_cell_border)
                        elif col_name in numeric_cols_ri:
                            try:
                                ws.write_number(rr, cc_i, float(val or 0), cell_fmt_num)
                            except Exception:
                                ws.write(rr, cc_i, val, cell_fmt_num if (is_total_row or is_conc_row) else fmt_cell_border)
                        else:
                            ws.write(rr, cc_i, val, cell_fmt_text)

            if name == "Resumen Contable":
                ws.set_column(0,0,90)
                ws.set_column(1,1,18)
                idx_calc = df.index[df["Concepto"].astype(str).str.contains("TOTAL A PAGAR EN IATA calculado", case=False, na=False)][0] + 2
                idx_info = df.index[df["Concepto"].eq("TOTAL informado por IATA")][0] + 2
                diff_rows = df.index[df["Concepto"].astype(str).eq("Diferencia de la Semana")]
                if len(diff_rows) == 0:
                    diff_rows = df.index[df["Concepto"].astype(str).str.contains("Diferencia", case=False, na=False)]
                idx_diff = int(diff_rows[0]) + 2
                # B13 queda con el total informado del PDF si vino cargado.
                try:
                    val_info = df.loc[df["Concepto"].eq("TOTAL informado por IATA"), "Importe"].iloc[0]
                    if val_info != "" and pd.notna(val_info):
                        ws.write_number(idx_info-1, 1, float(val_info), fmt_money)
                    else:
                        ws.write_blank(idx_info-1, 1, None, fmt_yellow)
                except Exception:
                    ws.write_blank(idx_info-1, 1, None, fmt_yellow)
                # Fila real de Diferencia de la Semana, no arriba del resumen.
                ws.write(idx_diff-1, 0, "Diferencia de la Semana", fmt_semana_label)
                ws.write_formula(idx_diff-1, 1, f'=IF(ABS(B{idx_calc}-B{idx_info})<0.01,"SEMANA OK",B{idx_calc}-B{idx_info})', fmt_semana_ok)
                ws.conditional_format(idx_diff-1, 1, idx_diff-1, 1, {"type":"formula", "criteria":f'=AND(ISNUMBER(B{idx_diff}),ABS(B{idx_diff})>=0.01)', "format":fmt_diff_rojo_resumen})

                note_rows = df.index[df["Concepto"].astype(str).str.startswith("* Nota")]
                for nr in note_rows:
                    ws.write(nr+1, 0, df.loc[nr, "Concepto"], fmt_note)

                # v3.5.18: Nueva conciliación por compañía abajo del resumen viejo.
                # No se escribe la tabla vieja "Resumen por compañía desde Espejo Maverick".
                if resumen_comp_v3518 is not None and not resumen_comp_v3518.empty:
                    start = len(df) + 5
                    ws.write(start, 0, "Conciliación por compañía desde Espejo + ADMS/ACMS/RFND Cash", fmt_title)
                    data = resumen_comp_v3518.copy()
                    data.to_excel(writer, sheet_name=name[:31], startrow=start+1, startcol=0, index=False)
                    for c,h in enumerate(data.columns):
                        ws.write(start+1, c, h, fmt_header)
                    # filtro solo en cuerpo, sin incluir la fila TOTAL
                    ws.autofilter(start+1, 0, start+1+len(data), len(data.columns)-1)
                    try:
                        for _rr in range(start+2, start+2+len(data)):
                            for _cc, _col in enumerate(data.columns):
                                _val = data.iloc[_rr-(start+2), _cc]
                                if _col == "Estado":
                                    ws.write(_rr, _cc, _val, fmt_semana_ok if str(_val).upper()=="OK" else fmt_diff_rojo_resumen)
                                elif _col == "Diferencia":
                                    _fval = float(_val or 0)
                                    ws.write_number(_rr, _cc, _fval, fmt_semana_ok if abs(_fval)<=0.01 else fmt_diff_rojo_resumen)
                                elif _col == "Cantidad TKTT":
                                    ws.write_number(_rr, _cc, int(float(_val or 0)), fmt_int_border)
                                elif pd.api.types.is_numeric_dtype(data[_col]):
                                    ws.write_number(_rr, _cc, float(_val or 0), fmt_money_border)
                    except Exception:
                        pass
                    total_row = start + 2 + len(data)
                    total_vals = _tuki_v3518_total_row(data)
                    for c, val in enumerate(total_vals):
                        if c == 0:
                            ws.write(total_row, c, val, fmt_total_label)
                        elif c < len(data.columns) and data.columns[c] == "Estado":
                            ws.write(total_row, c, val, fmt_semana_ok if str(val).upper()=="OK" else fmt_diff_rojo_resumen)
                        elif c < len(data.columns) and data.columns[c] == "Cantidad TKTT":
                            try:
                                ws.write_number(total_row, c, int(val or 0), fmt_int_border)
                            except Exception:
                                ws.write(total_row, c, val, fmt_total_text_border)
                        else:
                            try:
                                ws.write_number(total_row, c, float(val or 0), fmt_total)
                            except Exception:
                                ws.write(total_row, c, val, fmt_total_label)

                    # Control total por ítem debajo
                    item_start = total_row + 4
                    ctrl_rows = []
                    for label, sdf in [("RFND Cash", rfnd_sum_v3518), ("ADMS", adm_sum_v3518), ("ACMS", acm_sum_v3518)]:
                        if sdf is not None and not sdf.empty:
                            iata_col = [x for x in sdf.columns if str(x).startswith("Resumen IATA")]
                            det_col = [x for x in sdf.columns if str(x).startswith("Hoja detalle")]
                            iata_val = float(pd.to_numeric(sdf[iata_col[0]], errors="coerce").fillna(0).sum()) if iata_col else 0.0
                            det_val = float(pd.to_numeric(sdf[det_col[0]], errors="coerce").fillna(0).sum()) if det_col else 0.0
                            diff = round(det_val - iata_val, 2)
                            ctrl_rows.append([label, round(iata_val,2), round(det_val,2), diff, "OK" if abs(diff)<=0.01 else "REVISAR"])
                    ctrl = pd.DataFrame(ctrl_rows, columns=["Item","Resumen IATA","Hoja detalle","Diferencia","Estado"])
                    if not ctrl.empty:
                        ws.write(item_start, 0, "Control total por ítem contra Resumen IATA", fmt_title)
                        ctrl.to_excel(writer, sheet_name=name[:31], startrow=item_start+1, startcol=0, index=False)
                        for c,h in enumerate(ctrl.columns):
                            ws.write(item_start+1, c, h, fmt_header)
                        # Formato visual del resumen inferior: colores y números contables.
                        try:
                            for _rr in range(item_start+2, item_start+2+len(ctrl)):
                                for _cc, _col in enumerate(ctrl.columns):
                                    _val = ctrl.iloc[_rr-(item_start+2), _cc]
                                    if _col == "Estado":
                                        ws.write(_rr, _cc, _val, fmt_semana_ok if str(_val).upper()=="OK" else fmt_diff_rojo_resumen)
                                    elif _col == "Diferencia":
                                        _fval = float(_val or 0)
                                        ws.write_number(_rr, _cc, _fval, fmt_semana_ok if abs(_fval)<=0.01 else fmt_diff_rojo_resumen)
                                    elif pd.api.types.is_numeric_dtype(ctrl[_col]):
                                        ws.write_number(_rr, _cc, float(_val or 0), fmt_money_border)
                                    else:
                                        ws.write(_rr, _cc, _val, fmt_cell_border)
                        except Exception:
                            pass

            elif name != "Resumen" and len(df):
                ws.autofilter(0,0,len(df),len(df.columns)-1)

            if "Aerolínea" in df.columns:
                ci = list(df.columns).index("Aerolínea")
                for ri,val in enumerate(df["Aerolínea"],start=1):
                    if str(val).startswith("FALTA NOMBRE"):
                        ws.write(ri,ci,val,fmt_red)

            # Colores visuales para estados, aplicado dentro de cada hoja
            for estado_col_name in ["Estado", "Estado Maverick"]:
                if estado_col_name in df.columns:
                    estado_ci = list(df.columns).index(estado_col_name)
                    for estado_ri, estado_val in enumerate(df[estado_col_name], start=1):
                        estado_txt = str(estado_val or "").upper()
                        if "RFND EN MAVERIC" in estado_txt:
                            ws.write(estado_ri, estado_ci, estado_val, fmt_estado_ok)
                        elif "RFND FUERA" in estado_txt:
                            ws.write(estado_ri, estado_ci, estado_val, fmt_estado_no)
                        elif "DUPLICADO" in estado_txt:
                            ws.write(estado_ri, estado_ci, estado_val, fmt_estado_no)
                        elif "FUERA" in estado_txt:
                            ws.write(estado_ri, estado_ci, estado_val, fmt_estado_fuera)
                        elif "DIF" in estado_txt:
                            ws.write(estado_ri, estado_ci, estado_val, fmt_estado_diff)
                        elif "NO" in estado_txt:
                            ws.write(estado_ri, estado_ci, estado_val, fmt_estado_no)
                        elif "OK" in estado_txt:
                            ws.write(estado_ri, estado_ci, estado_val, fmt_estado_ok)

            # v3.5.18: resúmenes por compañía dentro de RFND/ADM/ACM.
            if name in ["RFND", "ADM", "ACM"]:
                _summary_map = {"RFND": rfnd_sum_v3518, "ADM": adm_sum_v3518, "ACM": acm_sum_v3518}
                _title_map = {"RFND": "Resumen por compañía - RFND Cash", "ADM": "Resumen por compañía - ADMS", "ACM": "Resumen por compañía - ACMS"}
                _sdf = _summary_map.get(name)
                if _sdf is not None and not _sdf.empty:
                    _start = len(df) + 3
                    ws.write(_start, 0, _title_map.get(name, "Resumen por compañía"), fmt_title)
                    _sdf.to_excel(writer, sheet_name=name[:31], startrow=_start+1, startcol=0, index=False)
                    for _c, _h in enumerate(_sdf.columns):
                        ws.write(_start+1, _c, _h, fmt_header)
                    ws.autofilter(_start+1, 0, _start+1+len(_sdf), len(_sdf.columns)-1)
                    try:
                        for _rr in range(_start+2, _start+2+len(_sdf)):
                            for _cc, _col in enumerate(_sdf.columns):
                                _val = _sdf.iloc[_rr-(_start+2), _cc]
                                if _col == "Estado":
                                    ws.write(_rr, _cc, _val, fmt_semana_ok if str(_val).upper()=="OK" else fmt_diff_rojo_resumen)
                                elif _col == "Diferencia":
                                    _fval = float(_val or 0)
                                    ws.write_number(_rr, _cc, _fval, fmt_semana_ok if abs(_fval)<=0.01 else fmt_diff_rojo_resumen)
                                elif pd.api.types.is_numeric_dtype(_sdf[_col]):
                                    ws.write_number(_rr, _cc, float(_val or 0), fmt_money_border)
                    except Exception:
                        pass
                    _total_row = _start + 2 + len(_sdf)
                    _total_vals = _tuki_v3518_total_row(_sdf)
                    for _c, _v in enumerate(_total_vals):
                        if _c == 0:
                            ws.write(_total_row, _c, _v, fmt_total_label)
                        elif _c < len(_sdf.columns) and _sdf.columns[_c] == "Estado":
                            ws.write(_total_row, _c, _v, fmt_semana_ok if str(_v).upper()=="OK" else fmt_diff_rojo_resumen)
                        else:
                            try:
                                ws.write_number(_total_row, _c, float(_v or 0), fmt_total)
                            except Exception:
                                ws.write(_total_row, _c, _v, fmt_total_label)
                    # Anchos del resumen para evitar ######.
                    try:
                        ws.set_column(0, 0, 34)
                        ws.set_column(1, 3, 18)
                        ws.set_column(4, 4, 14)
                    except Exception:
                        pass

            if "Emitido en:" in df.columns:
                emitido_ci = list(df.columns).index("Emitido en:")
                for emitido_ri, emitido_val in enumerate(df["Emitido en:"], start=1):
                    emitido_txt = str(emitido_val or "").upper()
                    if emitido_txt == "WEB":
                        ws.write(emitido_ri, emitido_ci, emitido_val, fmt_emitido_web)
                    elif emitido_txt == "BSP":
                        ws.write(emitido_ri, emitido_ci, emitido_val, fmt_emitido_bsp)
                    elif emitido_txt == "???":
                        ws.write(emitido_ri, emitido_ci, emitido_val, fmt_estado_no)

            # Congelar siempre primera fila
            ws.freeze_panes(1, 0)

    output.seek(0)
    output.seek(0)
    return output.getvalue()


def output_name(start, end):
    s = pd.to_datetime(start)
    e = pd.to_datetime(end)
    meses = {
        1: "ene", 2: "feb", 3: "mar", 4: "abr", 5: "may", 6: "jun",
        7: "jul", 8: "ago", 9: "sep", 10: "oct", 11: "nov", 12: "dic"
    }
    mes = meses[e.month]
    creado = datetime.now()
    creado_txt = f"{creado.day}{meses[creado.month]}{str(creado.year)[-2:]}_{creado.strftime('%H%M')}"
    return f"Conciliacion_IATA_Maverick_{s.day}-{e.day}_{mes}_{e.strftime('%y')}_creado_{creado_txt}.xlsx"


# Autorización agregada v2.9.7
EXTRA_AUTHORIZED_UUIDS = {
    "D4157452-1745-11EC-B699-67F9496C3500": {"name": "Laura Techera PC", "role": "user"},
}

def get_app_root():
    p = Path(__file__).resolve()
    parts = list(p.parts)
    if "APP_MAC" in parts:
        return Path(*parts[:parts.index("APP_MAC")])
    if "APP_PC" in parts:
        return Path(*parts[:parts.index("APP_PC")])
    return p.parent

APP_BASE_DIR = get_app_root()

def get_reports_base_dir():
    # v3.5.33:
    # Orden de carpetas para Mac/PC.
    # La app queda dentro de Documentos/App Conciliador IATA Maveric
    # y los archivos generados se guardan dentro de esa misma carpeta,
    # en "archivos conciliados de iata".
    home = Path.home()
    docs = home / "Documents"
    if not docs.exists():
        docs = home / "Documentos"
    if not docs.exists():
        docs = home
    app_folder = docs / "App Conciliador IATA Maveric"
    base = app_folder / "archivos conciliados de iata"
    base.mkdir(parents=True, exist_ok=True)
    return base

REPORTS_DIR = get_reports_base_dir()
OUT_DIR = REPORTS_DIR

def period_folder_name(start, end):
    s = pd.to_datetime(start)
    e = pd.to_datetime(end)
    meses = {
        1: "ene", 2: "feb", 3: "mar", 4: "abr", 5: "may", 6: "jun",
        7: "jul", 8: "ago", 9: "sep", 10: "oct", 11: "nov", 12: "dic"
    }
    if s.month == e.month and s.year == e.year:
        return f"{s.day}-{e.day} {meses[e.month]} {str(e.year)[-2:]}"
    return f"{s.day} {meses[s.month]}-{e.day} {meses[e.month]} {str(e.year)[-2:]}"

def get_period_output_dir(start, end):
    folder = REPORTS_DIR / period_folder_name(start, end)
    folder.mkdir(parents=True, exist_ok=True)
    return folder

def get_conciliador_home():
    return REPORTS_DIR


def period_folder_name(start, end):
    s = pd.to_datetime(start)
    e = pd.to_datetime(end)
    meses = {
        1: "ene", 2: "feb", 3: "mar", 4: "abr", 5: "may", 6: "jun",
        7: "jul", 8: "ago", 9: "sep", 10: "oct", 11: "nov", 12: "dic"
    }
    if s.month == e.month and s.year == e.year:
        return f"{s.day}-{e.day} {meses[e.month]} {str(e.year)[-2:]}"
    return f"{s.day} {meses[s.month]}-{e.day} {meses[e.month]} {str(e.year)[-2:]}"

def get_period_output_dir(start, end):
    folder = REPORTS_DIR / period_folder_name(start, end)
    folder.mkdir(parents=True, exist_ok=True)
    return folder

def get_conciliador_home():
    return REPORTS_DIR


def period_folder_name(start, end):
    s = pd.to_datetime(start)
    e = pd.to_datetime(end)
    mes = e.strftime("%b").lower()
    return f"{s.day}-{e.day} {mes} {e.strftime('%y')}"

def get_period_output_dir(start, end):
    folder = REPORTS_DIR / period_folder_name(start, end)
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def period_folder_name(start, end):
    s = pd.to_datetime(start)
    e = pd.to_datetime(end)
    mes = e.strftime("%b").lower()
    return f"{s.day}-{e.day} {mes} {e.strftime('%y')}"

def get_period_output_dir(start, end):
    folder = REPORTS_DIR / period_folder_name(start, end)
    folder.mkdir(parents=True, exist_ok=True)
    return folder



def tuki_authorized_devices_table():
    data = [
        {"Nombre": "Tuki Mac Admin", "UUID/HWID": "LOCAL_ADMIN", "Rol": "admin"},
        {"Nombre": "Laura Techera PC", "UUID/HWID": "D4157452-1745-11EC-B699-67F9496C3500", "Rol": "user"},
    ]
    try:
        for k, v in AUTHORIZED_DEVICES.items():
            if isinstance(v, dict):
                data.append({"Nombre": v.get("name", k), "UUID/HWID": k, "Rol": v.get("role", "")})
            else:
                data.append({"Nombre": str(v), "UUID/HWID": k, "Rol": ""})
    except Exception:
        pass
    # dedupe por UUID/HWID
    seen = set()
    clean = []
    for row in data:
        key = row.get("UUID/HWID")
        if key not in seen:
            clean.append(row)
            seen.add(key)
    return pd.DataFrame(clean)

st.set_page_config(page_title=APP_NAME, page_icon="🧾", layout="wide")

st.markdown("""
<style>
.tuki-hero {
    background: linear-gradient(135deg, #eaf6ff 0%, #f5f7fa 100%);
    border: 1px solid #d6e7f5;
    border-radius: 18px;
    padding: 26px 30px;
    margin: 8px 0 22px 0;
    box-shadow: 0 2px 10px rgba(31,78,121,0.08);
}
.tuki-hero h1 {
    color: #111827;
    font-size: 36px;
    font-weight: 750;
    margin: 0;
    letter-spacing: -0.5px;
}
.tuki-hero p {
    color: #4b5563;
    margin: 8px 0 0 0;
    font-size: 15px;
}
section[data-testid="stSidebar"] { background: #f7fafc; }
</style>
<div class="tuki-hero">
  <h1>Conciliador IATA - Maveric</h1>
  <p>Conciliación operativa y contable de Subir TXT de la IATA contra Maveric original.</p>
</div>
""", unsafe_allow_html=True)

col_logo, col_title = st.columns([1, 5])
with col_logo:
    show_logo()
with col_title:
    # st.title(APP_NAME)  # reemplazado por tuki-hero
    st.caption(f"Versión {VERSION} · Creada {CREATED_LABEL}")

device_uuid, device_info = check_device_authorized()

if not device_info:
    st.error("Aplicación no autorizada para este dispositivo.")
    st.warning(f"UUID detectado: {device_uuid or 'No pude detectar UUID'}")
    st.info("Enviá este UUID a Tuki para autorizar el equipo.")
    st.stop()

st.sidebar.success(f"Autorizado: {device_info['name']} | Rol: {device_info['role']}")

if device_info["role"] == "admin":
    st.sidebar.caption("Modo admin habilitado.")

# Sidebar utilidades v2.8.9

try:
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
except Exception:
    pass

st.sidebar.markdown("---")
st.sidebar.markdown("### Utilidades")
if st.sidebar.button("Abrir carpeta de reportes", key="abrir_reportes_v285"):
    try:
        import subprocess, sys
        if sys.platform == "darwin":
            subprocess.Popen(["open", str(REPORTS_DIR)])
        elif sys.platform.startswith("win"):
            os.startfile(str(REPORTS_DIR))
        else:
            subprocess.Popen(["xdg-open", str(REPORTS_DIR)])
    except Exception as e:
        st.sidebar.warning(f"No pude abrir la carpeta: {e}")

if device_info.get("role") == "admin":
    with st.sidebar.expander("Admin"):
        st.caption("Diagnóstico")
        if st.button("Ver logs", key="ver_logs_v285"):
            try:
                logs = sorted(REPORTS_DIR.glob("*.log"), key=lambda p: p.stat().st_mtime, reverse=True)
                if logs:
                    st.text_area("Último log", logs[0].read_text(errors="ignore")[-8000:], height=260)
                else:
                    st.info("No encontré logs.")
            except Exception as e:
                st.warning(f"No pude leer logs: {e}")
        if st.button("Reiniciar motor", key="reiniciar_motor_v285"):
            st.warning("Cerrá esta pestaña y volvé a abrir la app.")


if st.sidebar.button("Cerrar aplicación", key="cerrar_sidebar_v287"):
    st.sidebar.warning("Cerrando servidor local...")
    os._exit(0)





st.markdown("""
<style>
/* Tuki custom css */
h1 { font-size: 2.4rem !important; white-space: normal !important; }
.block-container { padding-top: 3rem; }
</style>
""", unsafe_allow_html=True)

st.write("Subí el TXT largo de la IATA, el XLS de Maveric original sin títulos y, opcionalmente, el PDF de resumen IATA.")

col1, col2, col3 = st.columns(3)
with col1:
    txt_file = st.file_uploader("Subir TXT de la IATA", type=["txt","TXT"])
with col2:
    mav_file = st.file_uploader("Subir XLS de Maveric original sin títulos", type=["xlsx","xls"])
with col3:
    resumen_pdf_file = st.file_uploader("Subir PDF resumen IATA opcional", type=["pdf"])

periodo = st.date_input(
    "📅 Seleccionar el período IATA",
    value=(pd.Timestamp.today().date(), pd.Timestamp.today().date()),
    help="Elegí primero el día inicial y después el día final del período IATA."
)

if isinstance(periodo, tuple) and len(periodo) == 2:
    start_date, end_date = periodo
else:
    start_date = end_date = periodo

if st.button("GENERAR CONCILIACIÓN", type="primary"):
    if txt_file is None or mav_file is None:
        st.error("Tenés que subir Subir TXT de la IATA y Subir XLS de Maveric original sin títulos.")
    elif pd.Timestamp(start_date) > pd.Timestamp(end_date):
        st.error("La fecha desde no puede ser mayor que la fecha hasta.")
    else:
        try:
            sheets = build_beta2(txt_file, mav_file, start_date, end_date)
            resumen_iata_df, totales_iata_df, total_iata_pdf, diag_pdf_iata = parse_iata_summary_pdf(resumen_pdf_file)
            try:
                pdf_subido = resumen_pdf_file is not None
            except Exception:
                pdf_subido = False
            if pdf_subido:
                if resumen_iata_df is None or resumen_iata_df.empty:
                    resumen_iata_df = pd.DataFrame([{"Categoria":"ERROR","Codigo":"","Sigla":"","Compañia":f"PDF subido, pero sin filas parseadas. Diagnóstico: {diag_pdf_iata}","FOP":"","Cash":0.0,"CC":0.0,"Total":0.0,"RFND Cash":0.0,"RFND CC":0.0,"RFND Total":0.0,"ADMS":0.0,"ACM":0.0,"Tasas y Cargos":0.0,"Monto Cash":0.0,"Taxs sin Comi":0.0,"Neto a pagar":0.0,"Cantidad de docs":0}])
                sheets["Resumen IATA"] = resumen_iata_df
                if total_iata_pdf is not None:
                    sheets["_TOTAL_INFORMADO_IATA_PDF"] = float(total_iata_pdf)
            data = excel_bytes(sheets); filename = output_name(start_date, end_date)
            out_dir = get_period_output_dir(start_date, end_date); (out_dir / filename).write_bytes(data)
            st.success("Conciliación generada correctamente.")
            st.download_button("Descargar Excel conciliado", data=data, file_name=filename, mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            st.info(f"También se guardó una copia en: {out_dir}")
        except Exception as e:
            st.exception(e)
