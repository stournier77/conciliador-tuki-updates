@echo off
setlocal
set "BASE=%USERPROFILE%\Documents\App Conciliador IATA Maveric"
set "APPFILES=%BASE%\Archivos APP"
set "APPDIR=%APPFILES%\APP_PC"
set "VERSIONFILE=%APPFILES%\installed_version.txt"
set "LOGDIR=%APPFILES%\logs"
set "PORT=8761"
if not exist "%LOGDIR%" mkdir "%LOGDIR%"

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
 "$ErrorActionPreference='Stop'; $repo='stournier77/conciliador-tuki-updates'; $vf='%VERSIONFILE%'; $installed=if(Test-Path $vf){(Get-Content $vf -Raw).Trim()}else{'0'}; try{$r=Invoke-RestMethod -Headers @{'User-Agent'='Conciliador-IATA'} -Uri ('https://api.github.com/repos/'+$repo+'/releases/latest'); $remote=$r.tag_name.TrimStart('v'); if($remote -ne $installed){$a=$r.assets|Where-Object{$_.name -eq 'latest_pc.zip'}|Select-Object -First 1; if($a){$tmp=Join-Path $env:TEMP ('conciliador_iata_'+[guid]::NewGuid()); New-Item -ItemType Directory -Path $tmp|Out-Null; $zip=Join-Path $tmp 'latest_pc.zip'; Invoke-WebRequest -UseBasicParsing -Uri $a.browser_download_url -OutFile $zip; Expand-Archive -Path $zip -DestinationPath (Join-Path $tmp 'u') -Force; $src=Get-ChildItem (Join-Path $tmp 'u') -Recurse -Directory|Where-Object{$_.Name -eq 'Archivos APP'}|Select-Object -First 1; if($src){Copy-Item (Join-Path $src.FullName 'APP_PC\*') '%APPDIR%' -Recurse -Force; Copy-Item (Join-Path $src.FullName 'assets\*') '%APPFILES%\assets' -Recurse -Force; Copy-Item (Join-Path $src.FullName 'installed_version.txt') $vf -Force}; Remove-Item $tmp -Recurse -Force}}}catch{Add-Content '%LOGDIR%\actualizador.log' ((Get-Date).ToString('s')+' '+$_.Exception.Message)}"

python -c "import streamlit,pandas,openpyxl,xlsxwriter,pypdf" >nul 2>&1
if errorlevel 1 python -m pip install --user streamlit pandas openpyxl xlsxwriter PyPDF2 pypdf xlrd
for /f "tokens=5" %%P in ('netstat -ano ^| findstr ":%PORT% " ^| findstr "LISTENING"') do taskkill /PID %%P /F >nul 2>&1
cd /d "%APPDIR%"
start "Conciliador IATA Maveric" /B python -m streamlit run "%APPDIR%\app.py" --server.headless false --server.port %PORT%
timeout /t 2 /nobreak >nul
start "" "http://localhost:%PORT%"
endlocal
