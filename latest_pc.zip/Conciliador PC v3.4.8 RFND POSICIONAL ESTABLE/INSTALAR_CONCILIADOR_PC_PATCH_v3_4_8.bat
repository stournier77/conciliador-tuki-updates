@echo off
echo Copiando app.py v3.4.8 RFND POSICIONAL ESTABLE...
copy /Y app.py ..\APP_PCpp.py
echo Listo.
pause
